"""3D box conventions, conversions, and IoU.

Two box parameterisations are used:

**KITTI camera box** (labels and PointRCNN detections), in the *rectified camera-0* frame
(x right, y down, z forward):

* ``loc = (x, y, z)``: centre of the box's **bottom face** (not the geometric centre),
* ``dims = (h, w, l)``: height along -y, width, length,
* ``ry``: rotation about the camera y axis; the object's length axis points along
  ``R_y(ry) @ [1, 0, 0] = (cos ry, 0, -sin ry)``. ``ry = 0`` means facing camera +x.

**Tracking box** ``box7 = [x, y, z, yaw, l, w, h]`` in a right-handed **z-up** frame
(the world/ENU frame during tracking): ``(x, y, z)`` is the **geometric centre**, ``yaw`` is
the heading of the length axis measured counter-clockwise from +x in the xy plane.

Converting camera -> z-up keeps only the heading component of orientation: the box's
vertical axis is assumed parallel to the target frame's z axis. The small road pitch/roll
(typically < 2 deg in KITTI) is therefore neglected, which is the usual BEV-tracking
assumption.
"""

from __future__ import annotations

import numpy as np

from .transforms import rot_y, transform_points, wrap_angle

# Axis permutation from rectified camera (x right, y down, z fwd) to a z-up frame with
# x fwd, y left, z up. Used for frame-independent IoU of camera-frame boxes (evaluation).
T_ZUP_CAM = np.array(
    [[0.0, 0.0, 1.0, 0.0], [-1.0, 0.0, 0.0, 0.0], [0.0, -1.0, 0.0, 0.0], [0.0, 0.0, 0.0, 1.0]]
)

BOX7_FIELDS = ("x", "y", "z", "yaw", "l", "w", "h")


def cam_box_to_zup(loc, dims_hwl, ry: float, T_zup_cam: np.ndarray) -> np.ndarray:
    """KITTI camera box -> ``box7`` in the z-up frame given by ``T_zup_cam``."""
    h, w, l = (float(v) for v in dims_hwl)
    center_cam = np.asarray(loc, dtype=float) + np.array([0.0, -h / 2.0, 0.0])
    center = transform_points(T_zup_cam, center_cam)
    heading_cam = np.array([np.cos(ry), 0.0, -np.sin(ry)])
    heading = T_zup_cam[:3, :3] @ heading_cam
    yaw = float(np.arctan2(heading[1], heading[0]))
    return np.array([center[0], center[1], center[2], yaw, l, w, h])


def zup_box_to_cam(box7, T_cam_zup: np.ndarray):
    """``box7`` in a z-up frame -> KITTI camera box ``(loc, dims_hwl, ry)``."""
    x, y, z, yaw, l, w, h = (float(v) for v in box7)
    center_cam = transform_points(T_cam_zup, np.array([x, y, z]))
    heading_cam = T_cam_zup[:3, :3] @ np.array([np.cos(yaw), np.sin(yaw), 0.0])
    ry = float(wrap_angle(np.arctan2(-heading_cam[2], heading_cam[0])))
    loc = center_cam + np.array([0.0, h / 2.0, 0.0])
    return loc, np.array([h, w, l]), ry


def kitti_alpha(loc, ry: float) -> float:
    """Observation angle alpha = ry - atan2(x, z) (KITTI devkit convention)."""
    return float(wrap_angle(ry - np.arctan2(loc[0], loc[2])))


def cam_box_corners(loc, dims_hwl, ry: float) -> np.ndarray:
    """8 corners (8, 3) of a KITTI camera box, following the KITTI devkit ordering:
    0-3 bottom face, 4-7 top face; 0/1 are at +l/2 (front)."""
    h, w, l = dims_hwl
    xs = np.array([l, l, -l, -l, l, l, -l, -l]) / 2.0
    ys = np.array([0, 0, 0, 0, -h, -h, -h, -h], dtype=float)
    zs = np.array([w, -w, -w, w, w, -w, -w, w]) / 2.0
    return (rot_y(ry) @ np.vstack([xs, ys, zs])).T + np.asarray(loc, dtype=float)


def box7_corners(box7) -> np.ndarray:
    """8 corners (8, 3) of a z-up ``box7``: 0-3 bottom (CCW from front-left), 4-7 top."""
    x, y, z, yaw, l, w, h = box7
    c, s = np.cos(yaw), np.sin(yaw)
    xs = np.array([l, -l, -l, l]) / 2.0
    ys = np.array([w, w, -w, -w]) / 2.0
    bx, by = x + c * xs - s * ys, y + s * xs + c * ys
    bottom = np.column_stack([bx, by, np.full(4, z - h / 2.0)])
    top = np.column_stack([bx, by, np.full(4, z + h / 2.0)])
    return np.vstack([bottom, top])


def bev_polygon(box7) -> np.ndarray:
    """Counter-clockwise BEV footprint (4, 2) of a z-up ``box7``."""
    x, y, _, yaw, l, w, _ = box7
    c, s = np.cos(yaw), np.sin(yaw)
    xs = np.array([l, -l, -l, l]) / 2.0
    ys = np.array([w, w, -w, -w]) / 2.0
    # front-left, rear-left, rear-right, front-right -> CCW
    return np.column_stack([x + c * xs - s * ys, y + s * xs + c * ys])


def polygon_area(poly: np.ndarray) -> float:
    if len(poly) < 3:
        return 0.0
    x, y = poly[:, 0], poly[:, 1]
    return 0.5 * float(np.dot(x, np.roll(y, -1)) - np.dot(y, np.roll(x, -1)))


def convex_clip(subject: np.ndarray, clip: np.ndarray) -> np.ndarray:
    """Sutherland-Hodgman intersection of two convex CCW polygons."""
    out = subject
    n = len(clip)
    for i in range(n):
        if len(out) == 0:
            break
        a, b = clip[i], clip[(i + 1) % n]
        edge = b - a
        inp, out = out, []

        def inside(p):
            return edge[0] * (p[1] - a[1]) - edge[1] * (p[0] - a[0]) >= -1e-12

        def intersect(p, q):
            d = q - p
            denom = edge[0] * d[1] - edge[1] * d[0]
            t = (edge[1] * (p[0] - a[0]) - edge[0] * (p[1] - a[1])) / denom
            return p + t * d

        for j in range(len(inp)):
            cur, prev = inp[j], inp[j - 1]
            if inside(cur):
                if not inside(prev):
                    out.append(intersect(prev, cur))
                out.append(cur)
            elif inside(prev):
                out.append(intersect(prev, cur))
        out = np.array(out) if out else np.zeros((0, 2))
    return np.asarray(out).reshape(-1, 2)


def _bev_intersection(a, b) -> float:
    # quick reject on circumscribed circles
    ra = 0.5 * np.hypot(a[4], a[5])
    rb = 0.5 * np.hypot(b[4], b[5])
    if np.hypot(a[0] - b[0], a[1] - b[1]) > ra + rb:
        return 0.0
    return max(0.0, polygon_area(convex_clip(bev_polygon(a), bev_polygon(b))))


def iou_bev(a, b) -> float:
    """Rotated BEV IoU of two z-up ``box7``."""
    inter = _bev_intersection(a, b)
    if inter <= 0.0:
        return 0.0
    union = a[4] * a[5] + b[4] * b[5] - inter
    return float(inter / union) if union > 0 else 0.0


def iou_3d(a, b) -> float:
    """3D IoU of two z-up ``box7`` (rotated BEV overlap x vertical overlap)."""
    inter_bev = _bev_intersection(a, b)
    if inter_bev <= 0.0:
        return 0.0
    zmin = max(a[2] - a[6] / 2.0, b[2] - b[6] / 2.0)
    zmax = min(a[2] + a[6] / 2.0, b[2] + b[6] / 2.0)
    inter = inter_bev * max(0.0, zmax - zmin)
    if inter <= 0.0:
        return 0.0
    union = a[4] * a[5] * a[6] + b[4] * b[5] * b[6] - inter
    return float(inter / union) if union > 0 else 0.0


def iou_matrix(boxes_a, boxes_b, mode: str = "3d") -> np.ndarray:
    fn = {"3d": iou_3d, "bev": iou_bev}[mode]
    A, B = np.asarray(boxes_a, float).reshape(-1, 7), np.asarray(boxes_b, float).reshape(-1, 7)
    out = np.zeros((len(A), len(B)))
    for i, a in enumerate(A):
        for j, b in enumerate(B):
            out[i, j] = fn(a, b)
    return out


def points_in_box7(points: np.ndarray, box7) -> np.ndarray:
    """Boolean mask of (N, 3) z-up points inside a z-up ``box7``."""
    x, y, z, yaw, l, w, h = box7
    d = np.asarray(points, float)[:, :3] - np.array([x, y, z])
    c, s = np.cos(yaw), np.sin(yaw)
    lx = c * d[:, 0] + s * d[:, 1]
    ly = -s * d[:, 0] + c * d[:, 1]
    return (np.abs(lx) <= l / 2) & (np.abs(ly) <= w / 2) & (np.abs(d[:, 2]) <= h / 2)
