"""Rigid-body transform and angle utilities.

Naming convention used throughout the package: ``T_a_b`` is a 4x4 homogeneous matrix that
maps point coordinates expressed in frame ``b`` into frame ``a``:  ``p_a = T_a_b @ p_b``.
Composition therefore chains naturally: ``T_a_c = T_a_b @ T_b_c``.
"""

from __future__ import annotations

import numpy as np


def wrap_angle(a):
    """Wrap angle(s) to the half-open interval [-pi, pi)."""
    return (np.asarray(a, dtype=float) + np.pi) % (2.0 * np.pi) - np.pi


def rot_x(a: float) -> np.ndarray:
    c, s = np.cos(a), np.sin(a)
    return np.array([[1.0, 0.0, 0.0], [0.0, c, -s], [0.0, s, c]])


def rot_y(a: float) -> np.ndarray:
    c, s = np.cos(a), np.sin(a)
    return np.array([[c, 0.0, s], [0.0, 1.0, 0.0], [-s, 0.0, c]])


def rot_z(a: float) -> np.ndarray:
    c, s = np.cos(a), np.sin(a)
    return np.array([[c, -s, 0.0], [s, c, 0.0], [0.0, 0.0, 1.0]])


def make_se3(R: np.ndarray, t) -> np.ndarray:
    T = np.eye(4)
    T[:3, :3] = R
    T[:3, 3] = np.asarray(t, dtype=float).reshape(3)
    return T


def invert_se3(T: np.ndarray) -> np.ndarray:
    """Exact inverse of a rigid transform (R^T, -R^T t)."""
    R, t = T[:3, :3], T[:3, 3]
    Ti = np.eye(4)
    Ti[:3, :3] = R.T
    Ti[:3, 3] = -R.T @ t
    return Ti


def transform_points(T: np.ndarray, pts) -> np.ndarray:
    """Apply a 4x4 transform to an (N, 3) array (or a single (3,) point)."""
    pts = np.asarray(pts, dtype=float)
    single = pts.ndim == 1
    p = pts.reshape(-1, 3)
    out = p @ T[:3, :3].T + T[:3, 3]
    return out[0] if single else out
