"""Replay model built from *saved* tracker outputs (no tracking is re-run).

Source: ``results/<experiment>/frames/<seq>.jsonl`` written by ``trackscope.pipeline``.

Predicted-only (coasting) states
--------------------------------
The frozen configuration does not write coasting tracks to the result files
(``lifecycle.output_lost: false``), but the per-frame diagnostics record every lifecycle
transition: ``lost_now`` (confirmed track missed a frame), re-appearance in ``tracks`` (matched
again, same ID) and ``deleted``. Between those events the tracker only runs the Kalman
*prediction*, whose mean is exactly ``F x``: the last posterior centre advanced by the posterior
velocity times the elapsed time, with yaw and size unchanged. :func:`load_replay` reconstructs
those predicted states; ``tests/test_viz.py`` checks them against a live tracker run with
``output_lost=True`` on real data.

Tentative (unconfirmed) tracks are not part of the saved outputs and are not displayed.
"""

from __future__ import annotations

import csv
import json
from collections import defaultdict
from dataclasses import dataclass, field, replace
from pathlib import Path

import numpy as np


@dataclass(frozen=True)
class TrackState:
    track_id: int
    cls: str
    box: np.ndarray  # box7 world [x, y, z, yaw, l, w, h]
    velocity: np.ndarray  # (2,) world, m/s (ego-motion compensated)
    source: str  # "measured" (updated with a detection this frame) | "predicted" (coasting)
    status: str  # "confirmed" | "lost"
    score: float  # score of the last associated detection
    hits: int
    age: int
    time_since_update: int
    det_id: int
    pos_std: np.ndarray | None = None

    @property
    def speed(self) -> float:
        return float(np.hypot(*self.velocity))


@dataclass
class ReplayFrame:
    frame: int
    t: float
    T_world_rect: np.ndarray
    T_world_velo: np.ndarray
    detections: list[dict]
    tracks: list[TrackState]
    diagnostics: dict
    history: dict[int, list[tuple[int, np.ndarray, str]]] = field(default_factory=dict)  # id -> [(frame, xyz, source)]

    @property
    def measured(self) -> list[TrackState]:
        return [t for t in self.tracks if t.source == "measured"]

    @property
    def predicted(self) -> list[TrackState]:
        return [t for t in self.tracks if t.source == "predicted"]


def _state(d: dict) -> TrackState:
    return TrackState(track_id=d["id"], cls=d["cls"], box=np.array(d["box"], float),
                      velocity=np.array(d["velocity"], float), source=d["source"], status=d["status"],
                      score=float(d["score"]), hits=int(d["hits"]), age=int(d["age"]),
                      time_since_update=int(d["time_since_update"]), det_id=int(d["det_id"]),
                      pos_std=np.array(d["pos_std"], float) if "pos_std" in d else None)


def read_records(path: str | Path) -> list[dict]:
    with open(path) as f:
        recs = [json.loads(line) for line in f if line.strip()]
    frames = [r["frame"] for r in recs]
    if frames != list(range(len(recs))):
        raise ValueError(f"{path}: frames are not consecutive from 0")
    return recs


def build_replay(records: list[dict], history_len: int = 40) -> list[ReplayFrame]:
    """Records (JSON dicts, in frame order) -> frames with measured + reconstructed predicted states."""
    last_post: dict[int, tuple[int, float, TrackState]] = {}
    coasting: set[int] = set()
    hist: dict[int, list] = defaultdict(list)
    out = []
    for r in records:
        f, t, diag = r["frame"], float(r["t"]), r["diagnostics"]
        measured = {d["id"]: _state(d) for d in r["tracks"] if d["source"] == "measured"}
        coasting |= set(diag["lost_now"])
        coasting -= set(diag["deleted"])
        coasting -= set(measured)
        states = list(measured.values())
        for tid, s in measured.items():
            last_post[tid] = (f, t, s)
        for tid in sorted(coasting):
            if tid not in last_post:
                raise ValueError(f"frame {f}: track {tid} lost before it was ever output")
            f0, t0, s0 = last_post[tid]
            box = s0.box.copy()
            box[:2] = s0.box[:2] + s0.velocity * (t - t0)
            states.append(replace(s0, box=box, source="predicted", status="lost",
                                  time_since_update=f - f0, det_id=-1, age=s0.age + (f - f0)))
        for s in states:
            hist[s.track_id].append((f, s.box[:3].copy(), s.source))
        alive = {s.track_id for s in states}
        out.append(ReplayFrame(
            frame=f, t=t, T_world_rect=np.array(r["T_world_rect"], float).reshape(4, 4),
            T_world_velo=np.array(r["T_world_velo"], float).reshape(4, 4),
            detections=r["detections"], tracks=sorted(states, key=lambda s: s.track_id), diagnostics=diag,
            history={tid: list(hist[tid][-history_len:]) for tid in alive},
        ))
    return out


def load_replay(results_root: str | Path, experiment: str, seq: str, history_len: int = 40) -> list[ReplayFrame]:
    return build_replay(read_records(Path(results_root) / experiment / "frames" / f"{seq}.jsonl"), history_len)


# ---- evaluation events (annotations only; never alter displayed tracks) ----------------------
CAUSE_TEXT = {
    "detector_gap": "detector dropout > max_age: track terminated, object re-acquired with a new ID",
    "association_failure": "track lost although detections were available (association/gating failure)",
    "identity_swap": "old track still alive: association swapped identities",
    "parallel_track_takeover": "a duplicate track took over the object",
    "tracker_gap": "tracker gap although detections were available",
}


@dataclass(frozen=True)
class EvalEvent:
    kind: str  # IDSW | FRAG
    method: str
    cls: str
    frame: int
    gt_id: int
    old_track: int | None  # IDSW: previous tracker ID of this GT object
    new_track: int  # IDSW: new tracker ID; FRAG: re-acquiring track
    last_match_frame: int
    gap_frames: int
    cause: str

    def describe(self) -> str:
        why = CAUSE_TEXT.get(self.cause, self.cause)
        if self.kind == "IDSW":
            return (f"ID switch (eval): GT {self.cls} #{self.gt_id} was track {self.old_track} "
                    f"(last matched frame {self.last_match_frame}), now track {self.new_track}. Cause: {why}.")
        return (f"Fragmentation (eval): GT {self.cls} #{self.gt_id} re-acquired by track {self.new_track} "
                f"after {self.gap_frames} untracked frames. Cause: {why}.")


def load_events(failure_csv: str | Path, seq: str, method: str, iou_thr: float = 0.25,
                kinds: tuple[str, ...] = ("IDSW", "FRAG")) -> list[EvalEvent]:
    """Evaluation events of one sequence/method from ``results/evaluation/failure_cases.csv``."""
    path = Path(failure_csv)
    if not path.exists():
        return []
    out = []
    with open(path, newline="") as f:
        for r in csv.DictReader(f):
            if (r["type"] not in kinds or r["seq"] != seq or r["method"] != method
                    or abs(float(r["iou_thr"]) - iou_thr) > 1e-9):
                continue
            idsw = r["type"] == "IDSW"
            out.append(EvalEvent(
                kind=r["type"], method=method, cls=r["class"], frame=int(r["frame"]), gt_id=int(r["gt_id"]),
                old_track=int(r["old_track"]) if idsw else None,
                new_track=int(r["new_track"] if idsw else r["track"]),
                last_match_frame=int(r["last_match_frame"]), gap_frames=int(r["gap_frames"]), cause=r["cause"],
            ))
    return sorted(out, key=lambda e: (e.frame, e.kind, e.gt_id))
