"""Rerun logging of a saved TrackScope-3D run + the default blueprint.

Entity layout (timeline ``frame``)::

    world                         z-up world frame (ENU, origin = first IMU pose)
    world/ego                     Transform3D = T_world_velo (per frame)
      world/ego/lidar             Velodyne points (sensor frame, placed by the transform)
      world/ego/vehicle, axes     static ego body and axes
    world/ego_path                driven path so far
    world/detections              PointRCNN detections used by the tracker (grey)
    world/tracks/<id>             one entity per track: box + inspection values
      .../trail, .../velocity     history and velocity arrow
    world/events                  evaluation-event highlights (annotation only)
    world/ground_truth            optional GT boxes (--show-gt), never drawn as tracker output
    camera/image                  image_02 + projected track boxes
    bev/...                       ego-centred bird's-eye view (2D), one sub-tree per method
    diagnostics/...               per-frame text panel + time series (saved values only)
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
import rerun as rr
import rerun.blueprint as rrb

from ..data.kitti_tracking import KittiTrackingSequence
from ..geometry.transforms import transform_points
from .overlays import footprint_world, height_colors, id_color, project_box_edges, velo_to_bev, world_to_bev
from .replay import EvalEvent, ReplayFrame, TrackState, load_events, load_replay

METHOD_TAG = {"center": "C", "mahalanobis": "M", "iou": "I"}
METHOD_NAME = {"center": "Center-distance Hungarian", "mahalanobis": "Mahalanobis-gated Hungarian",
               "iou": "3D-IoU Hungarian"}
DET_COLOR = (150, 150, 150, 255)
EVENT_COLOR = (255, 40, 200, 255)
GT_COLOR = (255, 255, 255, 255)
EVENT_PERSIST = 5  # frames an event highlight stays visible


@dataclass
class ViewerConfig:
    seq: str = "0014"
    methods: list[str] = field(default_factory=lambda: ["mahalanobis"])  # first = primary (3D view)
    results_root: str = "results"
    kitti_root: str = "data/kitti_tracking"
    failure_csv: str = "results/evaluation/failure_cases.csv"
    event_iou_thr: float = 0.25
    frames: tuple[int, int] | None = None  # [start, end) ; None = all
    score_threshold: dict = field(default_factory=lambda: {"Car": 0.0, "Pedestrian": 0.0, "Cyclist": 0.0})
    show_gt: bool = False
    history_len: int = 40
    bev_lidar_z_min: float = -1.4  # velo frame; drops ground returns in the BEV only

    @property
    def primary(self) -> str:
        return self.methods[0]

    @property
    def compare(self) -> bool:
        return len(self.methods) > 1


def _rot(yaw: float):
    return rr.RotationAxisAngle(axis=(0.0, 0.0, 1.0), radians=float(yaw))


def track_label(s: TrackState, method: str, compare: bool, short: bool = False) -> str:
    tag = f"{METHOD_TAG[method]}{s.track_id}" if compare else f"ID {s.track_id}"
    if short:  # crowded comparison BEVs: identity + state only (details in 3D / selection panel)
        return f"{tag} PRED" if s.source == "predicted" else tag
    if s.source == "predicted":
        return f"{tag} {s.cls} PREDICTED (+{s.time_since_update})"
    return f"{tag} {s.cls} {s.speed:.1f} m/s"


class SequenceLogger:
    def __init__(self, cfg: ViewerConfig, rec: rr.RecordingStream):
        self.cfg, self.rec = cfg, rec
        self.seq = KittiTrackingSequence(cfg.kitti_root, cfg.seq)
        self.has_lidar, self.has_images = self.seq.has_velodyne(), self.seq.has_images()
        self.replays = {m: load_replay(cfg.results_root, f"pointrcnn_{m}", cfg.seq, cfg.history_len)
                        for m in cfg.methods}
        n = len(self.replays[cfg.primary])
        if n != self.seq.num_frames:
            raise ValueError(f"replay has {n} frames, sequence {cfg.seq} has {self.seq.num_frames}")
        for m, rp in self.replays.items():  # all runs must share the ego trajectory (same data)
            if not np.allclose(rp[0].T_world_velo, self.replays[cfg.primary][0].T_world_velo, atol=1e-5):
                raise ValueError(f"{m}: ego poses differ from {cfg.primary}")
        self.events = {m: load_events(cfg.failure_csv, cfg.seq, m, cfg.event_iou_thr) for m in cfg.methods}
        self.gt = None
        if cfg.show_gt or any(self.events.values()):
            from ..evaluation.ground_truth import load_ground_truth  # annotation only
            self.gt = load_ground_truth(Path(cfg.kitti_root) / "training" / "label_02" / f"{cfg.seq}.txt")
        self._alive: dict[str, set[int]] = {m: set() for m in cfg.methods}
        self._arrows: set[int] = set()

    # ------------------------------------------------------------------ static content
    def log_static(self) -> None:
        log = self.rec.log
        log("world", rr.ViewCoordinates.RIGHT_HAND_Z_UP, static=True)
        log("world/ego/vehicle", rr.Boxes3D(centers=[[-0.3, 0.0, -0.98]], sizes=[[4.5, 1.8, 1.5]],
                                            colors=[(235, 235, 235, 255)], radii=0.04, labels=["ego"],
                                            fill_mode=rr.components.FillMode.TransparentFillMajorWireframe),
            static=True)
        log("world/ego/axes", rr.Arrows3D(origins=np.zeros((3, 3)), vectors=np.eye(3) * 2.0,
                                          colors=[(230, 60, 60), (60, 200, 60), (60, 120, 240)], radii=0.05),
            static=True)
        rings = []
        for r in (10, 20, 30, 40, 50):
            a = np.linspace(0, 2 * np.pi, 121)
            rings.append(np.column_stack([r * np.cos(a), r * np.sin(a)]))
        log("bev/grid/rings", rr.LineStrips2D(rings, colors=[(70, 70, 75)], radii=0.06,
                                              labels=[f"{r} m" for r in (10, 20, 30, 40, 50)]), static=True)
        ego_fp = velo_to_bev(np.array([[1.95, 0.9], [1.95, -0.9], [-2.55, -0.9], [-2.55, 0.9], [1.95, 0.9]]))
        log("bev/ego", rr.LineStrips2D([ego_fp], colors=[(235, 235, 235)], radii=0.15, labels=["ego"]), static=True)
        log("bev/ego/heading", rr.Arrows2D(origins=[[0, 0]], vectors=[[0, -5]], colors=[(235, 235, 235)],
                                           radii=0.15), static=True)
        for k, (path, text) in enumerate(self._legend()):
            log(path, rr.TextDocument(text, media_type=rr.MediaType.MARKDOWN), static=True)

    def _legend(self):
        notes = [f"- **Sequence** {self.cfg.seq}, {self.seq.num_frames} frames at 10 Hz.",
                 f"- **Tracker output**: saved results of `pointrcnn_{self.cfg.primary}` "
                 "(not re-run; frozen Phase-2 configuration)."]
        if not (self.has_lidar and self.has_images):
            notes.append("- LiDAR/camera data not downloaded for this sequence: **tracks-and-detections replay**.")
        notes += [
            "- **Solid box** = state updated with a detection this frame. **Thin grey-tinted box `PREDICTED`** = "
            "confirmed track coasting on the Kalman prediction (no detection associated).",
            "- Grey boxes = PointRCNN detections used by the tracker. Colours are stable per track ID.",
            "- Magenta = evaluation event (ID switch / fragmentation from `failure_cases.csv`, 3D IoU "
            f"{self.cfg.event_iou_thr}); white = ground-truth annotation (analysis only).",
        ]
        if self.cfg.compare:
            notes.append("- Comparison: IDs are per tracker (prefix C/M/I) and **not comparable across methods**.")
        return [("diagnostics/legend", "### Legend\n" + "\n".join(notes))]

    # ------------------------------------------------------------------ per frame
    def log_frame(self, f: int) -> None:
        rec, cfg = self.rec, self.cfg
        rec.set_time("frame", sequence=f)
        fr = self.replays[cfg.primary][f]
        T = fr.T_world_velo
        rec.log("world/ego", rr.Transform3D(translation=T[:3, 3], mat3x3=T[:3, :3]))
        path = [r.T_world_velo[:3, 3] for r in self.replays[cfg.primary][: f + 1]]
        rec.log("world/ego_path", rr.LineStrips3D([np.array(path)], colors=[(235, 235, 235, 160)], radii=0.08))

        if self.has_lidar:
            pts = self.seq.load_velodyne(f)
            rec.log("world/ego/lidar", rr.Points3D(pts[:, :3], colors=height_colors(pts[:, 2]), radii=0.035))
            keep = (pts[:, 2] > cfg.bev_lidar_z_min) & (np.abs(pts[:, 0]) < 80) & (np.abs(pts[:, 1]) < 80)
            rec.log("bev/lidar", rr.Points2D(velo_to_bev(pts[keep]), colors=[(95, 105, 115)], radii=0.07))

        self._log_detections(fr)
        self._log_tracks_3d(fr)
        for m in cfg.methods:
            self._log_bev(m, self.replays[m][f])
        if self.has_images:
            self._log_camera(fr)
        self._log_events(f)
        if cfg.show_gt:
            self._log_gt(f, fr, "world/ground_truth")
        self._log_diagnostics(f)

    def _used_detections(self, fr: ReplayFrame) -> list[dict]:
        return [d for d in fr.detections if d["score"] >= self.cfg.score_threshold.get(d["cls"], np.inf)]

    def _log_detections(self, fr: ReplayFrame) -> None:
        dets = self._used_detections(fr)
        if not dets:
            self.rec.log("world/detections", rr.Clear(recursive=False))
            return
        b = np.array([d["box"] for d in dets])
        self.rec.log("world/detections", rr.Boxes3D(
            centers=b[:, :3], sizes=b[:, 4:7], rotation_axis_angles=[_rot(y) for y in b[:, 3]],
            colors=[DET_COLOR], radii=0.02, fill_mode=rr.components.FillMode.MajorWireframe))

    def _log_tracks_3d(self, fr: ReplayFrame) -> None:
        m, rec = self.cfg.primary, self.rec
        alive = {s.track_id for s in fr.tracks}
        for tid in self._alive[m] - alive:
            rec.log(f"world/tracks/{tid}", rr.Clear(recursive=True))
        self._alive[m] = alive
        for s in fr.tracks:
            base = f"world/tracks/{s.track_id}"
            pred = s.source == "predicted"
            col = id_color(s.track_id, m, predicted=pred)
            x, y, z, yaw, l, w, h = s.box
            rec.log(base, rr.Boxes3D(
                centers=[[x, y, z]], sizes=[[l, w, h]], rotation_axis_angles=[_rot(yaw)], colors=[col],
                radii=0.025 if pred else 0.06, labels=[track_label(s, m, False)], show_labels=True,
                fill_mode=(rr.components.FillMode.MajorWireframe if pred
                           else rr.components.FillMode.TransparentFillMajorWireframe)),
                rr.AnyValues(track_id=s.track_id, object_class=s.cls, association_method=m,
                             lifecycle_status=s.status, state_source=s.source,
                             speed_mps=round(s.speed, 3), velocity_world_mps=[round(v, 3) for v in s.velocity],
                             position_world_m=[round(v, 3) for v in s.box[:3]],
                             yaw_deg=round(float(np.degrees(yaw)), 2), size_lwh_m=[round(v, 3) for v in s.box[4:7]],
                             last_detection_score_logit=round(s.score, 3), hits=s.hits, age_frames=s.age,
                             frames_since_detection=s.time_since_update,
                             position_std_m=[] if s.pos_std is None else [round(v, 3) for v in s.pos_std]))
            hist = np.array([p for _, p, _ in fr.history[s.track_id]])
            if len(hist) > 1:
                rec.log(f"{base}/trail", rr.LineStrips3D([hist], colors=[id_color(s.track_id, m)], radii=0.07))
            if s.speed > 0.5:
                rec.log(f"{base}/velocity", rr.Arrows3D(origins=[[x, y, z + h / 2]], vectors=[[*s.velocity, 0.0]],
                                                        colors=[col], radii=0.06))
                self._arrows.add(s.track_id)
            elif s.track_id in self._arrows:
                rec.log(f"{base}/velocity", rr.Clear(recursive=False))
                self._arrows.discard(s.track_id)

    def _log_bev(self, m: str, fr: ReplayFrame) -> None:
        rec, T = self.rec, fr.T_world_velo
        base = f"bev/{m}"
        strips, cols, labels, radii, arrows_o, arrows_v, arrow_c, trails, trail_c = [], [], [], [], [], [], [], [], []
        for s in fr.tracks:
            pred = s.source == "predicted"
            strips.append(world_to_bev(footprint_world(s.box), T))
            cols.append(id_color(s.track_id, m, predicted=pred))
            labels.append(track_label(s, m, self.cfg.compare, short=self.cfg.compare))
            radii.append(0.08 if pred else 0.16)
            c = world_to_bev(s.box[None, :3], T)[0]
            if s.speed > 0.5:
                tip = world_to_bev(np.array([[s.box[0] + s.velocity[0], s.box[1] + s.velocity[1], s.box[2]]]), T)[0]
                arrows_o.append(c)
                arrows_v.append(tip - c)
                arrow_c.append(cols[-1])
            hist = fr.history[s.track_id]
            if len(hist) > 1:
                trails.append(world_to_bev(np.array([p for _, p, _ in hist]), T))
                trail_c.append(id_color(s.track_id, m))
        self._log_or_clear(f"{base}/tracks", rr.LineStrips2D(strips, colors=cols, radii=radii, labels=labels,
                                                             show_labels=True, draw_order=30), bool(strips))
        self._log_or_clear(f"{base}/velocity", rr.Arrows2D(origins=arrows_o, vectors=arrows_v, colors=arrow_c,
                                                           radii=0.12, draw_order=31), bool(arrows_o))
        self._log_or_clear(f"{base}/trails", rr.LineStrips2D(trails, colors=trail_c, radii=0.1, draw_order=29),
                           bool(trails))
        dets = self._used_detections(fr)
        self._log_or_clear(f"{base}/detections", rr.LineStrips2D(
            [world_to_bev(footprint_world(np.array(d["box"])), T) for d in dets], colors=[DET_COLOR], radii=0.05,
            draw_order=20), bool(dets))
        ev = [e for e in self.events[m] if e.frame <= fr.frame < e.frame + EVENT_PERSIST]
        hl, hl_lab = [], []
        by_id = {s.track_id: s for s in fr.tracks}
        for e in ev:
            for tid in {e.new_track, e.old_track} - {None}:
                if tid in by_id:
                    hl.append(world_to_bev(footprint_world(by_id[tid].box * [1, 1, 1, 1, 1.25, 1.25, 1]), T))
                    hl_lab.append(f"{e.kind} @{e.frame}")
        self._log_or_clear(f"{base}/events", rr.LineStrips2D(hl, colors=[EVENT_COLOR], radii=0.22, labels=hl_lab,
                                                             show_labels=True, draw_order=40), bool(hl))

    def _log_or_clear(self, path: str, archetype, present: bool) -> None:
        self.rec.log(path, archetype if present else rr.Clear(recursive=False))

    def _log_camera(self, fr: ReplayFrame) -> None:
        rec, m = self.rec, self.cfg.primary
        rec.log("camera/image", rr.EncodedImage(path=self.seq.image_path(fr.frame)))
        T_rect_world = np.linalg.inv(fr.T_world_rect)
        size = self.seq.image_size
        for src in ("measured", "predicted"):
            segs, cols, anchors, labels, acol = [], [], [], [], []
            for s in fr.tracks:
                if s.source != src:
                    continue
                e = project_box_edges(s.box, T_rect_world, self.seq.calib.P2, size)
                if not e:
                    continue
                col = id_color(s.track_id, m, predicted=src == "predicted")
                segs += e
                cols += [col] * len(e)
                a = np.vstack(e)
                anchors.append([a[:, 0].min(), a[:, 1].min()])
                labels.append(track_label(s, m, False))
                acol.append(col)
            path = f"camera/image/{src}"
            self._log_or_clear(path, rr.LineStrips2D(segs, colors=cols, radii=2.0 if src == "measured" else 1.0,
                                                     draw_order=10), bool(segs))
            self._log_or_clear(f"{path}_labels", rr.Points2D(anchors, colors=acol, radii=2.5, labels=labels,
                                                              show_labels=True, draw_order=11), bool(anchors))

    def _gt_boxes(self, f: int, fr: ReplayFrame, ids: set[int] | None = None):
        from ..geometry.boxes import cam_box_to_zup
        out = []
        for o in self.gt.get(f, []):
            if o.cls in ("Car", "Van", "Pedestrian", "Cyclist") and (ids is None or o.track_id in ids):
                out.append((o, cam_box_to_zup(o.loc, o.dims_hwl, o.ry, fr.T_world_rect)))
        return out

    def _log_gt(self, f: int, fr: ReplayFrame, path: str, ids: set[int] | None = None) -> None:
        boxes = self._gt_boxes(f, fr, ids)
        if not boxes:
            self.rec.log(path, rr.Clear(recursive=False))
            return
        b = np.array([x for _, x in boxes])
        self.rec.log(path, rr.Boxes3D(centers=b[:, :3], sizes=b[:, 4:7] * 1.02,
                                      rotation_axis_angles=[_rot(y) for y in b[:, 3]], colors=[GT_COLOR], radii=0.015,
                                      labels=[f"GT {o.cls} #{o.track_id}" for o, _ in boxes], show_labels=True,
                                      fill_mode=rr.components.FillMode.MajorWireframe))

    def _log_events(self, f: int) -> None:
        m, rec = self.cfg.primary, self.rec
        fr = self.replays[m][f]
        for e in self.events[m]:
            if e.frame == f:
                rec.log("events", rr.TextLog(f"[frame {f}] {e.describe()}",
                                             level="WARN" if e.kind == "IDSW" else "INFO"))
        active = [e for e in self.events[m] if e.frame <= f < e.frame + EVENT_PERSIST]
        by_id = {s.track_id: s for s in fr.tracks}
        boxes, labels = [], []
        for e in active:
            for tid in {e.new_track, e.old_track} - {None}:
                if tid in by_id:
                    boxes.append(by_id[tid].box)
                    labels.append(f"{e.kind} @frame {e.frame}: track {tid}")
        if boxes:
            b = np.array(boxes)
            rec.log("world/events", rr.Boxes3D(centers=b[:, :3], sizes=b[:, 4:7] * 1.15,
                                               rotation_axis_angles=[_rot(y) for y in b[:, 3]], colors=[EVENT_COLOR],
                                               radii=0.08, labels=labels, show_labels=True,
                                               fill_mode=rr.components.FillMode.MajorWireframe))
        else:
            rec.log("world/events", rr.Clear(recursive=False))
        if self.gt is not None and active:
            self._log_gt(f, fr, "world/events/gt", {e.gt_id for e in active})
        elif self.gt is not None:
            rec.log("world/events/gt", rr.Clear(recursive=False))

    def _log_diagnostics(self, f: int) -> None:
        rec, cfg = self.rec, self.cfg
        lines = [f"### Frame {f} / {self.seq.num_frames - 1}  ·  t = {self.seq.timestamp(f):.1f} s",
                 f"Sequence **{cfg.seq}**  ·  primary association: **{METHOD_NAME[cfg.primary]}**", ""]
        lines += ["| | " + " | ".join(METHOD_TAG[m] + ": " + m for m in cfg.methods) + " |",
                  "|---|" + "---|" * len(cfg.methods)]
        rows = Counter()
        cells: dict[str, list[str]] = {}
        for m in cfg.methods:
            fr = self.replays[m][f]
            d = fr.diagnostics
            rej = Counter(r["reason"] for r in d["rejections"])
            vals = {
                "confirmed, updated (solid)": str(len(fr.measured)),
                "predicted-only (coasting)": f"{len(fr.predicted)}" + (
                    f" ({', '.join(str(s.track_id) for s in fr.predicted)})" if fr.predicted else ""),
                "tentative (not drawn)": str(d["n_tentative"]),
                "new tracks born": str(len(d["born"])),
                "newly confirmed": ", ".join(map(str, d["confirmed_now"])) or "-",
                "lost this frame": ", ".join(map(str, d["lost_now"])) or "-",
                "terminated": ", ".join(map(str, d["deleted"])) or "-",
                "detections in / used": f"{d['n_detections_in']} / {d['n_detections_used']}",
                "associations": str(len(d["matches"])),
                "unmatched-track reasons": ", ".join(f"{k} {v}" for k, v in sorted(rej.items())) or "-",
                "tracker step (recorded)": f"{d['timing_ms']['total']:.2f} ms",
            }
            for k, v in vals.items():
                cells.setdefault(k, []).append(v)
            rows.update(vals.keys())
            rec.log(f"diagnostics/counts/{m}/confirmed_updated", rr.Scalars(len(fr.measured)))
            rec.log(f"diagnostics/counts/{m}/predicted_only", rr.Scalars(len(fr.predicted)))
            rec.log(f"diagnostics/counts/{m}/detections_used", rr.Scalars(d["n_detections_used"]))
            rec.log(f"diagnostics/latency_ms/{m}", rr.Scalars(d["timing_ms"]["total"]))
        for k, v in cells.items():
            lines.append(f"| {k} | " + " | ".join(v) + " |")
        lines.append("")
        lines.append("Latency = `MultiObjectTracker.step` time recorded during the tracking run "
                     "(not replay speed; detector inference excluded).")
        ev = [e for m in cfg.methods for e in self.events[m] if e.frame <= f < e.frame + EVENT_PERSIST]
        if ev:
            lines += ["", f"**Evaluation events (3D IoU {cfg.event_iou_thr})**"]
            lines += [f"- {METHOD_TAG[e.method]} · frame {e.frame}: {e.describe()}" for e in ev]
        rec.log("diagnostics/summary", rr.TextDocument("\n".join(lines), media_type=rr.MediaType.MARKDOWN))

    # ------------------------------------------------------------------ driver
    def frame_window(self) -> range:
        start, end = self.cfg.frames or (0, self.seq.num_frames)
        return range(max(0, start), min(end, self.seq.num_frames))

    def log_all(self) -> range:
        self.log_static()
        frames = self.frame_window()
        for m in self.cfg.methods:  # entities that may need clearing must start from the window
            self._alive[m] = set()
        for f in frames:
            self.log_frame(f)
        return frames


def build_blueprint(cfg: ViewerConfig, has_camera: bool, first_pose: np.ndarray,
                    image_size: tuple[int, int] = (1242, 375)) -> rrb.Blueprint:
    eye_pos = transform_points(first_pose, np.array([-22.0, 0.0, 14.0]))
    target = transform_points(first_pose, np.array([10.0, 0.0, 0.0]))
    main3d = rrb.Spatial3DView(
        origin="world", name=f"3D · LiDAR + tracks ({METHOD_NAME[cfg.primary]})",
        background=[12, 14, 18], line_grid=rrb.LineGrid3D(visible=False),
        eye_controls=rrb.EyeControls3D(position=eye_pos, look_target=target, eye_up=[0, 0, 1],
                                       tracking_entity="world/ego"))
    bounds = rrb.VisualBounds2D(x_range=[-32, 32], y_range=[-55, 18])
    bevs = [rrb.Spatial2DView(origin="bev", contents=["bev/grid/**", "bev/ego/**", "bev/lidar", f"bev/{m}/**"],
                              name=f"BEV · {METHOD_NAME[m]}", background=[12, 14, 18], visual_bounds=bounds)
            for m in cfg.methods]
    diag = rrb.Vertical(
        rrb.TextDocumentView(origin="diagnostics/summary", name="Tracking diagnostics"),
        rrb.TimeSeriesView(origin="diagnostics/counts", name="Track counts"),
        rrb.Tabs(rrb.TextLogView(origin="events", name="Evaluation events"),
                 rrb.TextDocumentView(origin="diagnostics/legend", name="Legend")),
        row_shares=[2.2, 1, 1])
    # Fixed bounds = the image itself: the view must not re-fit to overlay content every frame.
    camera = rrb.Spatial2DView(origin="camera", name="Camera 02 · projected tracks",
                               visual_bounds=rrb.VisualBounds2D(x_range=[0, image_size[0]], y_range=[0, image_size[1]]))
    if cfg.compare:
        left = rrb.Vertical(rrb.Horizontal(*bevs), main3d if not has_camera else rrb.Horizontal(main3d, camera),
                            row_shares=[1.3, 1])
    else:
        left = rrb.Vertical(main3d, camera, row_shares=[2.3, 1]) if has_camera else main3d
        left = rrb.Horizontal(left, bevs[0], column_shares=[2.4, 1])
    return rrb.Blueprint(
        rrb.Horizontal(left, diag, column_shares=[3.4, 1]),
        rrb.TimePanel(timeline="frame", fps=10.0, play_state="playing", loop_mode="all"),
        collapse_panels=False,
    )


def record(cfg: ViewerConfig, save_path: str | Path | None = None, spawn: bool = True) -> dict:
    rec = rr.RecordingStream(application_id="TrackScope-3D", recording_id=f"{cfg.seq}-{'-'.join(cfg.methods)}")
    logger = SequenceLogger(cfg, rec)
    first = logger.frame_window().start  # chase-camera start pose = first logged frame, not frame 0
    bp = build_blueprint(cfg, logger.has_images, logger.replays[cfg.primary][first].T_world_velo,
                         logger.seq.image_size)
    if save_path is not None:
        Path(save_path).parent.mkdir(parents=True, exist_ok=True)
        rec.save(save_path, default_blueprint=bp)
    elif spawn:
        rec.spawn(default_blueprint=bp)
    frames = logger.log_all()
    rec.flush()
    if save_path is not None:
        rec.disconnect()
    return {"frames": [frames.start, frames.stop], "has_lidar": logger.has_lidar, "has_images": logger.has_images,
            "events": {m: len(v) for m, v in logger.events.items()}}
