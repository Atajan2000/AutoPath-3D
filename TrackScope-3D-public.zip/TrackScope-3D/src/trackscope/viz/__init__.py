"""Visualisation of saved tracking runs.

``replay`` and ``overlays`` are pure Python/NumPy; ``rerun_view`` requires ``rerun-sdk``
(``pip install -e .[viz]``) and is imported explicitly by the launcher.
"""
