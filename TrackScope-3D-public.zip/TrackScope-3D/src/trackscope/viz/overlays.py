"""Pure-NumPy overlay geometry for the viewer: ID colours, camera projection, BEV transform."""

from __future__ import annotations

import colorsys
import hashlib

import numpy as np

from ..geometry.boxes import cam_box_corners, zup_box_to_cam

# ---- stable identity colours -----------------------------------------------------------------
GOLDEN = 0.6180339887498949


def id_color(track_id: int, salt: str = "", predicted: bool = False) -> tuple[int, int, int, int]:
    """Deterministic, well-spread RGBA colour for a track ID.

    Hue follows the golden-ratio sequence (consecutive IDs get very different hues); the salt
    (e.g. the association method) offsets it so that equal numeric IDs from independent trackers
    are *not* drawn in the same colour. Predicted-only states are desaturated and darker.
    """
    offset = int(hashlib.sha256(salt.encode()).hexdigest()[:8], 16) / 0xFFFFFFFF if salt else 0.0
    h = (track_id * GOLDEN + offset) % 1.0
    s, v = (0.25, 0.75) if predicted else (0.75, 1.0)
    r, g, b = colorsys.hsv_to_rgb(h, s, v)
    return int(r * 255), int(g * 255), int(b * 255), 255


# ---- camera projection ---------------------------------------------------------------------
# KITTI corner order (geometry.boxes.cam_box_corners): 0-3 bottom, 4-7 top, 0/1/5/4 = front face
BOX_EDGES = [(0, 1), (1, 2), (2, 3), (3, 0), (4, 5), (5, 6), (6, 7), (7, 4), (0, 4), (1, 5), (2, 6), (3, 7)]
FRONT_CROSS = [(0, 5), (1, 4)]


def project_box_edges(box7_world, T_rect_world: np.ndarray, P2: np.ndarray, image_size: tuple[int, int],
                      near: float = 0.1, front_cross: bool = True) -> list[np.ndarray]:
    """Image-space line segments (each (2, 2) in pixels) of a world-frame box.

    Edges are clipped against the near plane ``z_rect = near`` *in 3D* before projection, so
    boxes partly behind the camera are drawn correctly and boxes fully behind are dropped.
    Segments entirely outside the image are discarded.
    """
    loc, dims, ry = zup_box_to_cam(box7_world, T_rect_world)
    c = cam_box_corners(loc, dims, ry)
    w, h = image_size
    segs = []
    for i, j in BOX_EDGES + (FRONT_CROSS if front_cross else []):
        p, q = c[i].copy(), c[j].copy()
        if p[2] < near and q[2] < near:
            continue
        if p[2] < near:
            p = p + (near - p[2]) / (q[2] - p[2]) * (q - p)
        elif q[2] < near:
            q = q + (near - q[2]) / (p[2] - q[2]) * (p - q)
        pts = np.hstack([np.vstack([p, q]), np.ones((2, 1))]) @ P2.T
        uv = clip_segment_to_rect(pts[:, :2] / pts[:, 2:3], w, h)
        if uv is not None:
            segs.append(uv)
    return segs


def clip_segment_to_rect(uv: np.ndarray, w: float, h: float) -> np.ndarray | None:
    """Liang-Barsky clipping of a 2D segment (2, 2) to [0, w] x [0, h]; None if fully outside.

    Keeps every overlay inside the image so the camera view never has to re-fit its bounds
    (which made the panel appear to shake from frame to frame).
    """
    (x0, y0), (x1, y1) = uv
    dx, dy = x1 - x0, y1 - y0
    t0, t1 = 0.0, 1.0
    for p, q in ((-dx, x0), (dx, w - x0), (-dy, y0), (dy, h - y0)):
        if abs(p) < 1e-12:
            if q < 0:
                return None
            continue
        r = q / p
        if p < 0:
            t0 = max(t0, r)
        else:
            t1 = min(t1, r)
        if t0 > t1:
            return None
    return np.array([[x0 + t0 * dx, y0 + t0 * dy], [x0 + t1 * dx, y0 + t1 * dy]])


def segments_bbox(segs: list[np.ndarray]) -> np.ndarray | None:
    if not segs:
        return None
    a = np.vstack(segs)
    return np.array([a[:, 0].min(), a[:, 1].min(), a[:, 0].max(), a[:, 1].max()])


# ---- bird's-eye view in the ego frame ------------------------------------------------------
def world_to_bev(points_world: np.ndarray, T_world_velo: np.ndarray) -> np.ndarray:
    """World xy(z) -> 2D BEV pixels-as-metres in the ego (LiDAR) frame.

    BEV axes: u = right of the vehicle (-y_velo), v = backwards (-x_velo). Rerun 2D views have
    y pointing down, so the driving direction points *up* on screen.
    """
    p = np.atleast_2d(np.asarray(points_world, float))
    if p.shape[1] == 2:
        p = np.hstack([p, np.zeros((len(p), 1))])
    T = np.linalg.inv(T_world_velo)
    v = p[:, :3] @ T[:3, :3].T + T[:3, 3]
    return np.column_stack([-v[:, 1], -v[:, 0]])


def velo_to_bev(points_velo: np.ndarray) -> np.ndarray:
    return np.column_stack([-points_velo[:, 1], -points_velo[:, 0]])


def footprint_world(box7) -> np.ndarray:
    """Closed BEV footprint polygon (5, 3) in world coordinates (front edge first)."""
    x, y, z, yaw, l, w, _ = box7
    c, s = np.cos(yaw), np.sin(yaw)
    lx = np.array([l, l, -l, -l, l]) / 2
    ly = np.array([w, -w, -w, w, w]) / 2
    return np.column_stack([x + c * lx - s * ly, y + s * lx + c * ly, np.full(5, z)])


# ---- LiDAR colouring -----------------------------------------------------------------------
_HEIGHT_STOPS = np.array([[0.0, 40, 52, 74], [0.45, 70, 110, 140], [0.8, 150, 190, 205], [1.0, 225, 235, 240]])


def height_colors(z: np.ndarray, z_min: float = -2.0, z_max: float = 1.5) -> np.ndarray:
    """Muted blue-grey ramp by height (keeps the coloured tracks visually dominant)."""
    u = np.clip((np.asarray(z) - z_min) / (z_max - z_min), 0, 1)
    out = np.empty((len(u), 3), np.uint8)
    for k in range(3):
        out[:, k] = np.interp(u, _HEIGHT_STOPS[:, 0], _HEIGHT_STOPS[:, k + 1]).astype(np.uint8)
    return out
