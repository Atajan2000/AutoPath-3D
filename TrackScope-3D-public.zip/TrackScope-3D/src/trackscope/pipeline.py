"""Run the tracker over KITTI Tracking sequences and write result files.

Per sequence, three outputs are written to ``<output_dir>/<experiment>/``:

``kitti/<seq>.txt``    tracker output in KITTI Tracking result format, boxes converted back to
                       the rectified camera frame of each frame (for evaluation)::
                           frame id type trunc occ alpha x1 y1 x2 y2 h w l x y z ry score
``frames/<seq>.jsonl`` one JSON object per frame: ego pose, input detections (world frame),
                       tracker outputs with source/status/velocity, and diagnostics (for
                       analysis and the replay viewer)
``summary.json``       configuration, per-sequence statistics and tracker timing

This module uses detector outputs only; it does not import ``trackscope.evaluation``.
"""

from __future__ import annotations

import json
import time
from dataclasses import asdict
from pathlib import Path

import numpy as np

from .config import ExperimentConfig, config_to_dict
from .data.detections import load_sequence_detections, to_tracking_detections
from .data.kitti_tracking import KittiTrackingSequence
from .geometry.boxes import cam_box_corners, kitti_alpha, zup_box_to_cam
from .tracking.tracker import FrameResult, MultiObjectTracker


def project_bbox2d(seq: KittiTrackingSequence, loc, dims_hwl, ry) -> np.ndarray | None:
    """Image-space 2D box (clipped) of a camera-frame 3D box, or None if not in view."""
    corners = cam_box_corners(loc, dims_hwl, ry)
    uv, depth = seq.calib.project_rect_to_image(corners)
    front = depth > 0.1
    if not front.any():
        return None
    w, h = seq.image_size
    x1, y1 = uv[front].min(0)
    x2, y2 = uv[front].max(0)
    x1, x2 = np.clip([x1, x2], 0, w - 1)
    y1, y2 = np.clip([y1, y2], 0, h - 1)
    if x2 - x1 < 1 or y2 - y1 < 1:
        return None
    return np.array([x1, y1, x2, y2])


def _r(a, n=4):
    return [round(float(v), n) for v in np.asarray(a).ravel()]


def frame_record(seq: KittiTrackingSequence, res: FrameResult, dets) -> dict:
    d = asdict(res.diagnostics)
    d["timing_ms"] = {k: round(v, 4) for k, v in d["timing_ms"].items()}
    d["det_scores"] = _r(d["det_scores"], 3)
    for m in d["matches"]:
        m["cost"] = round(m["cost"], 4)
    return {
        "frame": res.frame,
        "t": res.t,
        "T_world_rect": _r(seq.T_world_rect[res.frame], 6),
        "T_world_velo": _r(seq.T_world_velo[res.frame], 6),
        "detections": [{"det_id": x.det_id, "cls": x.cls, "score": round(x.score, 3),
                        "box": _r(x.box)} for x in dets],
        "tracks": [{
            "id": o.track_id, "cls": o.cls, "status": o.status, "source": o.source,
            "box": _r(o.box), "velocity": _r(o.velocity), "speed": round(float(np.hypot(*o.velocity)), 3),
            "pos_std": _r(o.pos_std), "score": round(o.score, 3), "hits": o.hits, "age": o.age,
            "time_since_update": o.time_since_update, "det_id": o.det_id,
        } for o in res.tracks],
        "diagnostics": d,
    }


def kitti_rows(seq: KittiTrackingSequence, res: FrameResult) -> list[str]:
    T_rect_world = np.linalg.inv(seq.T_world_rect[res.frame])
    rows = []
    for o in res.tracks:
        loc, dims, ry = zup_box_to_cam(o.box, T_rect_world)
        if loc[2] <= 0.1:  # behind the camera: not representable in KITTI image-based format
            continue
        bb = project_bbox2d(seq, loc, dims, ry)
        if bb is None:
            continue
        rows.append(
            f"{res.frame} {o.track_id} {o.cls} -1 -1 {kitti_alpha(loc, ry):.6f} "
            f"{bb[0]:.2f} {bb[1]:.2f} {bb[2]:.2f} {bb[3]:.2f} "
            f"{dims[0]:.4f} {dims[1]:.4f} {dims[2]:.4f} {loc[0]:.4f} {loc[1]:.4f} {loc[2]:.4f} "
            f"{ry:.6f} {o.score:.4f}"
        )
    return rows


def _latency_stats(lat_s: list[float]) -> dict:
    a = np.asarray(lat_s) * 1e3
    if a.size == 0:
        return {}
    return {"mean_ms": float(a.mean()), "median_ms": float(np.median(a)),
            "p95_ms": float(np.percentile(a, 95)), "max_ms": float(a.max())}


def run_sequence(cfg: ExperimentConfig, seq_id: str, out_root: Path | None = None) -> dict:
    """Run one sequence. Timing is split into stages; ``tracker_*`` covers only
    ``MultiObjectTracker.step`` (detector inference is not part of this pipeline)."""
    t_load = time.perf_counter()
    seq = KittiTrackingSequence(cfg.data.kitti_root, seq_id, cfg.data.split)
    cam_dets = load_sequence_detections(cfg.data.detections_root, seq_id, list(cfg.tracker.classes))
    load_s = time.perf_counter() - t_load
    tracker = MultiObjectTracker(cfg.tracker)
    rows, records = [], []
    step_lat, convert_s, format_s = [], 0.0, 0.0
    n_det_in = 0
    track_ids, confirmed_ids = set(), set()
    t_wall = time.perf_counter()
    for frame in range(seq.num_frames):
        t0 = time.perf_counter()
        dets = to_tracking_detections(cam_dets.get(frame, []), seq.T_world_rect[frame])
        t1 = time.perf_counter()
        res = tracker.step(frame, seq.timestamp(frame), dets)
        t2 = time.perf_counter()
        n_det_in += len(dets)
        track_ids.update(res.diagnostics.born)
        confirmed_ids.update(o.track_id for o in res.tracks)
        rows.extend(kitti_rows(seq, res))
        records.append(frame_record(seq, res, dets))
        convert_s += t1 - t0
        step_lat.append(t2 - t1)
        format_s += time.perf_counter() - t2
    loop_s = time.perf_counter() - t_wall
    step_s = float(sum(step_lat))
    unknown_frames = sorted(f for f in cam_dets if f >= seq.num_frames)
    if unknown_frames:
        raise ValueError(f"seq {seq_id}: detections for frames beyond sequence end: {unknown_frames[:5]}")

    stats = {
        "sequence": seq_id,
        "frames": seq.num_frames,
        "detections_in": n_det_in,
        "detections_used": int(sum(r["diagnostics"]["n_detections_used"] for r in records)),
        "tracks_born": len(track_ids),
        "tracks_confirmed": len(confirmed_ids),
        "output_rows_kitti": len(rows),
        "mean_confirmed_per_frame": float(np.mean([r["diagnostics"]["n_confirmed"] for r in records])),
        "tracker_time_s": step_s,
        "tracker_fps": seq.num_frames / step_s if step_s > 0 else float("inf"),
        "tracker_step_latency": _latency_stats(step_lat),
        "_step_latencies_s": step_lat,
    }
    write_s = 0.0
    if out_root is not None:
        t_w = time.perf_counter()
        (out_root / "kitti").mkdir(parents=True, exist_ok=True)
        (out_root / "frames").mkdir(parents=True, exist_ok=True)
        (out_root / "kitti" / f"{seq_id}.txt").write_text("\n".join(rows) + ("\n" if rows else ""))
        with open(out_root / "frames" / f"{seq_id}.jsonl", "w") as f:
            for r in records:
                f.write(json.dumps(r, separators=(",", ":")) + "\n")
        write_s = time.perf_counter() - t_w
    stats["stage_time_s"] = {
        "load_calib_oxts_detections": load_s,
        "convert_detections_to_world": convert_s,
        "tracker_step": step_s,
        "format_outputs": format_s,
        "write_outputs": write_s,
        "end_to_end_excl_detector": load_s + loop_s + write_s,
    }
    stats["end_to_end_fps_excl_detector"] = seq.num_frames / stats["stage_time_s"]["end_to_end_excl_detector"]
    return stats


def run_experiment(cfg: ExperimentConfig, sequences: list[str] | None = None) -> dict:
    out_root = Path(cfg.output_dir) / cfg.name
    out_root.mkdir(parents=True, exist_ok=True)
    seqs = list(sequences or cfg.data.sequences)
    per_seq = [run_sequence(cfg, s, out_root) for s in seqs]
    total_frames = sum(s["frames"] for s in per_seq)
    total_time = sum(s["tracker_time_s"] for s in per_seq)
    all_lat = [x for s in per_seq for x in s.pop("_step_latencies_s")]
    e2e = sum(s["stage_time_s"]["end_to_end_excl_detector"] for s in per_seq)
    summary = {
        "experiment": cfg.name,
        "detector": cfg.data.detector_name,
        "sequences": per_seq,
        "total_frames": total_frames,
        "tracker_fps_overall": total_frames / total_time if total_time > 0 else None,
        "tracker_step_latency_overall": _latency_stats(all_lat),
        "end_to_end_fps_excl_detector": total_frames / e2e if e2e > 0 else None,
        "timing_note": "tracker_* = MultiObjectTracker.step only. end_to_end_excl_detector adds "
                       "file loading, frame conversion, output formatting and writing. Detector "
                       "inference is NOT included (precomputed PointRCNN outputs).",
        "config": config_to_dict(cfg),
    }
    (out_root / "summary.json").write_text(json.dumps(summary, indent=2, default=str))
    return summary
