"""YAML experiment configuration -> typed config objects."""

from __future__ import annotations

import copy
from dataclasses import asdict, dataclass, field, fields
from pathlib import Path

import yaml

from .tracking.association import AssociationConfig
from .tracking.kalman import KalmanParams
from .tracking.tracker import LifecycleConfig, TrackerConfig


@dataclass(frozen=True)
class DataConfig:
    kitti_root: str = "data/kitti_tracking"
    detections_root: str = "data/detections/pointrcnn"
    detector_name: str = "pointrcnn"
    split: str = "training"
    sequences: tuple[str, ...] = ("0014",)


@dataclass(frozen=True)
class ExperimentConfig:
    name: str = "default"
    data: DataConfig = field(default_factory=DataConfig)
    tracker: TrackerConfig = field(default_factory=TrackerConfig)
    output_dir: str = "results"
    raw: dict = field(default_factory=dict, compare=False, repr=False)


def _build(cls, d: dict | None):
    d = dict(d or {})
    known = {f.name for f in fields(cls)}
    unknown = set(d) - known
    if unknown:
        raise ValueError(f"unknown {cls.__name__} keys: {sorted(unknown)}")
    return cls(**d)


def tracker_config_from_dict(d: dict) -> TrackerConfig:
    d = copy.deepcopy(d or {})
    base_kf = d.pop("kalman_default", {}) or {}
    kalman = {"default": _build(KalmanParams, base_kf)}
    for cls_name, params in (d.pop("kalman", {}) or {}).items():
        kalman[cls_name] = _build(KalmanParams, {**base_kf, **(params or {})})
    assoc = _build(AssociationConfig, d.pop("association", {}))
    life = _build(LifecycleConfig, d.pop("lifecycle", {}))
    if "classes" in d:
        d["classes"] = tuple(d["classes"])
    return _build(TrackerConfig, {**d, "kalman": kalman, "association": assoc, "lifecycle": life})


def load_config(path: str | Path, overrides: dict | None = None) -> ExperimentConfig:
    raw = yaml.safe_load(Path(path).read_text()) or {}
    for dotted, value in (overrides or {}).items():
        node = raw
        *parents, leaf = dotted.split(".")
        for k in parents:
            node = node.setdefault(k, {})
        node[leaf] = value
    data = dict(raw.get("data", {}))
    if "sequences" in data:
        data["sequences"] = tuple(f"{int(s):04d}" for s in data["sequences"])
    return ExperimentConfig(
        name=raw.get("name", Path(path).stem),
        data=_build(DataConfig, data),
        tracker=tracker_config_from_dict(raw.get("tracker", {})),
        output_dir=raw.get("output_dir", "results"),
        raw=raw,
    )


def config_to_dict(cfg: ExperimentConfig) -> dict:
    out = asdict(cfg)
    out.pop("raw", None)
    return out
