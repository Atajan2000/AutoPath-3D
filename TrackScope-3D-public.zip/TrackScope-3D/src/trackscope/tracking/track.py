"""Single-track state and lifecycle.

Lifecycle::

    birth --> TENTATIVE --(min_hits consecutive hits)--> CONFIRMED <--(hit)-- LOST
                 |                                          |                  |
             (any miss)                                  (miss)      (misses > max_age)
                 v                                          v                  v
              DELETED                                      LOST             DELETED

* ``TENTATIVE`` tracks need ``min_hits`` consecutive matched frames (including the birth
  frame) to be confirmed; a single miss deletes them (suppresses one-off false positives).
* ``CONFIRMED`` tracks that miss a frame become ``LOST`` and coast on the motion model.
* ``LOST`` tracks are re-confirmed by a match (same ID) or deleted after more than
  ``max_age`` consecutive misses.

Every history entry records whether it came from a measurement update (``measured``) or from
motion-model prediction alone (``predicted``).
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from enum import Enum

import numpy as np

from . import kalman as kf
from ..types import Detection


class TrackStatus(str, Enum):
    TENTATIVE = "tentative"
    CONFIRMED = "confirmed"
    LOST = "lost"
    DELETED = "deleted"


@dataclass(frozen=True)
class HistoryEntry:
    frame: int
    t: float
    box: np.ndarray  # box7 posterior (measured) or prediction (predicted)
    velocity: np.ndarray  # (2,) world-frame vx, vy
    source: str  # "measured" | "predicted"


class Track:
    def __init__(self, track_id: int, det: Detection, frame: int, t: float,
                 params: kf.KalmanParams, history_len: int = 50):
        self.id = track_id
        self.cls = det.cls
        self.params = params
        self.x, self.P = kf.initiate(det.box, params)
        self.status = TrackStatus.TENTATIVE
        self.birth_frame = frame
        self.hits = 1
        self.hit_streak = 1
        self.age = 1  # frames since birth (inclusive)
        self.time_since_update = 0  # consecutive missed frames
        self.last_t = t
        self.last_meas_t = t
        self.last_meas_pos = det.box[:3].copy()
        self.score = det.score
        self.last_det_id = det.det_id
        self.yaw_flips = 0
        self.last_nis: float | None = None
        self.last_innovation: np.ndarray | None = None
        self.history: deque[HistoryEntry] = deque(maxlen=history_len)
        self._record(frame, "measured")

    # -- views -------------------------------------------------------------------------------
    @property
    def box(self) -> np.ndarray:
        return np.concatenate([self.x[0:3], [self.x[kf.IDX_YAW]], self.x[kf.IDX_DIM]])

    @property
    def velocity(self) -> np.ndarray:
        return self.x[kf.IDX_VEL].copy()

    @property
    def is_active(self) -> bool:
        return self.status is not TrackStatus.DELETED

    def _record(self, frame: int, source: str) -> None:
        self.history.append(HistoryEntry(frame, self.last_t, self.box, self.velocity, source))

    # -- filter steps ------------------------------------------------------------------------
    def predict(self, t: float) -> None:
        dt = t - self.last_t
        self.x, self.P = kf.predict(self.x, self.P, dt, self.params)
        self.last_t = t
        self.age += 1

    def update(self, det: Detection, frame: int, min_hits: int) -> None:
        self.x, self.P, y, S, flipped = kf.update(self.x, self.P, det.box, self.params)
        self.last_nis = float(y @ np.linalg.solve(S, y))
        self.last_innovation = y  # measurement - prediction (yaw wrapped / flip-corrected)
        self.yaw_flips += int(flipped)
        self.hits += 1
        self.hit_streak += 1
        self.time_since_update = 0
        self.last_meas_t = self.last_t
        self.last_meas_pos = det.box[:3].copy()
        self.score = det.score
        self.last_det_id = det.det_id
        if self.status is TrackStatus.LOST or (
            self.status is TrackStatus.TENTATIVE and self.hit_streak >= min_hits
        ):
            self.status = TrackStatus.CONFIRMED
        self._record(frame, "measured")

    def mark_missed(self, frame: int, max_age: int) -> None:
        self.time_since_update += 1
        self.hit_streak = 0
        self.last_det_id = -1
        if self.status is TrackStatus.TENTATIVE or self.time_since_update > max_age:
            self.status = TrackStatus.DELETED
            return
        self.status = TrackStatus.LOST
        self._record(frame, "predicted")
