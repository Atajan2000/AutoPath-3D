"""Constant-velocity 3D Kalman filter for box tracking in a z-up world frame.

State (9):        x = [px, py, pz, vx, vy, yaw, l, w, h]
Measurement (7):  z = [px, py, pz, yaw, l, w, h]      (a detected box, geometric centre)

Motion model (time step dt, variable):
    px' = px + vx dt,  py' = py + vy dt         constant velocity in the ground plane
    pz, yaw, l, w, h                              random walks
Vertical velocity is not modelled: in the gravity-aligned world frame road objects stay on
the ground plane, and the detector's z noise would otherwise be integrated as fake motion.

Process noise is the exact discretisation of continuous white-noise acceleration with power
spectral density q = sigma_acc^2 [m^2/s^3] per ground axis:
    Q_[p,v] = q * [[dt^3/3, dt^2/2], [dt^2/2, dt]]
and ``sigma^2 * dt`` for the random-walk components. Unlike the piecewise-constant
(dt^4/4, dt^3/2, dt^2) form, this composes exactly - predicting once over 2*dt gives the same
covariance as two predictions over dt - so irregular frame gaps are handled consistently.

Orientation: yaw is wrapped to [-pi, pi) after every predict/update and the yaw innovation is
wrapped. 3D detectors often confuse an object's front and back, which produces a yaw jump of
~pi; when the wrapped innovation exceeds pi/2 the measured yaw is flipped by pi before the
update (the box itself is symmetric under this flip). The covariance update uses the Joseph
form for numerical stability.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from ..geometry.transforms import wrap_angle

STATE_DIM, MEAS_DIM = 9, 7
IDX_POS, IDX_VEL, IDX_YAW, IDX_DIM = slice(0, 3), slice(3, 5), 5, slice(6, 9)
YAW_MEAS = 3  # index of yaw in the measurement vector

H = np.zeros((MEAS_DIM, STATE_DIM))
H[0:3, 0:3] = np.eye(3)  # position
H[3, IDX_YAW] = 1.0
H[4:7, 6:9] = np.eye(3)  # dimensions


@dataclass(frozen=True)
class KalmanParams:
    sigma_acc: float = 3.0  # m/s^(3/2), sqrt of acceleration-noise PSD (ground plane)
    sigma_z: float = 0.1  # m/sqrt(s), vertical random walk
    sigma_yaw: float = 0.3  # rad/sqrt(s), heading random walk
    sigma_dim: float = 0.02  # m/sqrt(s), size random walk (rigid objects)
    meas_pos: float = 0.25  # m, detector centre std (x, y)
    meas_z: float = 0.2  # m
    meas_yaw: float = 0.2  # rad
    meas_dim: float = 0.15  # m
    init_vel: float = 10.0  # m/s, prior std of the unknown initial velocity

    @property
    def R(self) -> np.ndarray:
        return np.diag(
            [self.meas_pos, self.meas_pos, self.meas_z, self.meas_yaw,
             self.meas_dim, self.meas_dim, self.meas_dim]
        ) ** 2


def transition(dt: float) -> np.ndarray:
    F = np.eye(STATE_DIM)
    F[0, 3] = F[1, 4] = dt
    return F


def process_noise(dt: float, p: KalmanParams) -> np.ndarray:
    Q = np.zeros((STATE_DIM, STATE_DIM))
    qa = p.sigma_acc**2
    for pi, vi in ((0, 3), (1, 4)):
        Q[pi, pi] = qa * dt**3 / 3.0
        Q[pi, vi] = Q[vi, pi] = qa * dt**2 / 2.0
        Q[vi, vi] = qa * dt
    Q[2, 2] = p.sigma_z**2 * dt
    Q[IDX_YAW, IDX_YAW] = p.sigma_yaw**2 * dt
    for i in range(6, 9):
        Q[i, i] = p.sigma_dim**2 * dt
    return Q


def initiate(z: np.ndarray, p: KalmanParams) -> tuple[np.ndarray, np.ndarray]:
    """State and covariance from a first detection (velocity unknown, zero-mean prior)."""
    x = np.zeros(STATE_DIM)
    x[0:3] = z[0:3]
    x[IDX_YAW] = wrap_angle(z[YAW_MEAS])
    x[IDX_DIM] = z[4:7]
    P = np.zeros((STATE_DIM, STATE_DIM))
    P[np.ix_([0, 1, 2, 5, 6, 7, 8], [0, 1, 2, 5, 6, 7, 8])] = p.R
    P[3, 3] = P[4, 4] = p.init_vel**2
    return x, P


def predict(x: np.ndarray, P: np.ndarray, dt: float, p: KalmanParams):
    if dt < 0:
        raise ValueError(f"negative time step {dt}")
    F = transition(dt)
    x = F @ x
    x[IDX_YAW] = wrap_angle(x[IDX_YAW])
    P = F @ P @ F.T + process_noise(dt, p)
    return x, 0.5 * (P + P.T)


def innovation(x: np.ndarray, P: np.ndarray, z: np.ndarray, p: KalmanParams):
    """Innovation y (with yaw wrapping and front/back flip), its covariance S, flip flag."""
    y = z - H @ x
    y[YAW_MEAS] = wrap_angle(y[YAW_MEAS])
    flipped = bool(abs(y[YAW_MEAS]) > np.pi / 2)
    if flipped:
        y[YAW_MEAS] = wrap_angle(y[YAW_MEAS] + np.pi)
    S = H @ P @ H.T + p.R
    return y, S, flipped


def update(x: np.ndarray, P: np.ndarray, z: np.ndarray, p: KalmanParams):
    """Kalman update. Returns (x, P, y, S, flipped)."""
    y, S, flipped = innovation(x, P, z, p)
    K = np.linalg.solve(S, H @ P).T  # P H^T S^-1 (S, P symmetric)
    x = x + K @ y
    x[IDX_YAW] = wrap_angle(x[IDX_YAW])
    IKH = np.eye(STATE_DIM) - K @ H
    P = IKH @ P @ IKH.T + K @ p.R @ K.T
    return x, 0.5 * (P + P.T), y, S, flipped


def position_innovation_cov(P: np.ndarray, p: KalmanParams) -> np.ndarray:
    """3x3 innovation covariance of the measured 3D centre (used for Mahalanobis gating)."""
    return P[0:3, 0:3] + p.R[0:3, 0:3]
