"""Online multi-object tracker: predict -> associate -> update -> manage lifecycle.

The tracker is frame-source agnostic: :meth:`MultiObjectTracker.step` takes a timestamp and a
list of world-frame :class:`~trackscope.types.Detection` and returns the tracker output for
that instant. It has no knowledge of KITTI, files, visualisation or annotations, so the same
core can later sit behind a ROS 2 node (detections topic in, tracked-objects topic out).
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field

import numpy as np

from . import kalman as kf
from .association import AssociationConfig, AssociationResult, TrackPrediction, associate
from .track import Track, TrackStatus
from ..types import Detection


@dataclass(frozen=True)
class LifecycleConfig:
    min_hits: int = 3
    max_age: int = 2  # frames a confirmed track may coast before deletion
    birth_min_score: float = -np.inf  # extra threshold for spawning tracks
    output_lost: bool = False  # also report coasting (predicted-only) confirmed tracks
    history_len: int = 50


@dataclass(frozen=True)
class TrackerConfig:
    classes: tuple[str, ...] = ("Car", "Pedestrian", "Cyclist")
    score_threshold: dict = field(default_factory=lambda: {"Car": 0.0, "Pedestrian": 0.0, "Cyclist": 0.0})
    kalman: dict = field(default_factory=lambda: {"Car": kf.KalmanParams()})  # cls -> KalmanParams
    association: AssociationConfig = field(default_factory=AssociationConfig)
    lifecycle: LifecycleConfig = field(default_factory=LifecycleConfig)

    def kalman_for(self, cls: str) -> kf.KalmanParams:
        return self.kalman.get(cls) or self.kalman.get("default") or kf.KalmanParams()


@dataclass(frozen=True)
class TrackOutput:
    track_id: int
    cls: str
    status: str
    box: np.ndarray  # box7, world frame
    velocity: np.ndarray  # (2,) world frame, m/s (ego-motion compensated)
    pos_std: np.ndarray  # (3,) posterior std of the centre
    score: float  # score of the last associated detection
    source: str  # "measured" (updated this frame) | "predicted" (coasting)
    hits: int
    age: int
    time_since_update: int
    det_id: int  # detection index matched this frame, -1 if none


@dataclass
class FrameDiagnostics:
    frame: int
    t: float
    n_detections_in: int
    n_detections_used: int
    n_tentative: int
    n_confirmed: int
    n_lost: int
    born: list[int]
    confirmed_now: list[int]
    lost_now: list[int]
    deleted: list[int]
    matches: list[dict]  # {track_id, det_id, cost}
    rejections: list[dict]  # {track_id, det_id, reason}
    det_scores: list[float]
    timing_ms: dict


@dataclass
class FrameResult:
    frame: int
    t: float
    tracks: list[TrackOutput]
    diagnostics: FrameDiagnostics


class MultiObjectTracker:
    def __init__(self, config: TrackerConfig):
        self.cfg = config
        self.tracks: list[Track] = []
        self._next_id = 0
        self._last_t: float | None = None

    def reset(self) -> None:
        self.tracks, self._next_id, self._last_t = [], 0, None

    def _predictions(self) -> list[TrackPrediction]:
        out = []
        for trk in self.tracks:
            p = trk.params
            out.append(TrackPrediction(
                track_id=trk.id, cls=trk.cls, box=trk.box,
                S_pos=kf.position_innovation_cov(trk.P, p),
                last_meas_pos=trk.last_meas_pos, time_since_meas=trk.last_t - trk.last_meas_t,
            ))
        return out

    def step(self, frame: int, t: float, detections: list[Detection]) -> FrameResult:
        if self._last_t is not None and t <= self._last_t:
            raise ValueError(f"timestamps must increase: {t} <= {self._last_t}")
        t0 = time.perf_counter()
        thr = self.cfg.score_threshold
        dets = [d for d in detections
                if d.cls in self.cfg.classes and d.score >= thr.get(d.cls, -np.inf)]

        # 1) predict
        for trk in self.tracks:
            trk.predict(t)
        t1 = time.perf_counter()

        # 2) associate
        preds = self._predictions()
        res: AssociationResult = associate(preds, dets, self.cfg.association)
        t2 = time.perf_counter()

        # 3) update / miss handling
        lc = self.cfg.lifecycle
        before = {trk.id: trk.status for trk in self.tracks}
        for ti, di in res.matches:
            self.tracks[ti].update(dets[di], frame, lc.min_hits)
        for ti in res.unmatched_tracks:
            self.tracks[ti].mark_missed(frame, lc.max_age)

        # 4) births
        born = []
        for di in res.unmatched_dets:
            d = dets[di]
            if d.score < lc.birth_min_score:
                continue
            trk = Track(self._next_id, d, frame, t, self.cfg.kalman_for(d.cls), lc.history_len)
            if lc.min_hits <= 1:
                trk.status = TrackStatus.CONFIRMED
            self.tracks.append(trk)
            born.append(trk.id)
            self._next_id += 1

        # 5) lifecycle bookkeeping + pruning
        confirmed_now = [trk.id for trk in self.tracks if trk.status is TrackStatus.CONFIRMED
                         and before.get(trk.id, TrackStatus.TENTATIVE) is TrackStatus.TENTATIVE]
        lost_now = [trk.id for trk in self.tracks if trk.status is TrackStatus.LOST
                    and before.get(trk.id) is TrackStatus.CONFIRMED]
        deleted = [trk.id for trk in self.tracks if trk.status is TrackStatus.DELETED]
        self._by_id = {trk.id: trk for trk in self.tracks}  # incl. tracks deleted this frame
        self.tracks = [trk for trk in self.tracks if trk.is_active]
        t3 = time.perf_counter()

        # 6) outputs
        outputs = []
        for trk in self.tracks:
            if trk.status is TrackStatus.CONFIRMED or (lc.output_lost and trk.status is TrackStatus.LOST):
                outputs.append(TrackOutput(
                    track_id=trk.id, cls=trk.cls, status=trk.status.value, box=trk.box,
                    velocity=trk.velocity, pos_std=np.sqrt(np.diag(trk.P)[0:3]), score=trk.score,
                    source="measured" if trk.time_since_update == 0 else "predicted",
                    hits=trk.hits, age=trk.age, time_since_update=trk.time_since_update,
                    det_id=trk.last_det_id,
                ))
        counts = {s: sum(trk.status is s for trk in self.tracks) for s in TrackStatus}
        diag = FrameDiagnostics(
            frame=frame, t=t, n_detections_in=len(detections), n_detections_used=len(dets),
            n_tentative=counts[TrackStatus.TENTATIVE], n_confirmed=counts[TrackStatus.CONFIRMED],
            n_lost=counts[TrackStatus.LOST], born=born, confirmed_now=confirmed_now,
            lost_now=lost_now, deleted=deleted,
            matches=[{"track_id": preds[ti].track_id, "det_id": dets[di].det_id, "cost": c,
                      "nis": self._by_id[preds[ti].track_id].last_nis,
                      "innov_xy": float(np.hypot(*self._by_id[preds[ti].track_id].last_innovation[:2]))}
                     for (ti, di), c in zip(res.matches, res.match_costs)],
            rejections=[{"track_id": preds[ti].track_id, "det_id": dets[di].det_id, "reason": r}
                        for ti, di, r in res.rejections],
            det_scores=[d.score for d in dets],
            timing_ms={"predict": 1e3 * (t1 - t0), "associate": 1e3 * (t2 - t1),
                       "update": 1e3 * (t3 - t2), "total": 1e3 * (time.perf_counter() - t0)},
        )
        self._last_t = t
        return FrameResult(frame, t, outputs, diag)
