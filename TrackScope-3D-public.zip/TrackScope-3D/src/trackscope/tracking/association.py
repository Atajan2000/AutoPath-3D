"""Track-to-detection association: cost matrices, gating, and Hungarian assignment.

Methods (all compare the Kalman-*predicted* track box with the current detections, so they
differ only in the matching criterion):

``center``       Euclidean BEV distance between centres; gate ``d < center_gate[cls]`` (m).
``mahalanobis``  Squared Mahalanobis distance of the 3D centre under the innovation covariance
                 ``S = P_pos + R_pos``; gate ``d2 < chi2.ppf(gate_prob, 3)``. The assignment cost
                 is the Gaussian negative log-likelihood ``d2 + ln det S`` so that uncertain
                 (long-coasting) tracks do not attract detections too cheaply.
``iou``          ``1 - IoU`` between predicted and detected boxes (3D or BEV); gate
                 ``IoU > iou_threshold``.

Feasibility checks applied to every method before assignment:

* **class compatibility** - a track only matches detections of its own class;
* **physical plausibility** - the displacement from the track's last *measured* centre to the
  detection, divided by the elapsed time, must not exceed ``max_speed[cls]`` (+ a small slack
  for measurement noise). Speeds are meaningful because the world frame is ego-compensated;
* **size consistency** - box volume ratio within ``[1/max_volume_ratio, max_volume_ratio]``.

The Hungarian solver (``scipy.optimize.linear_sum_assignment``) runs on the cost matrix with
infeasible entries set to a large constant, so it maximises the number of feasible matches
first and minimises total cost second; any infeasible pair it returns is discarded.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
from scipy.optimize import linear_sum_assignment
from scipy.stats import chi2

from ..geometry.boxes import iou_3d, iou_bev
from ..types import Detection

METHODS = ("center", "mahalanobis", "iou")
_INFEASIBLE = 1e6


@dataclass(frozen=True)
class AssociationConfig:
    method: str = "mahalanobis"
    center_gate: dict = field(default_factory=lambda: {"Car": 3.0, "Pedestrian": 1.5, "Cyclist": 2.0})
    gate_prob: float = 0.99
    iou_mode: str = "3d"
    iou_threshold: float = 0.01
    max_speed: dict = field(default_factory=lambda: {"Car": 40.0, "Pedestrian": 4.0, "Cyclist": 15.0})
    speed_slack: float = 1.0  # m, tolerance on the speed check for detector noise
    max_volume_ratio: float = 3.0

    def __post_init__(self):
        if self.method not in METHODS:
            raise ValueError(f"unknown association method {self.method!r}; choose from {METHODS}")
        if self.iou_mode not in ("3d", "bev"):
            raise ValueError(f"iou_mode must be '3d' or 'bev', got {self.iou_mode!r}")

    @property
    def chi2_gate(self) -> float:
        return float(chi2.ppf(self.gate_prob, df=3))


@dataclass(frozen=True)
class TrackPrediction:
    """What association needs to know about a track (decoupled from the Track class)."""

    track_id: int
    cls: str
    box: np.ndarray  # predicted box7
    S_pos: np.ndarray  # 3x3 innovation covariance of the centre
    last_meas_pos: np.ndarray  # (3,)
    time_since_meas: float  # s


@dataclass
class AssociationResult:
    matches: list[tuple[int, int]]  # (track index, detection index)
    match_costs: list[float]
    unmatched_tracks: list[int]
    unmatched_dets: list[int]
    #: (track index, detection index, reason) for same-class pairs ruled out by gating
    #: or a plausibility check while still being the nearest candidate (for diagnostics)
    rejections: list[tuple[int, int, str]] = field(default_factory=list)


def _pair_cost(trk: TrackPrediction, det: Detection, cfg: AssociationConfig) -> tuple[float, str]:
    """Cost of a pair, or (inf, reason) if infeasible."""
    if trk.cls != det.cls:
        return np.inf, "class"
    dt = max(trk.time_since_meas, 1e-6)
    if np.linalg.norm(det.box[:2] - trk.last_meas_pos[:2]) > cfg.max_speed.get(det.cls, np.inf) * dt + cfg.speed_slack:
        return np.inf, "speed"
    v_t = float(np.prod(trk.box[4:7]))
    v_d = float(np.prod(det.box[4:7]))
    if max(v_t, v_d) > cfg.max_volume_ratio * min(v_t, v_d):
        return np.inf, "size"
    if cfg.method == "center":
        d = float(np.linalg.norm(det.box[:2] - trk.box[:2]))
        return (d, "") if d < cfg.center_gate.get(det.cls, np.inf) else (np.inf, "gate")
    if cfg.method == "mahalanobis":
        r = det.box[:3] - trk.box[:3]
        d2 = float(r @ np.linalg.solve(trk.S_pos, r))
        if d2 >= cfg.chi2_gate:
            return np.inf, "gate"
        return d2 + float(np.log(np.linalg.det(trk.S_pos))), ""
    iou = (iou_3d if cfg.iou_mode == "3d" else iou_bev)(trk.box, det.box)
    return (1.0 - iou, "") if iou > cfg.iou_threshold else (np.inf, "gate")


def cost_matrix(tracks: list[TrackPrediction], dets: list[Detection], cfg: AssociationConfig):
    C = np.full((len(tracks), len(dets)), np.inf)
    reasons = np.full((len(tracks), len(dets)), "", dtype=object)
    for i, t in enumerate(tracks):
        for j, d in enumerate(dets):
            C[i, j], reasons[i, j] = _pair_cost(t, d, cfg)
    return C, reasons


def associate(tracks: list[TrackPrediction], dets: list[Detection], cfg: AssociationConfig) -> AssociationResult:
    if not tracks or not dets:
        return AssociationResult([], [], list(range(len(tracks))), list(range(len(dets))))
    C, reasons = cost_matrix(tracks, dets, cfg)
    feasible = np.isfinite(C)
    rows, cols = linear_sum_assignment(np.where(feasible, C, _INFEASIBLE))
    matches, costs = [], []
    for r, c in zip(rows, cols):
        if feasible[r, c]:
            matches.append((int(r), int(c)))
            costs.append(float(C[r, c]))
    mt = {m[0] for m in matches}
    md = {m[1] for m in matches}
    unmatched_tracks = [i for i in range(len(tracks)) if i not in mt]
    unmatched_dets = [j for j in range(len(dets)) if j not in md]
    # Diagnostics: for each unmatched track, report why its nearest same-class detection failed.
    rejections = []
    for i in unmatched_tracks:
        same = [j for j in range(len(dets)) if dets[j].cls == tracks[i].cls]
        if same:
            j = min(same, key=lambda j: np.linalg.norm(dets[j].box[:2] - tracks[i].box[:2]))
            rejections.append((i, j, reasons[i, j] or "assigned_elsewhere"))
    return AssociationResult(matches, costs, unmatched_tracks, unmatched_dets, rejections)
