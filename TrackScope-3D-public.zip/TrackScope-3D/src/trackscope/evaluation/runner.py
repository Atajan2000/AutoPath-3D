"""Evaluate tracker result files and raw detections against KITTI annotations."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np

from ..data.detections import load_sequence_detections
from .ground_truth import KittiObject, load_ground_truth, load_kitti_tracking_file
from .metrics import TrackingEvents, detection_counts, evaluate_frames
from .protocol import FrameEval, preprocess_sequence


@dataclass
class SequenceEval:
    seq: str
    cls: str
    mode: str
    threshold: float
    counts: dict
    events: TrackingEvents
    frames: list[FrameEval]


def num_frames_of(kitti_root: Path, seq: str) -> int:
    """Sequence length from the OXTS file (one row per frame)."""
    with open(Path(kitti_root) / "training" / "oxts" / f"{seq}.txt") as f:
        return sum(1 for line in f if line.strip())


def evaluate_tracking(gt_frames: dict, trk_frames: dict, num_frames: int, seq: str, cls: str,
                      mode: str, threshold: float, match_threshold: float | None = None) -> SequenceEval:
    """``match_threshold`` is the preprocessing (ignore-region) matching threshold; KITTI/TrackEval
    use 0.5 for 2D. For custom 3D evaluation we use the evaluation threshold itself."""
    mt = threshold if match_threshold is None else match_threshold
    frames = preprocess_sequence(gt_frames, trk_frames, num_frames, cls, mode, mt)
    counts, events = evaluate_frames(frames, threshold)
    return SequenceEval(seq, cls, mode, threshold, counts, events, frames)


def detections_as_objects(cam_dets: dict, score_threshold: float = -np.inf) -> dict[int, list[KittiObject]]:
    """Raw detections -> KittiObjects with a unique ID per detection (frame*10000 + index)."""
    out: dict[int, list[KittiObject]] = {}
    for f, dets in cam_dets.items():
        out[f] = [KittiObject(frame=f, track_id=f * 10000 + i, cls=d.cls, truncated=-1, occluded=-1,
                              alpha=0.0, bbox2d=d.bbox2d, dims_hwl=d.dims_hwl, loc=d.loc, ry=d.ry,
                              score=d.score)
                  for i, d in enumerate(dets) if d.score >= score_threshold]
    return out


def evaluate_detector(gt_frames: dict, cam_dets: dict, num_frames: int, cls: str, mode: str,
                      threshold: float, score_threshold: float = -np.inf) -> dict:
    objs = detections_as_objects(cam_dets, score_threshold)
    frames = preprocess_sequence(gt_frames, objs, num_frames, cls, mode, threshold)
    return detection_counts(frames, threshold)


def load_inputs(kitti_root: Path, det_root: Path, seq: str, classes: list[str]):
    gt = load_ground_truth(Path(kitti_root) / "training" / "label_02" / f"{seq}.txt")
    dets = load_sequence_detections(det_root, seq, classes)
    return gt, dets, num_frames_of(kitti_root, seq)


def load_tracker_results(results_dir: Path, seq: str) -> dict[int, list[KittiObject]]:
    return load_kitti_tracking_file(Path(results_dir) / f"{seq}.txt")
