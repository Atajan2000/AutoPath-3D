"""Evaluation protocol: sequence split, classes, ignore rules, per-frame preprocessing.

Ignore handling reproduces the KITTI tracking protocol as implemented in TrackEval's
``Kitti2DBox`` (commit 12c8791), so the 2D path is directly comparable and the 3D path differs
**only in the similarity measure** (oriented 3D IoU instead of 2D box IoU):

1. Per evaluated class, keep GT of that class plus its *distractor* class
   (Car -> Van, Pedestrian -> Person [= person sitting]); keep tracker objects of that class.
2. Hungarian-match tracker objects to those GT at ``match_threshold``. Tracker objects matched
   to a distractor, or to GT with occlusion > 2 or truncation > 0, are removed (neither TP nor FP).
3. Unmatched tracker objects whose 2D box height is <= 25 px, or whose 2D box lies > 50 % inside
   a ``DontCare`` region (intersection over tracker-box area), are removed.
4. Only GT of the evaluated class with occlusion <= 2 and truncation <= 0 are scored.

The 2D boxes used in steps 3 are the image projections written by the pipeline for tracker
outputs, and the detector's own 2D boxes for detector-only evaluation.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

import numpy as np
from scipy.optimize import linear_sum_assignment

from ..geometry.boxes import T_ZUP_CAM, cam_box_to_zup, iou_3d
from .ground_truth import KittiObject

EPS = np.finfo(float).eps

# ---- split (AB3DMOT KITTI split; AB3DMOT_libs/utils.py) ------------------------------------
AB3DMOT_TRAIN = ("0000", "0002", "0003", "0004", "0005", "0007", "0009", "0011", "0017", "0020")
AB3DMOT_VAL = ("0001", "0006", "0008", "0010", "0012", "0013", "0014", "0015", "0016", "0018", "0019")
DEV_SEQUENCES = ("0014",)  # used during Phase-1 development and geometry validation
HELDOUT_SEQUENCES = tuple(s for s in AB3DMOT_VAL if s not in DEV_SEQUENCES)

# ---- KITTI protocol constants -------------------------------------------------------------
MAX_OCCLUSION = 2
MAX_TRUNCATION = 0
MIN_HEIGHT = 25.0
DONTCARE_IOA = 0.5


@dataclass(frozen=True)
class ClassSpec:
    name: str
    distractors: tuple[str, ...]
    kitti_official: bool  # evaluated by the official KITTI tracking benchmark


CLASS_SPECS = {
    "Car": ClassSpec("Car", ("Van",), True),
    "Pedestrian": ClassSpec("Pedestrian", ("Person",), True),
    "Cyclist": ClassSpec("Cyclist", (), False),  # supplementary, not a KITTI tracking class
}


# ---- similarity -----------------------------------------------------------------------------
def box_iou_2d(a: np.ndarray, b: np.ndarray, ioa: bool = False) -> np.ndarray:
    """Pairwise IoU (or intersection over area of ``a``) of x1y1x2y2 boxes, as in TrackEval."""
    a, b = np.asarray(a, float).reshape(-1, 4), np.asarray(b, float).reshape(-1, 4)
    if len(a) == 0 or len(b) == 0:
        return np.zeros((len(a), len(b)))
    ix = np.clip(np.minimum(a[:, None, 2], b[None, :, 2]) - np.maximum(a[:, None, 0], b[None, :, 0]), 0, None)
    iy = np.clip(np.minimum(a[:, None, 3], b[None, :, 3]) - np.maximum(a[:, None, 1], b[None, :, 1]), 0, None)
    inter = ix * iy
    area_a = (a[:, 2] - a[:, 0]) * (a[:, 3] - a[:, 1])
    if ioa:
        denom = area_a[:, None]
    else:
        area_b = (b[:, 2] - b[:, 0]) * (b[:, 3] - b[:, 1])
        denom = area_a[:, None] + area_b[None, :] - inter
    out = np.zeros_like(inter)
    np.divide(inter, denom, out=out, where=denom > EPS)
    return np.clip(out, 0.0, 1.0)


def cam_object_box7(o) -> np.ndarray:
    return cam_box_to_zup(o.loc, o.dims_hwl, o.ry, T_ZUP_CAM)


def similarity_3d(gts: list, trks: list) -> np.ndarray:
    gb = [cam_object_box7(g) for g in gts]
    tb = [cam_object_box7(t) for t in trks]
    out = np.zeros((len(gb), len(tb)))
    for i, g in enumerate(gb):
        for j, t in enumerate(tb):
            out[i, j] = iou_3d(g, t)
    return out


def similarity_2d(gts: list, trks: list) -> np.ndarray:
    return box_iou_2d([g.bbox2d for g in gts], [t.bbox2d for t in trks])


SIMILARITY: dict[str, Callable] = {"3d": similarity_3d, "2d": similarity_2d}


# ---- per-frame preprocessing ----------------------------------------------------------------
@dataclass
class FrameEval:
    frame: int
    gt_ids: np.ndarray  # original GT track ids (scored GT only)
    trk_ids: np.ndarray  # original tracker ids (kept tracker objects only)
    sim: np.ndarray  # (len(gt_ids), len(trk_ids))
    removed: list[tuple[int, str]] = field(default_factory=list)  # (tracker id, reason)


def preprocess_frame(frame: int, gts: list[KittiObject], trks: list, cls: str, mode: str,
                     match_threshold: float) -> FrameEval:
    """Apply the KITTI ignore rules for one frame and class (see module docstring)."""
    spec = CLASS_SPECS[cls]
    rel_gt = [g for g in gts if g.cls == cls or g.cls in spec.distractors]
    dontcare = np.array([g.bbox2d for g in gts if g.cls == "DontCare"]).reshape(-1, 4)
    rel_trk = [t for t in trks if t.cls == cls]
    sim = SIMILARITY[mode](rel_gt, rel_trk)

    remove: dict[int, str] = {}
    unmatched = list(range(len(rel_trk)))
    if rel_gt and rel_trk:
        score = sim.copy()
        score[score < match_threshold - EPS] = 0.0
        rows, cols = linear_sum_assignment(-score)
        ok = score[rows, cols] > EPS
        for r, c in zip(rows[ok], cols[ok]):
            g = rel_gt[r]
            if g.cls in spec.distractors:
                remove[c] = "distractor"
            elif g.occluded > MAX_OCCLUSION or g.truncated > MAX_TRUNCATION:
                remove[c] = "occluded_or_truncated_gt"
        matched_cols = set(cols[ok].tolist())
        unmatched = [j for j in range(len(rel_trk)) if j not in matched_cols]
    if unmatched:
        boxes = np.array([rel_trk[j].bbox2d for j in unmatched]).reshape(-1, 4)
        too_small = (boxes[:, 3] - boxes[:, 1]) <= MIN_HEIGHT + EPS
        in_dc = (box_iou_2d(boxes, dontcare, ioa=True) > DONTCARE_IOA + EPS).any(axis=1) \
            if len(dontcare) else np.zeros(len(unmatched), bool)
        for k, j in enumerate(unmatched):
            if too_small[k]:
                remove[j] = "too_small"
            elif in_dc[k]:
                remove[j] = "dontcare_region"

    keep_trk = [j for j in range(len(rel_trk)) if j not in remove]
    keep_gt = [i for i, g in enumerate(rel_gt) if g.cls == cls and g.occluded <= MAX_OCCLUSION
               and g.truncated <= MAX_TRUNCATION]
    return FrameEval(
        frame=frame,
        gt_ids=np.array([rel_gt[i].track_id for i in keep_gt], dtype=int),
        trk_ids=np.array([rel_trk[j].track_id for j in keep_trk], dtype=int),
        sim=sim[np.ix_(keep_gt, keep_trk)] if keep_gt and keep_trk else np.zeros((len(keep_gt), len(keep_trk))),
        removed=[(rel_trk[j].track_id, r) for j, r in sorted(remove.items())],
    )


def preprocess_sequence(gt_frames: dict, trk_frames: dict, num_frames: int, cls: str, mode: str,
                        match_threshold: float) -> list[FrameEval]:
    out = []
    for f in range(num_frames):
        out.append(preprocess_frame(f, gt_frames.get(f, []), trk_frames.get(f, []), cls, mode, match_threshold))
    extra = [f for f in list(gt_frames) + list(trk_frames) if f >= num_frames or f < 0]
    if extra:
        raise ValueError(f"objects in frames outside [0, {num_frames}): {sorted(set(extra))[:5]}")
    for fe in out:
        if len(set(fe.trk_ids.tolist())) != len(fe.trk_ids):
            raise ValueError(f"frame {fe.frame}: duplicate tracker id")
        if len(set(fe.gt_ids.tolist())) != len(fe.gt_ids):
            raise ValueError(f"frame {fe.frame}: duplicate GT id")
    return out
