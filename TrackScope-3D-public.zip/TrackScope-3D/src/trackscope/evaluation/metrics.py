"""CLEAR-MOT, identity (IDF1) and detection metrics on preprocessed frames.

Definitions follow the CLEAR-MOT paper (Bernardin & Stiefelhagen 2008) and the identity
metrics of Ristani et al. (2016), with the conventions of TrackEval (used for verification):

* **Per-frame matching**: Hungarian on similarity >= threshold, with a +1000 bonus for keeping
  the GT->tracker pairing of the previous evaluated frame (so ID switches are minimised first,
  similarity maximised second).
* **IDSW**: a GT is matched to a tracker ID different from the last tracker ID it was matched to
  (any number of frames earlier).
* **Frag**: number of times a GT trajectory resumes being tracked after an interruption
  (count of untracked->tracked transitions minus one per GT).
  TrackEval quirk reproduced on purpose: a frame with GT but *zero* tracker objects (or zero GT)
  is skipped and does not register as an interruption. In sparse scenes (a single object whose
  track is lost) this hides real fragmentation, so **Frag_strict** is reported as well: the same
  definition without skipping those frames. Failure analysis uses the strict events.
* **MT / PT / ML**: tracked ratio > 0.8 / >= 0.2 / rest.
* **MOTA** = (TP - FP - IDSW) / max(1, #GT).   **MOTP** = mean similarity of TPs.
* **IDF1**: one-to-one *identity-level* assignment between GT IDs and tracker IDs over the whole
  sequence maximising IDTP, where a (GT, tracker) pair contributes one IDTP per frame in which
  both exist with similarity >= threshold. IDF1 = 2 IDTP / (2 IDTP + IDFP + IDFN).

Counts are additive over sequences; ratios are recomputed from summed counts.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
from scipy.optimize import linear_sum_assignment

from .protocol import EPS, FrameEval

COUNT_FIELDS = ("GT", "GT_IDS", "TRK", "TRK_IDS", "TP", "FP", "FN", "IDSW", "Frag", "Frag_strict", "MT", "PT", "ML",
                "MOTP_sum", "IDTP", "IDFP", "IDFN", "frames")


@dataclass
class TrackingEvents:
    """Per-frame evaluation outcomes, keyed by original IDs (for failure analysis)."""

    matches: dict = field(default_factory=dict)  # frame -> list[(gt_id, trk_id, sim)]
    fn: dict = field(default_factory=dict)  # frame -> list[gt_id]
    fp: dict = field(default_factory=dict)  # frame -> list[trk_id]
    idsw: list = field(default_factory=list)  # (frame, gt_id, prev_trk_id, new_trk_id, last_match_frame)
    frag: list = field(default_factory=list)  # (frame, gt_id, trk_id, last_tracked_frame), TrackEval-compatible
    frag_strict: list = field(default_factory=list)  # same, without skipping empty frames


def clear_mot(frames: list[FrameEval], threshold: float) -> tuple[dict, TrackingEvents]:
    ev = TrackingEvents()
    c = dict.fromkeys(COUNT_FIELDS, 0)
    c["MOTP_sum"] = 0.0
    c["frames"] = len(frames)
    gt_all = sorted({int(g) for fe in frames for g in fe.gt_ids})
    trk_all = {int(t) for fe in frames for t in fe.trk_ids}
    c["GT_IDS"], c["TRK_IDS"] = len(gt_all), len(trk_all)
    c["GT"] = int(sum(len(fe.gt_ids) for fe in frames))
    c["TRK"] = int(sum(len(fe.trk_ids) for fe in frames))
    if c["TRK"] == 0:
        c["FN"], c["ML"] = c["GT"], c["GT_IDS"]
        for fe in frames:
            if len(fe.gt_ids):
                ev.fn[fe.frame] = fe.gt_ids.tolist()
        return c, ev
    if c["GT"] == 0:
        c["FP"] = c["TRK"]
        for fe in frames:
            if len(fe.trk_ids):
                ev.fp[fe.frame] = fe.trk_ids.tolist()
        return c, ev

    present = dict.fromkeys(gt_all, 0)
    matched = dict.fromkeys(gt_all, 0)
    starts = dict.fromkeys(gt_all, 0)
    last_trk: dict[int, int] = {}  # GT -> last matched tracker id (for IDSW)
    last_match_frame: dict[int, int] = {}
    prev_step: dict[int, int] = {}  # GT -> tracker id matched in the previous evaluated frame
    starts_strict = dict.fromkeys(gt_all, 0)
    prev_strict: dict[int, int] = {}  # like prev_step, but reset in every frame
    for fe in frames:
        gts, trks = fe.gt_ids, fe.trk_ids
        if len(gts) == 0:
            c["FP"] += len(trks)
            if len(trks):
                ev.fp[fe.frame] = trks.tolist()
            prev_strict = {}
            continue
        if len(trks) == 0:
            c["FN"] += len(gts)
            for g in gts:
                present[int(g)] += 1
            ev.fn[fe.frame] = gts.tolist()
            prev_strict = {}
            continue
        bonus = np.array([[prev_step.get(int(g)) == int(t) for t in trks] for g in gts], float)
        score = 1000.0 * bonus + fe.sim
        score[fe.sim < threshold - EPS] = 0.0
        rows, cols = linear_sum_assignment(-score)
        ok = score[rows, cols] > EPS
        rows, cols = rows[ok], cols[ok]
        fm = []
        for r, k in zip(rows, cols):
            g, t = int(gts[r]), int(trks[k])
            if g in last_trk and last_trk[g] != t:
                c["IDSW"] += 1
                ev.idsw.append((fe.frame, g, last_trk[g], t, last_match_frame[g]))
            fm.append((g, t, float(fe.sim[r, k])))
        for g in gts:
            present[int(g)] += 1
        new_step = {g: t for g, t, _ in fm}
        for g, t, _ in fm:
            matched[g] += 1
            if g not in prev_step:
                starts[g] += 1
                if starts[g] > 1:
                    ev.frag.append((fe.frame, g, t, last_match_frame[g]))
            if g not in prev_strict:
                starts_strict[g] += 1
                if starts_strict[g] > 1:
                    ev.frag_strict.append((fe.frame, g, t, last_match_frame[g]))
            last_trk[g] = t
            last_match_frame[g] = fe.frame
        prev_step = new_step
        prev_strict = new_step
        c["TP"] += len(fm)
        c["FN"] += len(gts) - len(fm)
        c["FP"] += len(trks) - len(fm)
        c["MOTP_sum"] += sum(s for _, _, s in fm)
        ev.matches[fe.frame] = fm
        mg, mt = {g for g, _, _ in fm}, {t for _, t, _ in fm}
        if len(gts) > len(fm):
            ev.fn[fe.frame] = [int(g) for g in gts if int(g) not in mg]
        if len(trks) > len(fm):
            ev.fp[fe.frame] = [int(t) for t in trks if int(t) not in mt]

    for g in gt_all:
        if present[g] == 0:
            continue
        ratio = matched[g] / present[g]
        if ratio > 0.8:
            c["MT"] += 1
        elif ratio >= 0.2:
            c["PT"] += 1
    c["ML"] = c["GT_IDS"] - c["MT"] - c["PT"]
    c["Frag"] = int(sum(max(0, s - 1) for s in starts.values()))
    c["Frag_strict"] = int(sum(max(0, s - 1) for s in starts_strict.values()))
    return c, ev


def identity(frames: list[FrameEval], threshold: float) -> dict:
    """IDTP/IDFP/IDFN via a global one-to-one GT-ID <-> tracker-ID assignment."""
    gt_ids = sorted({int(g) for fe in frames for g in fe.gt_ids})
    trk_ids = sorted({int(t) for fe in frames for t in fe.trk_ids})
    n_gt = int(sum(len(fe.gt_ids) for fe in frames))
    n_trk = int(sum(len(fe.trk_ids) for fe in frames))
    if not gt_ids or not trk_ids:
        return {"IDTP": 0, "IDFP": n_trk, "IDFN": n_gt}
    gi = {g: i for i, g in enumerate(gt_ids)}
    ti = {t: i for i, t in enumerate(trk_ids)}
    co = np.zeros((len(gt_ids), len(trk_ids)))
    for fe in frames:
        r, k = np.nonzero(fe.sim >= threshold)
        for a, b in zip(r, k):
            co[gi[int(fe.gt_ids[a])], ti[int(fe.trk_ids[b])]] += 1
    rows, cols = linear_sum_assignment(-co)
    idtp = int(co[rows, cols].sum())
    return {"IDTP": idtp, "IDFP": n_trk - idtp, "IDFN": n_gt - idtp}


def detection_counts(frames: list[FrameEval], threshold: float) -> dict:
    """Frame-wise detection TP/FP/FN (no identities) - for detector-only evaluation."""
    tp = fp = fn = 0
    sim_sum = 0.0
    for fe in frames:
        ng, nt = fe.sim.shape
        m = 0
        if ng and nt:
            s = fe.sim.copy()
            s[s < threshold - EPS] = 0.0
            r, k = linear_sum_assignment(-s)
            ok = s[r, k] > EPS
            m = int(ok.sum())
            sim_sum += float(fe.sim[r[ok], k[ok]].sum())
        tp += m
        fn += ng - m
        fp += nt - m
    return {"GT": tp + fn, "TRK": tp + fp, "TP": tp, "FP": fp, "FN": fn, "MOTP_sum": sim_sum,
            "frames": len(frames)}


def evaluate_frames(frames: list[FrameEval], threshold: float) -> tuple[dict, TrackingEvents]:
    c, ev = clear_mot(frames, threshold)
    c.update(identity(frames, threshold))
    return c, ev


def sum_counts(counts: list[dict]) -> dict:
    out: dict = {}
    for c in counts:
        for k, v in c.items():
            out[k] = out.get(k, 0) + v
    return out


def finalize(c: dict) -> dict:
    """Ratios from (possibly summed) counts. Missing keys are treated as not applicable."""
    out = dict(c)
    gt, tp, fp, fn = c.get("GT", 0), c.get("TP", 0), c.get("FP", 0), c.get("FN", 0)
    out["Recall"] = tp / max(1, tp + fn)
    out["Precision"] = tp / max(1, tp + fp)
    out["MODA"] = (tp - fp) / max(1, gt)
    out["MOTP"] = c.get("MOTP_sum", 0.0) / max(1, tp)
    if "IDSW" in c:
        out["MOTA"] = (tp - fp - c["IDSW"]) / max(1, gt)
    if "IDTP" in c:
        idtp, idfp, idfn = c["IDTP"], c["IDFP"], c["IDFN"]
        out["IDF1"] = idtp / max(1.0, idtp + 0.5 * idfp + 0.5 * idfn)
        out["IDP"] = idtp / max(1, idtp + idfp)
        out["IDR"] = idtp / max(1, idtp + idfn)
    if "MT" in c and c.get("GT_IDS"):
        out["MT_ratio"] = c["MT"] / c["GT_IDS"]
        out["ML_ratio"] = c["ML"] / c["GT_IDS"]
    return out
