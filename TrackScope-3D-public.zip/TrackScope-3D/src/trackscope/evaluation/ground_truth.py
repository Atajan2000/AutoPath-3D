"""KITTI Tracking-format files: annotations (``label_02``) and tracker results.

**Evaluation and validation only.** Nothing under ``trackscope.data``, ``trackscope.tracking``
or ``trackscope.pipeline`` may import this module; a test enforces it, so ground-truth
identities cannot influence online tracking.

Row format (space separated, 17 columns, plus an optional 18th score column for results)::

    frame track_id type truncated occluded alpha x1 y1 x2 y2 h w l x y z ry [score]
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path

import numpy as np


@dataclass(frozen=True)
class KittiObject:
    frame: int
    track_id: int  # -1 for DontCare
    cls: str  # Car, Van, Truck, Pedestrian, Person, Cyclist, Tram, Misc, DontCare
    truncated: int  # 0, 1, 2 in KITTI tracking labels; -1 in tracker results
    occluded: int  # 0 fully visible, 1 partly, 2 largely, 3 unknown; -1 in results
    alpha: float
    bbox2d: np.ndarray  # x1, y1, x2, y2
    dims_hwl: np.ndarray
    loc: np.ndarray  # bottom centre, rect camera frame
    ry: float
    score: float = 1.0


GroundTruthObject = KittiObject  # backwards-compatible name


def load_kitti_tracking_file(path: str | Path) -> dict[int, list[KittiObject]]:
    path = Path(path)
    by_frame: dict[int, list[KittiObject]] = defaultdict(list)
    for i, line in enumerate(path.read_text().splitlines(), start=1):
        p = line.split()
        if not p:
            continue
        if len(p) not in (17, 18):
            raise ValueError(f"{path}:{i}: expected 17 or 18 columns, got {len(p)}")
        try:
            v = [float(x) for x in p[3:]]
        except ValueError as e:
            raise ValueError(f"{path}:{i}: non-numeric value") from e
        obj = KittiObject(
            frame=int(p[0]), track_id=int(p[1]), cls=p[2], truncated=int(v[0]),
            occluded=int(v[1]), alpha=v[2], bbox2d=np.array(v[3:7]),
            dims_hwl=np.array(v[7:10]), loc=np.array(v[10:13]), ry=v[13],
            score=v[14] if len(v) > 14 else 1.0,
        )
        by_frame[obj.frame].append(obj)
    return dict(by_frame)


def load_ground_truth(path: str | Path) -> dict[int, list[KittiObject]]:
    return load_kitti_tracking_file(path)
