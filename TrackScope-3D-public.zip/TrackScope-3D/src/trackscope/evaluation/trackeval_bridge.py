"""Independent verification with TrackEval (JonathonLuiten/TrackEval @ 12c8791, MIT).

TrackEval is an optional dependency, installed with::

    pip install --no-deps "git+https://github.com/JonathonLuiten/TrackEval.git@12c8791b303e0a0b50f753af204249e622d0281a"

That commit still uses the aliases ``np.float``/``np.int``/``np.bool`` removed in NumPy 1.24;
:func:`import_trackeval` restores them as the Python builtins they always referred to. No
TrackEval logic is modified.

Two checks:

* :func:`trackeval_kitti_2d` runs TrackEval's *complete* KITTI 2D box pipeline (file parsing,
  official class/distractor/DontCare/occlusion/truncation/min-height rules, CLEAR, Identity)
  on our result files - independent of our loader, preprocessing and metric code.
* :func:`trackeval_metrics_on_frames` feeds our *preprocessed* frames (e.g. 3D IoU) into
  TrackEval's CLEAR and Identity metric classes - independent of our metric code.
"""

from __future__ import annotations

import contextlib
import io
import shutil
from pathlib import Path

import numpy as np

TRACKEVAL_COMMIT = "12c8791b303e0a0b50f753af204249e622d0281a"
FIELD_MAP = {"CLR_TP": "TP", "CLR_FP": "FP", "CLR_FN": "FN", "IDSW": "IDSW", "Frag": "Frag",
             "MT": "MT", "PT": "PT", "ML": "ML", "IDTP": "IDTP", "IDFP": "IDFP", "IDFN": "IDFN"}


def import_trackeval():
    for name, typ in (("float", float), ("int", int), ("bool", bool)):
        if name not in np.__dict__:
            setattr(np, name, typ)
    with contextlib.redirect_stdout(io.StringIO()):  # silences optional-dependency warnings
        import trackeval  # noqa: PLC0415
    return trackeval


def _pick(clear: dict, ident: dict) -> dict:
    out = {ours: int(round(float(clear.get(te, ident.get(te, 0))))) for te, ours in FIELD_MAP.items()}
    out["MOTA"], out["IDF1"] = float(clear["MOTA"]), float(ident["IDF1"])
    return out


def trackeval_metrics_on_frames(frames, threshold: float) -> dict:
    te = import_trackeval()
    gt_all = sorted({int(g) for fe in frames for g in fe.gt_ids})
    trk_all = sorted({int(t) for fe in frames for t in fe.trk_ids})
    gmap = {g: i for i, g in enumerate(gt_all)}
    tmap = {t: i for i, t in enumerate(trk_all)}
    data = {
        "num_timesteps": len(frames),
        "num_gt_ids": len(gt_all), "num_tracker_ids": len(trk_all),
        "num_gt_dets": int(sum(len(fe.gt_ids) for fe in frames)),
        "num_tracker_dets": int(sum(len(fe.trk_ids) for fe in frames)),
        "gt_ids": [np.array([gmap[int(g)] for g in fe.gt_ids], dtype=int) for fe in frames],
        "tracker_ids": [np.array([tmap[int(t)] for t in fe.trk_ids], dtype=int) for fe in frames],
        "similarity_scores": [fe.sim for fe in frames],
    }
    cfg = {"THRESHOLD": threshold, "PRINT_CONFIG": False}
    clear = te.metrics.CLEAR(cfg).eval_sequence(data)
    ident = te.metrics.Identity(cfg).eval_sequence(data)
    return _pick(clear, ident)


def trackeval_kitti_2d(label_dir: Path, results_root: Path, experiment: str, result_sub: str,
                       seq_lengths: dict[str, int], workdir: Path) -> dict:
    """Run TrackEval Kitti2DBox. Returns {(seq, cls): counts} with cls in {'Car', 'Pedestrian'}."""
    te = import_trackeval()
    gt_dir = workdir / "gt"
    if gt_dir.exists():
        shutil.rmtree(gt_dir)
    (gt_dir / "label_02").mkdir(parents=True)
    rows = []
    for seq, n in sorted(seq_lengths.items()):
        shutil.copy(Path(label_dir) / f"{seq}.txt", gt_dir / "label_02" / f"{seq}.txt")
        rows.append(f"{seq} empty 000000 {n:06d}")
    (gt_dir / "evaluate_tracking.seqmap.training").write_text("\n".join(rows) + "\n")
    eval_cfg = {"USE_PARALLEL": False, "PRINT_RESULTS": False, "PRINT_CONFIG": False,
                "TIME_PROGRESS": False, "OUTPUT_SUMMARY": False, "OUTPUT_DETAILED": False,
                "PLOT_CURVES": False, "LOG_ON_ERROR": str(workdir / "trackeval_error_log.txt")}
    ds_cfg = {"GT_FOLDER": str(gt_dir), "TRACKERS_FOLDER": str(results_root),
              "OUTPUT_FOLDER": str(workdir / "out"), "TRACKERS_TO_EVAL": [experiment],
              "CLASSES_TO_EVAL": ["car", "pedestrian"], "SPLIT_TO_EVAL": "training",
              "TRACKER_SUB_FOLDER": result_sub, "PRINT_CONFIG": False}
    metric_cfg = {"THRESHOLD": 0.5, "PRINT_CONFIG": False}
    with contextlib.redirect_stdout(io.StringIO()):
        evaluator = te.Evaluator(eval_cfg)
        res, _ = evaluator.evaluate([te.datasets.Kitti2DBox(ds_cfg)],
                                    [te.metrics.CLEAR(metric_cfg), te.metrics.Identity(metric_cfg)])
    per = res["Kitti2DBox"][experiment]
    out = {}
    for seq in seq_lengths:
        for te_cls, cls in (("car", "Car"), ("pedestrian", "Pedestrian")):
            r = per[seq][te_cls]
            out[(seq, cls)] = _pick(r["CLEAR"], r["Identity"])
    return out
