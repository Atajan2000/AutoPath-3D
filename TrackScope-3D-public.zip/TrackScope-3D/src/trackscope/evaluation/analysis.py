"""Error attribution: separate detector, initiation, association and state-estimation errors.

For each evaluated error event (from :func:`metrics.clear_mot`), the raw detections and the
tracker's own per-frame decisions (``frames/<seq>.jsonl``) are inspected:

False negatives (scored GT not matched by any tracker output)
    ``detector_miss``          no detection of the class overlaps the GT at the IoU threshold
    ``below_score_threshold``  only detections below the tracker's score threshold overlap it
    ``initiation_delay``       an overlapping detection was used by a tentative (unconfirmed)
                               track, or started a new track while no track covered the GT
    ``association_failure``    an overlapping detection was left unassociated (a new track was
                               spawned) although the GT had been tracked within ``max_age + 1``
                               frames - gating / motion-prediction failure
    ``state_estimation``       the detection was associated to a confirmed track, but the
                               filtered output box does not reach the IoU threshold

False positives (kept tracker outputs not matched to scored GT)
    ``detector_false_positive`` the associated detection itself overlaps no scored GT
    ``duplicate_track``         the detection overlaps a GT that another track already covers
    ``state_estimation``        the detection overlaps an uncovered GT, but the output box does not
    ``coasting_output``         output produced by prediction only (only if output_lost)

ID switches (GT changes tracker ID; ``old`` = previous tracker ID)
    ``identity_swap``           the old track still exists in the output at the switch frame
    ``parallel_track_takeover`` no gap: a duplicate track that was already confirmed takes over
    ``detector_gap``            the old track was lost while the detector missed the GT for more
                                than ``max_age`` consecutive frames - the tracker could not bridge it
    ``association_failure``     the old track was lost although detections were available

Fragmentations (strict definition, see ``metrics``) are attributed like track-loss ID switches:
``detector_gap`` if the detector missed the GT for more than ``max_age`` consecutive frames of
the gap (the frames needed to re-confirm a new track are a consequence), else ``tracker_gap``.
"""

from __future__ import annotations

import json
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

from .protocol import similarity_3d
from .runner import SequenceEval


def load_frame_records(path: Path) -> dict[int, dict]:
    with open(path) as f:
        return {r["frame"]: r for r in (json.loads(line) for line in f if line.strip())}


class _Coverage:
    """Best-overlapping detection per (frame, GT id) for one class, cached."""

    def __init__(self, gt_frames: dict, cam_dets: dict, cls: str):
        self.gt, self.dets, self.cls = gt_frames, cam_dets, cls
        self._cache: dict[int, dict] = {}

    def frame(self, f: int) -> dict:
        if f not in self._cache:
            gts = [g for g in self.gt.get(f, []) if g.cls == self.cls]
            all_dets = self.dets.get(f, [])
            idx = [i for i, d in enumerate(all_dets) if d.cls == self.cls]
            sim = similarity_3d(gts, [all_dets[i] for i in idx]) if gts and idx else np.zeros((len(gts), len(idx)))
            self._cache[f] = {"gt_ids": [g.track_id for g in gts], "det_idx": idx, "sim": sim,
                              "scores": [all_dets[i].score for i in idx]}
        return self._cache[f]

    def covering(self, f: int, gt_id: int, thr: float, min_score: float | None = None):
        """(det_id, iou, score) of the best detection overlapping GT at >= thr, or None."""
        c = self.frame(f)
        if gt_id not in c["gt_ids"] or not c["det_idx"]:
            return None
        row = c["sim"][c["gt_ids"].index(gt_id)]
        cand = [(row[k], c["det_idx"][k], c["scores"][k]) for k in range(len(row))
                if row[k] >= thr and (min_score is None or c["scores"][k] >= min_score)]
        if not cand:
            return None
        iou, det_id, score = max(cand)
        return det_id, float(iou), float(score)

    def det_overlaps(self, f: int, det_id: int, gt_ids, thr: float) -> list[int]:
        c = self.frame(f)
        if det_id not in c["det_idx"]:
            return []
        col = c["sim"][:, c["det_idx"].index(det_id)]
        return [g for g, s in zip(c["gt_ids"], col) if s >= thr and g in gt_ids]


def attribute_errors(se: SequenceEval, gt_frames: dict, cam_dets: dict, records: dict[int, dict],
                     score_threshold: float, max_age: int) -> dict:
    thr = se.threshold
    cov = _Coverage(gt_frames, cam_dets, se.cls)
    ev = se.events
    gt_ids_by_frame = {fe.frame: set(fe.gt_ids.tolist()) for fe in se.frames}

    match_frames: dict[int, list[int]] = defaultdict(list)  # gt -> frames matched
    covered_by: dict[int, dict[int, int]] = defaultdict(dict)  # frame -> gt -> trk
    for f, ms in ev.matches.items():
        for g, t, _ in ms:
            match_frames[g].append(f)
            covered_by[f][g] = t

    def outputs(f):
        return {t["id"]: t for t in records.get(f, {}).get("tracks", [])}

    def matched_det_to_track(f):
        return {m["det_id"]: m["track_id"] for m in records.get(f, {}).get("diagnostics", {}).get("matches", [])}

    fn_cause, fp_cause = Counter(), Counter()
    fn_rows, fp_rows = [], []
    for f, gts in ev.fn.items():
        outs, d2t = outputs(f), matched_det_to_track(f)
        for g in gts:
            hit = cov.covering(f, g, thr, score_threshold)
            if hit is None:
                cause = "below_score_threshold" if cov.covering(f, g, thr) else "detector_miss"
            else:
                det_id = hit[0]
                if det_id in d2t:
                    cause = "state_estimation" if d2t[det_id] in outs else "initiation_delay"
                else:
                    recent = [x for x in match_frames.get(g, []) if f - (max_age + 1) <= x < f]
                    cause = "association_failure" if recent else "initiation_delay"
            fn_cause[cause] += 1
            fn_rows.append((f, g, cause))

    for f, trks in ev.fp.items():
        outs = outputs(f)
        for t in trks:
            o = outs.get(t)
            if o is None:  # should not happen: result rows come from these outputs
                cause = "unknown"
            elif o["source"] == "predicted":
                cause = "coasting_output"
            else:
                hits = cov.det_overlaps(f, o["det_id"], gt_ids_by_frame.get(f, set()), thr)
                if not hits:
                    cause = "detector_false_positive"
                elif any(h in covered_by.get(f, {}) for h in hits):
                    cause = "duplicate_track"
                else:
                    cause = "state_estimation"
            fp_cause[cause] += 1
            fp_rows.append((f, t, cause))

    def gap_coverage(g, f0, f1):
        """Detector coverage of GT g over frames (f0, f1): list of bools for frames where g is scored."""
        return [cov.covering(x, g, thr, score_threshold) is not None
                for x in range(f0 + 1, f1) if g in gt_ids_by_frame.get(x, set())]

    def longest_false_run(flags):
        best = run = 0
        for v in flags:
            run = 0 if v else run + 1
            best = max(best, run)
        return best

    idsw_rows, idsw_cause = [], Counter()
    for f, g, old, new, f0 in ev.idsw:
        if old in outputs(f):
            cause, gap = "identity_swap", 0
        elif f0 == f - 1:
            cause, gap = "parallel_track_takeover", 0
        else:
            flags = gap_coverage(g, f0, f)
            gap = f - f0 - 1
            cause = "detector_gap" if longest_false_run(flags) > max_age or not any(flags) else "association_failure"
        idsw_cause[cause] += 1
        idsw_rows.append({"frame": f, "gt_id": g, "old_track": old, "new_track": new,
                          "last_match_frame": f0, "gap_frames": gap, "cause": cause})

    frag_rows, frag_cause = [], Counter()
    for f, g, t, f0 in ev.frag_strict:
        flags = gap_coverage(g, f0, f)
        cause = "detector_gap" if longest_false_run(flags) > max_age or not any(flags) else "tracker_gap"
        frag_cause[cause] += 1
        frag_rows.append({"frame": f, "gt_id": g, "track": t, "last_match_frame": f0,
                          "gap_frames": f - f0 - 1, "detector_coverage_in_gap": float(np.mean(flags)) if flags else 0.0,
                          "cause": cause})

    return {"fn": dict(fn_cause), "fp": dict(fp_cause), "idsw": dict(idsw_cause), "frag": dict(frag_cause),
            "idsw_events": idsw_rows, "frag_events": frag_rows, "fn_events": fn_rows, "fp_events": fp_rows}


def innovation_stats(records: dict[int, dict]) -> dict:
    """Per-class motion-prediction residuals from the tracker's own diagnostics."""
    by_cls: dict[str, dict[str, list]] = defaultdict(lambda: {"innov_xy": [], "nis": []})
    for r in records.values():
        cls_of = {d["det_id"]: d["cls"] for d in r["detections"]}
        for m in r["diagnostics"]["matches"]:
            if m.get("nis") is None:
                continue
            b = by_cls[cls_of[m["det_id"]]]
            b["innov_xy"].append(m["innov_xy"])
            b["nis"].append(m["nis"])
    return by_cls
