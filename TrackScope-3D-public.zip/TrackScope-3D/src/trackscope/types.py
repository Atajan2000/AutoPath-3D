"""Core data types shared by the data layer and the tracker.

The tracker consumes only :class:`Detection` objects. They carry no ground-truth identity
field by design - there is nowhere for an annotation track ID to enter online inference.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np


@dataclass(frozen=True)
class CameraDetection:
    """A raw detector output in the KITTI rectified camera frame (see ``geometry.boxes``)."""

    frame: int
    cls: str
    score: float
    bbox2d: np.ndarray  # (4,) x1, y1, x2, y2 in image_2 pixels
    loc: np.ndarray  # (3,) bottom-centre, rect camera frame [m]
    dims_hwl: np.ndarray  # (3,) h, w, l [m]
    ry: float  # rotation about camera y [rad]


@dataclass(frozen=True)
class Detection:
    """A tracker measurement: a 3D box in the tracking (z-up world) frame."""

    cls: str
    score: float
    box: np.ndarray  # (7,) [x, y, z, yaw, l, w, h], geometric centre
    det_id: int = -1  # index of the detection within its frame (provenance only)
    bbox2d: np.ndarray | None = field(default=None, compare=False)
