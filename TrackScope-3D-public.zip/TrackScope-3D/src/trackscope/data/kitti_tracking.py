"""KITTI Tracking sequence access: calibration, ego poses, LiDAR, images, timestamps.

Expected layout (as produced by ``scripts/download_data.py``)::

    <root>/training/calib/<seq>.txt
    <root>/training/oxts/<seq>.txt
    <root>/training/velodyne/<seq>/<frame:06d>.bin   (optional)
    <root>/training/image_02/<seq>/<frame:06d>.png   (optional)

Annotation files (``label_02``) are deliberately *not* accessed here; they are read only by
``trackscope.evaluation``.

Timing: the KITTI Tracking release has no per-frame timestamps. Frames are consecutive
10 Hz Velodyne sweeps, so ``t = 0.1 * frame`` seconds. The tracker itself accepts arbitrary
(variable) time steps.
"""

from __future__ import annotations

import struct
from functools import cached_property
from pathlib import Path

import numpy as np

from .calibration import KittiCalibration
from .oxts import load_oxts, oxts_to_poses

FRAME_PERIOD_S = 0.1
DEFAULT_IMAGE_SIZE = (1242, 375)


class KittiTrackingSequence:
    def __init__(self, root: str | Path, seq: str, split: str = "training"):
        self.root, self.seq, self.split = Path(root), seq, split
        self.base = self.root / split
        self.calib = KittiCalibration.from_file(self.base / "calib" / f"{seq}.txt")
        self.oxts = load_oxts(self.base / "oxts" / f"{seq}.txt")
        self.T_world_imu = oxts_to_poses(self.oxts)
        T_imu_rect = np.linalg.inv(self.calib.T_rect_imu)
        #: (N, 4, 4) pose of the rectified camera in the world frame, per frame
        self.T_world_rect = self.T_world_imu @ T_imu_rect
        self.T_world_velo = self.T_world_imu @ np.linalg.inv(self.calib.T_velo_imu)

    @property
    def num_frames(self) -> int:
        return len(self.oxts)

    def timestamp(self, frame: int) -> float:
        return FRAME_PERIOD_S * frame

    def velodyne_path(self, frame: int) -> Path:
        return self.base / "velodyne" / self.seq / f"{frame:06d}.bin"

    def image_path(self, frame: int) -> Path:
        return self.base / "image_02" / self.seq / f"{frame:06d}.png"

    def has_velodyne(self) -> bool:
        return self.velodyne_path(0).exists()

    def has_images(self) -> bool:
        return self.image_path(0).exists()

    def load_velodyne(self, frame: int) -> np.ndarray:
        """(N, 4) float32 [x, y, z, reflectance] in the Velodyne frame."""
        pts = np.fromfile(self.velodyne_path(frame), dtype=np.float32)
        if pts.size % 4:
            raise ValueError(f"{self.velodyne_path(frame)}: size not a multiple of 4 floats")
        return pts.reshape(-1, 4)

    @cached_property
    def image_size(self) -> tuple[int, int]:
        """(width, height) read from the first PNG header; KITTI default if unavailable."""
        p = self.image_path(0)
        if not p.exists():
            return DEFAULT_IMAGE_SIZE
        with open(p, "rb") as f:
            head = f.read(24)
        if head[:8] != b"\x89PNG\r\n\x1a\n":
            raise ValueError(f"{p}: not a PNG file")
        w, h = struct.unpack(">II", head[16:24])
        return int(w), int(h)
