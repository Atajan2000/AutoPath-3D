"""Loader for precomputed 3D detections in the AB3DMOT/KITTI layout.

File: ``<det_root>/<Class>/<seq>.txt``, one detection per comma-separated row::

    frame, type, x1, y1, x2, y2, score, h, w, l, x, y, z, ry, alpha

``type`` is 1=Pedestrian, 2=Car, 3=Cyclist. Boxes are in the rectified camera-0 frame with
the KITTI bottom-centre convention. PointRCNN scores are unnormalised logits (may be < 0).

This module reads **detector outputs only**; it never opens annotation files.
"""

from __future__ import annotations

from collections import defaultdict
from pathlib import Path

import numpy as np

from ..geometry.boxes import cam_box_to_zup
from ..types import CameraDetection, Detection

DET_TYPE_TO_CLASS = {1: "Pedestrian", 2: "Car", 3: "Cyclist"}
N_COLUMNS = 15


class DetectionFormatError(ValueError):
    pass


def parse_detection_line(line: str, source: str = "<line>") -> CameraDetection:
    parts = [p.strip() for p in line.strip().split(",")]
    if len(parts) != N_COLUMNS:
        raise DetectionFormatError(f"{source}: expected {N_COLUMNS} columns, got {len(parts)}")
    try:
        v = np.array([float(p) for p in parts])
    except ValueError as e:
        raise DetectionFormatError(f"{source}: non-numeric value") from e
    if not np.all(np.isfinite(v)):
        raise DetectionFormatError(f"{source}: non-finite value")
    if v[0] < 0 or v[0] != int(v[0]):
        raise DetectionFormatError(f"{source}: invalid frame index {v[0]}")
    det_type = int(v[1])
    if det_type not in DET_TYPE_TO_CLASS or v[1] != det_type:
        raise DetectionFormatError(f"{source}: unknown detection type {v[1]}")
    if np.any(v[7:10] <= 0):
        raise DetectionFormatError(f"{source}: non-positive box dimensions {v[7:10]}")
    return CameraDetection(
        frame=int(v[0]),
        cls=DET_TYPE_TO_CLASS[det_type],
        score=float(v[6]),
        bbox2d=v[2:6].copy(),
        dims_hwl=v[7:10].copy(),
        loc=v[10:13].copy(),
        ry=float(v[13]),
    )


def load_detection_file(path: str | Path) -> list[CameraDetection]:
    path = Path(path)
    out = []
    for i, line in enumerate(path.read_text().splitlines(), start=1):
        if line.strip():
            out.append(parse_detection_line(line, source=f"{path}:{i}"))
    return out


def load_sequence_detections(
    det_root: str | Path, seq: str, classes: list[str]
) -> dict[int, list[CameraDetection]]:
    """All detections of a sequence, grouped by frame (classes merged)."""
    by_frame: dict[int, list[CameraDetection]] = defaultdict(list)
    for cls in classes:
        path = Path(det_root) / cls / f"{seq}.txt"
        if not path.exists():
            raise FileNotFoundError(f"missing detection file {path}")
        for d in load_detection_file(path):
            if d.cls != cls:
                raise DetectionFormatError(f"{path}: row of class {d.cls} in {cls} file")
            by_frame[d.frame].append(d)
    return dict(by_frame)


def to_tracking_detections(
    cam_dets: list[CameraDetection], T_world_rect: np.ndarray
) -> list[Detection]:
    """Convert one frame's camera detections into world-frame tracker measurements."""
    return [
        Detection(
            cls=d.cls,
            score=d.score,
            box=cam_box_to_zup(d.loc, d.dims_hwl, d.ry, T_world_rect),
            det_id=i,
            bbox2d=d.bbox2d,
        )
        for i, d in enumerate(cam_dets)
    ]
