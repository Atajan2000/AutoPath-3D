"""KITTI Tracking calibration (``training/calib/<seq>.txt``).

The tracking calib files contain ``P0..P3`` (3x4), ``R_rect`` (3x3), ``Tr_velo_cam`` (3x4) and
``Tr_imu_velo`` (3x4). Keys are followed by ``:`` for the ``P*`` lines but not for the others,
so both forms are accepted.

Frames (see ``geometry.transforms`` for the ``T_a_b`` convention):

* ``imu``  - OXTS IMU frame (x fwd, y left, z up)
* ``velo`` - Velodyne HDL-64E frame (x fwd, y left, z up)
* ``cam``  - unrectified camera 0
* ``rect`` - rectified camera 0 (x right, y down, z fwd). **Labels and detections live here.**
* image    - pixel coordinates of the left colour camera (camera 2), reached with ``P2``.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np

_ALIASES = {"R0_rect": "R_rect", "Tr_velo_to_cam": "Tr_velo_cam", "Tr_imu_to_velo": "Tr_imu_velo"}


def _homog(m34: np.ndarray) -> np.ndarray:
    T = np.eye(4)
    T[:3, :4] = m34
    return T


@dataclass(frozen=True)
class KittiCalibration:
    P2: np.ndarray  # (3, 4) rect -> image_2 projection
    T_rect_cam: np.ndarray  # (4, 4) from R_rect
    T_cam_velo: np.ndarray  # (4, 4) from Tr_velo_cam
    T_velo_imu: np.ndarray  # (4, 4) from Tr_imu_velo

    @property
    def T_rect_velo(self) -> np.ndarray:
        return self.T_rect_cam @ self.T_cam_velo

    @property
    def T_rect_imu(self) -> np.ndarray:
        return self.T_rect_velo @ self.T_velo_imu

    @property
    def T_velo_rect(self) -> np.ndarray:
        return np.linalg.inv(self.T_rect_velo)

    def project_rect_to_image(self, pts_rect: np.ndarray):
        """Project (N, 3) rect-frame points with P2. Returns (uv (N, 2), depth (N,))."""
        p = np.asarray(pts_rect, float).reshape(-1, 3)
        uvw = np.hstack([p, np.ones((len(p), 1))]) @ self.P2.T
        depth = uvw[:, 2]
        with np.errstate(divide="ignore", invalid="ignore"):
            uv = uvw[:, :2] / depth[:, None]
        return uv, depth

    @classmethod
    def from_file(cls, path: str | Path) -> "KittiCalibration":
        return cls.from_text(Path(path).read_text(), source=str(path))

    @classmethod
    def from_text(cls, text: str, source: str = "<text>") -> "KittiCalibration":
        vals: dict[str, np.ndarray] = {}
        for line in text.splitlines():
            parts = line.replace(":", " ").split()
            if not parts:
                continue
            key = _ALIASES.get(parts[0], parts[0])
            try:
                vals[key] = np.array([float(v) for v in parts[1:]])
            except ValueError as e:
                raise ValueError(f"{source}: non-numeric calibration entry for {key}") from e
        expected = {"P2": 12, "R_rect": 9, "Tr_velo_cam": 12, "Tr_imu_velo": 12}
        for key, n in expected.items():
            if key not in vals:
                raise ValueError(f"{source}: missing calibration key {key}")
            if vals[key].size != n:
                raise ValueError(f"{source}: {key} has {vals[key].size} values, expected {n}")
        T_rect_cam = np.eye(4)
        T_rect_cam[:3, :3] = vals["R_rect"].reshape(3, 3)
        return cls(
            P2=vals["P2"].reshape(3, 4),
            T_rect_cam=T_rect_cam,
            T_cam_velo=_homog(vals["Tr_velo_cam"].reshape(3, 4)),
            T_velo_imu=_homog(vals["Tr_imu_velo"].reshape(3, 4)),
        )
