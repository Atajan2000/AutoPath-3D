"""OXTS GPS/IMU -> ego poses (KITTI raw devkit convention).

Each OXTS row has 30 values; we use lat, lon, alt (deg, deg, m) and roll, pitch, yaw (rad).
Positions use the devkit's Mercator projection with the scale fixed by the first frame's
latitude; orientation is ``R = Rz(yaw) Ry(pitch) Rx(roll)``. The resulting ``world`` frame is
East-North-Up oriented (z aligned with gravity) with its origin at the first frame's IMU
position. Because z is gravity-aligned, BEV tracking in this frame is well defined.

These poses come from an RTK-GPS/IMU unit, not from LiDAR odometry; they are used only for
ego-motion compensation so that track velocities are expressed in a static world frame.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np

from ..geometry.transforms import make_se3, rot_x, rot_y, rot_z

EARTH_RADIUS = 6378137.0  # WGS84 equatorial radius used by the KITTI devkit


def load_oxts(path: str | Path) -> np.ndarray:
    data = np.loadtxt(path, ndmin=2)
    if data.shape[1] != 30:
        raise ValueError(f"{path}: expected 30 OXTS columns, got {data.shape[1]}")
    if not np.all(np.isfinite(data[:, :6])):
        raise ValueError(f"{path}: non-finite OXTS pose values")
    return data


def oxts_to_poses(oxts: np.ndarray) -> np.ndarray:
    """(N, 30) OXTS rows -> (N, 4, 4) ``T_world_imu``."""
    lat0 = oxts[0, 0]
    scale = np.cos(np.deg2rad(lat0))
    poses = np.empty((len(oxts), 4, 4))
    origin = None
    for i, row in enumerate(oxts):
        lat, lon, alt, roll, pitch, yaw = row[:6]
        tx = scale * EARTH_RADIUS * np.deg2rad(lon)
        ty = scale * EARTH_RADIUS * np.log(np.tan(np.deg2rad(90.0 + lat) / 2.0))
        t = np.array([tx, ty, alt])
        if origin is None:
            origin = t.copy()
        poses[i] = make_se3(rot_z(yaw) @ rot_y(pitch) @ rot_x(roll), t - origin)
    return poses
