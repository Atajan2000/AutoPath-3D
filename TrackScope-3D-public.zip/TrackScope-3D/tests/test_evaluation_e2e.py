"""End-to-end: synthetic sequence -> tracker -> evaluation -> error attribution."""

import numpy as np

from trackscope.config import DataConfig, ExperimentConfig, tracker_config_from_dict
from trackscope.evaluation.analysis import attribute_errors, load_frame_records
from trackscope.evaluation.ground_truth import load_ground_truth
from trackscope.evaluation.runner import evaluate_detector, evaluate_tracking, load_tracker_results
from trackscope.data.detections import load_sequence_detections
from trackscope.geometry.boxes import zup_box_to_cam
from trackscope.pipeline import run_experiment

N = 30
GAP = range(12, 16)  # 4 missed frames > max_age = 2 -> track is deleted and re-born


def car(f):
    return (15.0 + 0.6 * f, 2.5, 0.0)  # world frame, slower than the 8 m/s ego


def test_attribution_on_synthetic_gap(synthetic_kitti, tmp_path):
    root, det_dir, seq = synthetic_kitti({"car": lambda f: None if f in GAP else car(f)}, n_frames=N)
    # perfect ground truth for every frame (also during the detection gap)
    lines = []
    for f in range(N):
        loc, dims, ry = zup_box_to_cam([*car(f)[:2], 0.75, 0.0, 3.9, 1.6, 1.5], np.linalg.inv(seq.T_world_rect[f]))
        lines.append(f"{f} 7 Car 0 0 0 100 100 200 200 {dims[0]} {dims[1]} {dims[2]} "
                     f"{loc[0]} {loc[1]} {loc[2]} {ry}")
    (root / "training" / "label_02" / "0000.txt").write_text("\n".join(lines) + "\n")

    cfg = ExperimentConfig(name="syn", data=DataConfig(kitti_root=str(root), detections_root=str(det_dir),
                                                       sequences=("0000",)),
                           tracker=tracker_config_from_dict({}), output_dir=str(tmp_path / "res"))
    run_experiment(cfg)
    gt = load_ground_truth(root / "training" / "label_02" / "0000.txt")
    dets = load_sequence_detections(det_dir, "0000", ["Car", "Pedestrian", "Cyclist"])
    trk = load_tracker_results(tmp_path / "res" / "syn" / "kitti", "0000")
    se = evaluate_tracking(gt, trk, N, "0000", "Car", "3d", 0.25)
    c = se.counts

    # detector is perfect except in the gap
    d = evaluate_detector(gt, dets, N, "Car", "3d", 0.25)
    assert (d["TP"], d["FP"], d["FN"]) == (N - len(GAP), 0, len(GAP))

    # tracker: 2 initiation frames + 4 gap frames + 2 re-initiation frames missed, one ID switch
    assert c["FP"] == 0 and c["IDSW"] == 1 and c["FN"] == 2 + len(GAP) + 2
    # TrackEval-compatible Frag skips frames without tracker output -> misses this interruption
    assert c["Frag"] == 0 and c["Frag_strict"] == 1

    a = attribute_errors(se, gt, dets, load_frame_records(tmp_path / "res" / "syn" / "frames" / "0000.jsonl"),
                         score_threshold=0.0, max_age=2)
    assert a["fn"] == {"initiation_delay": 4, "detector_miss": 4}
    assert a["idsw"] == {"detector_gap": 1} and a["frag"] == {"detector_gap": 1}
    ev = a["idsw_events"][0]
    assert ev["frame"] == GAP[-1] + 3 and ev["last_match_frame"] == GAP[0] - 1
