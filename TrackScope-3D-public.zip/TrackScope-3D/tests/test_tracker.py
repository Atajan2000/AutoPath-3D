"""Track lifecycle and multi-object scenarios on deterministic synthetic data."""

import numpy as np
import pytest

from conftest import make_det
from trackscope.tracking import AssociationConfig, LifecycleConfig, MultiObjectTracker, TrackerConfig
from trackscope.tracking.kalman import KalmanParams

DT = 0.1


def make_tracker(method="mahalanobis", **life):
    return MultiObjectTracker(TrackerConfig(
        kalman={"default": KalmanParams(), "Pedestrian": KalmanParams(sigma_acc=1.5, meas_pos=0.2, init_vel=2.5)},
        association=AssociationConfig(method=method),
        lifecycle=LifecycleConfig(**{"min_hits": 3, "max_age": 2, **life}),
    ))


def run(tracker, frames):
    return [tracker.step(f, f * DT, dets) for f, dets in enumerate(frames)]


def ids_per_object(results, frames_truth):
    """Map ground-truth object name -> set of output track IDs matched by det_id."""
    out = {}
    for res, truth in zip(results, frames_truth):
        for o in res.tracks:
            if o.source == "measured":
                out.setdefault(truth[o.det_id], set()).add(o.track_id)
    return out


def test_tentative_then_confirmed():
    trk = make_tracker()
    res = run(trk, [[make_det(10 + 0.5 * f, 0)] for f in range(5)])
    assert [len(r.tracks) for r in res] == [0, 0, 1, 1, 1]
    assert res[2].diagnostics.confirmed_now == [0]
    assert res[0].diagnostics.born == [0] and res[0].diagnostics.n_tentative == 1


def test_single_false_positive_never_reported():
    trk = make_tracker()
    frames = [[make_det(0, 0)]] + [[] for _ in range(4)]
    res = run(trk, frames)
    assert all(len(r.tracks) == 0 for r in res)
    assert res[1].diagnostics.deleted == [0] and trk.tracks == []


@pytest.mark.parametrize("gap, same_id", [(1, True), (2, True), (3, False)])
def test_missing_detections(gap, same_id):
    """Car at 10 m/s; detections dropped for ``gap`` frames. max_age=2 bridges <= 2 frames."""
    frames = [[make_det(1.0 * f, 0)] if not 8 <= f < 8 + gap else [] for f in range(20)]
    res = run(make_tracker(), frames)
    ids = {o.track_id for r in res for o in r.tracks if o.source == "measured"}
    assert (len(ids) == 1) is same_id
    if same_id:  # during the gap the track is reported only if output_lost; here it is lost
        assert res[8].diagnostics.lost_now == [0]


def test_coasting_tracks_reported_as_predicted():
    frames = [[make_det(1.0 * f, 0)] if f != 6 else [] for f in range(10)]
    res = run(make_tracker(output_lost=True), frames)
    o = res[6].tracks[0]
    assert o.source == "predicted" and o.status == "lost" and o.time_since_update == 1
    assert o.box[0] == pytest.approx(6.0, abs=0.3)  # extrapolated by the motion model
    assert res[7].tracks[0].source == "measured" and res[7].tracks[0].track_id == o.track_id


def test_crossing_objects_keep_identity():
    """Two cars on perpendicular paths through the same point, 0.3 s apart, with noise."""
    rng = np.random.default_rng(3)
    frames, truth = [], []
    for f in range(45):
        t = f * DT
        a = (-20 + 10 * t, 0.0, 0.0)  # eastbound, at origin at t = 2.0
        b = (0.0, -23 + 10 * t, np.pi / 2)  # northbound, at origin at t = 2.3
        dets, names = [], []
        for name, (x, y, yaw) in (("A", a), ("B", b)):
            n = rng.normal(0, 0.15, 2)
            dets.append(make_det(x + n[0], y + n[1], yaw=yaw, det_id=len(dets)))
            names.append(name)
        order = rng.permutation(2)  # detector output order carries no identity
        frames.append([dets[i] for i in order])
        truth.append({dets[i].det_id: names[i] for i in order})
    res = run(make_tracker(), frames)
    ids = ids_per_object(res, truth)
    assert len(ids["A"]) == 1 and len(ids["B"]) == 1 and ids["A"] != ids["B"]


def test_pedestrians_passing_keep_identity():
    """Two pedestrians walking toward each other, passing 0.9 m apart laterally."""
    rng = np.random.default_rng(4)
    frames, truth = [], []
    for f in range(60):
        t = f * DT
        p = {"L": (-4 + 1.4 * t, 0.45, 0.0), "R": (4 - 1.4 * t, -0.45, np.pi)}
        dets = [make_det(x + rng.normal(0, 0.1), y + rng.normal(0, 0.1), cls="Pedestrian", yaw=yaw, det_id=i)
                for i, (x, y, yaw) in enumerate(p.values())]
        frames.append(dets[::-1] if f % 2 else dets)
        truth.append(dict(enumerate(p)))
    ids = ids_per_object(run(make_tracker(), frames), truth)
    assert len(ids["L"]) == 1 and len(ids["R"]) == 1 and ids["L"] != ids["R"]


def test_ids_unique_and_never_reused():
    frames = [[make_det(0, 0)]] * 5 + [[]] * 4 + [[make_det(0, 0)]] * 5
    res = run(make_tracker(), frames)
    first = {o.track_id for r in res[:5] for o in r.tracks}
    second = {o.track_id for r in res[9:] for o in r.tracks}
    assert first and second and first.isdisjoint(second)


def test_empty_frames_and_empty_sequence():
    trk = make_tracker()
    res = run(trk, [[] for _ in range(10)])
    assert all(r.tracks == [] and r.diagnostics.n_detections_in == 0 for r in res)


def test_timestamps_must_increase():
    trk = make_tracker()
    trk.step(0, 0.0, [])
    with pytest.raises(ValueError):
        trk.step(1, 0.0, [])


def test_variable_frame_gaps():
    """Frames dropped at the sensor level (t jumps by 0.3 s) - still one track, right speed."""
    trk = make_tracker()
    ts = [0.0, 0.1, 0.2, 0.5, 0.6, 0.7, 1.0, 1.1, 1.2, 1.3]
    outs = [trk.step(i, t, [make_det(10 * t, 0)]) for i, t in enumerate(ts)]
    ids = {o.track_id for r in outs for o in r.tracks}
    assert ids == {0}
    assert outs[-1].tracks[0].velocity[0] == pytest.approx(10.0, abs=1.0)


def test_score_threshold_and_class_filter():
    trk = MultiObjectTracker(TrackerConfig(classes=("Car",), score_threshold={"Car": 1.0}))
    r = trk.step(0, 0.0, [make_det(0, 0, score=0.5), make_det(5, 5, score=2.0),
                          make_det(9, 9, cls="Pedestrian")])
    assert r.diagnostics.n_detections_used == 1 and r.diagnostics.born == [0]


@pytest.mark.parametrize("method", ["center", "mahalanobis", "iou"])
def test_all_methods_track_simple_scene(method):
    frames = [[make_det(f * 0.8, 0, det_id=0), make_det(30 - f * 0.5, 6, det_id=1)] for f in range(30)]
    res = run(make_tracker(method), frames)
    ids = ids_per_object(res, [{0: "a", 1: "b"}] * 30)
    assert len(ids["a"]) == 1 and len(ids["b"]) == 1
