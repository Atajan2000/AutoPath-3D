import numpy as np
import pytest

from conftest import make_det
from trackscope.tracking.association import AssociationConfig, TrackPrediction, associate


def pred(x, y, cls="Car", tid=0, S=0.3, dt=0.1, l=3.9, w=1.6, h=1.5):
    return TrackPrediction(track_id=tid, cls=cls, box=np.array([x, y, 0.8, 0.0, l, w, h]),
                           S_pos=np.eye(3) * S**2, last_meas_pos=np.array([x, y, 0.8]), time_since_meas=dt)


@pytest.mark.parametrize("method", ["center", "mahalanobis", "iou"])
def test_swapped_order(method):
    trks = [pred(0, 0, tid=0), pred(10, 0, tid=1)]
    dets = [make_det(10.2, 0.1), make_det(0.1, -0.1)]
    r = associate(trks, dets, AssociationConfig(method=method))
    assert sorted(r.matches) == [(0, 1), (1, 0)]
    assert r.unmatched_tracks == [] and r.unmatched_dets == []


@pytest.mark.parametrize("method", ["center", "mahalanobis", "iou"])
def test_far_detection_gated(method):
    r = associate([pred(0, 0)], [make_det(5.0, 0)], AssociationConfig(method=method))
    assert r.matches == [] and r.unmatched_tracks == [0] and r.unmatched_dets == [0]
    assert r.rejections[0][2] in ("gate", "speed")


@pytest.mark.parametrize("method", ["center", "mahalanobis", "iou"])
def test_class_mismatch_never_matches(method):
    r = associate([pred(0, 0, cls="Car")], [make_det(0, 0, cls="Cyclist")], AssociationConfig(method=method))
    assert r.matches == []


def test_speed_plausibility_rejects_teleport():
    # huge centre gate, but a pedestrian cannot move 5 m in 0.1 s
    cfg = AssociationConfig(method="center", center_gate={"Pedestrian": 100.0})
    t = pred(0, 0, cls="Pedestrian", l=0.8, w=0.6, h=1.7)
    r = associate([t], [make_det(5.0, 0, cls="Pedestrian")], cfg)
    assert r.matches == [] and r.rejections[0][2] == "speed"
    # ... but after 2 s without a measurement the same displacement is plausible
    t2 = pred(0, 0, cls="Pedestrian", l=0.8, w=0.6, h=1.7, dt=2.0)
    assert associate([t2], [make_det(5.0, 0, cls="Pedestrian")], cfg).matches == [(0, 0)]


def test_size_consistency():
    r = associate([pred(0, 0)], [make_det(0.2, 0, dims=(12.0, 2.5, 3.5))], AssociationConfig(method="center"))
    assert r.matches == [] and r.rejections[0][2] == "size"


def test_hungarian_beats_greedy():
    # greedy would take B-d1 (0.7) first and leave A with d2 (2.6): total 3.3.
    # The optimum is A-d1 (0.8) + B-d2 (1.1) = 1.9.
    trks = [pred(0.0, 0, tid=0), pred(1.5, 0, tid=1)]
    dets = [make_det(0.8, 0), make_det(2.6, 0)]
    r = associate(trks, dets, AssociationConfig(method="center"))
    assert sorted(r.matches) == [(0, 0), (1, 1)]


def test_mahalanobis_uses_uncertainty():
    cfg = AssociationConfig(method="mahalanobis")
    det = [make_det(2.0, 0)]
    assert associate([pred(0, 0, S=0.3)], det, cfg).matches == []  # 6.7 sigma away
    assert associate([pred(0, 0, S=1.5)], det, cfg).matches == [(0, 0)]  # 1.3 sigma


def test_empty_inputs():
    cfg = AssociationConfig()
    r = associate([], [make_det(0, 0)], cfg)
    assert r.matches == [] and r.unmatched_dets == [0]
    r = associate([pred(0, 0)], [], cfg)
    assert r.matches == [] and r.unmatched_tracks == [0]


def test_bad_config():
    with pytest.raises(ValueError):
        AssociationConfig(method="nearest")
