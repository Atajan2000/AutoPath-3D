"""Shared deterministic fixtures."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pytest

from trackscope.data.oxts import EARTH_RADIUS
from trackscope.types import Detection

REPO = Path(__file__).resolve().parents[1]
REAL_KITTI = REPO / "data" / "kitti_tracking"
REAL_DETS = REPO / "data" / "detections" / "pointrcnn"

requires_real_data = pytest.mark.skipif(
    not (REAL_KITTI / "training" / "calib" / "0014.txt").exists()
    or not (REAL_DETS / "Car" / "0014.txt").exists(),
    reason="real KITTI data not downloaded (run scripts/download_data.py)",
)

DIMS = {"Car": (3.9, 1.6, 1.5), "Pedestrian": (0.8, 0.6, 1.7), "Cyclist": (1.8, 0.6, 1.7)}  # l, w, h


def make_det(x, y, cls="Car", yaw=0.0, score=5.0, z=0.8, det_id=-1, dims=None) -> Detection:
    l, w, h = dims or DIMS[cls]
    return Detection(cls=cls, score=score, box=np.array([x, y, z, yaw, l, w, h], float), det_id=det_id)


# --- synthetic KITTI-layout dataset -------------------------------------------------------------
# rect camera = velo rotated (x_c = -y_v, y_c = -z_v, z_c = x_v); imu == velo; R_rect = I.
SYN_TR_VELO_CAM = np.array([[0, -1, 0, 0], [0, 0, -1, 0], [1, 0, 0, 0]], float)
SYN_P2 = np.array([[700.0, 0, 600, 45.0], [0, 700.0, 180, 0], [0, 0, 1, 0]])
SYN_LAT, SYN_LON = 49.0, 8.4


def synthetic_calib_text() -> str:
    def fmt(m):
        return " ".join(f"{v:.12e}" for v in np.asarray(m).ravel())

    p = "\n".join(f"P{i}: {fmt(SYN_P2)}" for i in range(4))
    return (f"{p}\nR_rect {fmt(np.eye(3))}\nTr_velo_cam {fmt(SYN_TR_VELO_CAM)}\n"
            f"Tr_imu_velo {fmt(np.hstack([np.eye(3), np.zeros((3, 1))]))}\n")


def synthetic_oxts_rows(n: int, ego_speed: float) -> np.ndarray:
    """Ego drives due east (yaw = 0) at ``ego_speed`` m/s, 10 Hz."""
    rows = np.zeros((n, 30))
    scale = np.cos(np.deg2rad(SYN_LAT))
    for i in range(n):
        east = ego_speed * 0.1 * i
        rows[i, 0] = SYN_LAT
        rows[i, 1] = SYN_LON + np.rad2deg(east / (scale * EARTH_RADIUS))
        rows[i, 2] = 110.0
    return rows


@pytest.fixture
def synthetic_kitti(tmp_path):
    """Write a 30-frame synthetic sequence '0000' with a moving ego and objects.

    Returns a function ``build(objects_world)`` where ``objects_world`` maps an object name to
    a callable ``frame -> (x, y, yaw) or None`` in the world frame; detections are written in
    the rectified camera frame of each frame, exactly as a detector would output them.
    """

    def build(objects_world: dict, n_frames: int = 30, ego_speed: float = 8.0, cls: str = "Car"):
        from trackscope.data.kitti_tracking import KittiTrackingSequence
        from trackscope.geometry.boxes import zup_box_to_cam

        root = tmp_path / "kitti"
        (root / "training" / "calib").mkdir(parents=True)
        (root / "training" / "oxts").mkdir(parents=True)
        (root / "training" / "label_02").mkdir(parents=True)
        (root / "training" / "calib" / "0000.txt").write_text(synthetic_calib_text())
        np.savetxt(root / "training" / "oxts" / "0000.txt", synthetic_oxts_rows(n_frames, ego_speed), fmt="%.12f")
        # a label file exists on disk so the leakage test can assert it is never opened
        (root / "training" / "label_02" / "0000.txt").write_text(
            "0 7 Car 0 0 0 0 0 10 10 1.5 1.6 3.9 0 1 10 0\n")
        seq = KittiTrackingSequence(root, "0000")
        det_dir = tmp_path / "dets"
        for c in ("Car", "Pedestrian", "Cyclist"):
            (det_dir / c).mkdir(parents=True)
            (det_dir / c / "0000.txt").write_text("")
        l, w, h = DIMS[cls]
        type_id = {"Pedestrian": 1, "Car": 2, "Cyclist": 3}[cls]
        lines = []
        for f in range(n_frames):
            T_rect_world = np.linalg.inv(seq.T_world_rect[f])
            for fn in objects_world.values():
                s = fn(f)
                if s is None:
                    continue
                x, y, yaw = s
                loc, dims, ry = zup_box_to_cam([x, y, 0.75, yaw, l, w, h], T_rect_world)
                lines.append(f"{f},{type_id},100,100,200,200,8.0,{dims[0]},{dims[1]},{dims[2]},"
                             f"{loc[0]},{loc[1]},{loc[2]},{ry},0.0")
        (det_dir / cls / "0000.txt").write_text("\n".join(lines) + "\n")
        return root, det_dir, seq

    return build
