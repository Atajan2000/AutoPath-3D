import numpy as np
import pytest

from trackscope.geometry import (
    T_ZUP_CAM, box7_corners, cam_box_corners, cam_box_to_zup, invert_se3, iou_3d, iou_bev,
    iou_matrix, kitti_alpha, make_se3, points_in_box7, rot_y, rot_z, transform_points,
    wrap_angle, zup_box_to_cam,
)


class TestAngles:
    @pytest.mark.parametrize("a, expected", [
        (0.0, 0.0), (np.pi, -np.pi), (-np.pi, -np.pi), (3 * np.pi, -np.pi),
        (2 * np.pi + 0.5, 0.5), (-2 * np.pi - 0.5, -0.5), (np.pi - 1e-9, np.pi - 1e-9),
    ])
    def test_wrap(self, a, expected):
        assert wrap_angle(a) == pytest.approx(expected, abs=1e-12)

    def test_wrap_vectorised_range(self):
        a = np.linspace(-20, 20, 1001)
        w = wrap_angle(a)
        assert np.all(w >= -np.pi) and np.all(w < np.pi)
        assert np.allclose(np.sin(w), np.sin(a)) and np.allclose(np.cos(w), np.cos(a))


class TestTransforms:
    def test_inverse(self):
        T = make_se3(rot_z(0.7) @ rot_y(-0.2), [1.0, -2.0, 3.0])
        assert np.allclose(invert_se3(T) @ T, np.eye(4))
        assert np.allclose(invert_se3(T), np.linalg.inv(T))

    def test_transform_points_single_and_batch(self):
        T = make_se3(rot_z(np.pi / 2), [1, 0, 0])
        assert np.allclose(transform_points(T, [1, 0, 0]), [1, 1, 0])
        assert transform_points(T, np.zeros((5, 3))).shape == (5, 3)


class TestBoxConventions:
    def test_cam_to_zup_known_values(self):
        # KITTI bottom-centre loc; h = 1.5 so geometric centre is 0.75 m above (y is down)
        b = cam_box_to_zup([1.0, 1.5, 10.0], [1.5, 1.6, 3.9], ry=0.0, T_zup_cam=T_ZUP_CAM)
        assert np.allclose(b[:3], [10.0, -1.0, -0.75])
        assert np.allclose(b[4:], [3.9, 1.6, 1.5])  # l, w, h order
        assert b[3] == pytest.approx(-np.pi / 2)  # ry = 0 faces camera +x = z-up -y
        b2 = cam_box_to_zup([0, 1.5, 10.0], [1.5, 1.6, 3.9], ry=-np.pi / 2, T_zup_cam=T_ZUP_CAM)
        assert b2[3] == pytest.approx(0.0, abs=1e-12)  # ry = -pi/2 faces forward

    @pytest.mark.parametrize("seed", range(5))
    def test_roundtrip_with_yaw_only_pose(self, seed):
        rng = np.random.default_rng(seed)
        # camera rotated about its own y axis (vehicle heading) + translation: exact roundtrip
        T_world_cam = T_ZUP_CAM @ make_se3(rot_y(rng.uniform(-3, 3)), rng.normal(size=3) * 20)
        loc, dims, ry = rng.normal(size=3) * 10, rng.uniform(0.5, 4, 3), rng.uniform(-np.pi, np.pi)
        b = cam_box_to_zup(loc, dims, ry, T_world_cam)
        loc2, dims2, ry2 = zup_box_to_cam(b, invert_se3(T_world_cam))
        assert np.allclose(loc2, loc) and np.allclose(dims2, dims)
        assert wrap_angle(ry2 - ry) == pytest.approx(0.0, abs=1e-9)

    def test_corner_sets_agree_between_parameterisations(self):
        loc, dims, ry = np.array([2.0, 1.6, 15.0]), np.array([1.5, 1.7, 4.2]), 0.4
        cam = transform_points(T_ZUP_CAM, cam_box_corners(loc, dims, ry))
        zup = box7_corners(cam_box_to_zup(loc, dims, ry, T_ZUP_CAM))
        key = lambda c: np.lexsort(np.round(c, 6).T)  # noqa: E731
        assert np.allclose(cam[key(cam)], zup[key(zup)], atol=1e-9)

    def test_alpha_matches_kitti_label(self):
        # from KITTI tracking training/label_02/0014.txt, frame 0, track 0 (alpha = 1.482157)
        assert kitti_alpha([-6.001341, 0.597486, 38.626173], 1.331191) == pytest.approx(1.482157, abs=5e-3)

    def test_points_in_box(self):
        b = np.array([0, 0, 0, np.pi / 4, 4.0, 2.0, 1.0])
        pts = np.array([[0, 0, 0], [1.3, 1.3, 0], [1.3, -1.3, 0], [0, 0, 0.6]])
        assert points_in_box7(pts, b).tolist() == [True, True, False, False]


class TestIoU:
    def test_identical_and_disjoint(self):
        a = np.array([0, 0, 0, 0.3, 4, 2, 1.5])
        assert iou_3d(a, a) == pytest.approx(1.0)
        assert iou_bev(a, a) == pytest.approx(1.0)
        assert iou_3d(a, a + [20, 0, 0, 0, 0, 0, 0]) == 0.0

    def test_half_shift(self):
        a = np.array([0, 0, 0, 0, 1, 1, 1.0])
        assert iou_bev(a, a + [0.5, 0, 0, 0, 0, 0, 0]) == pytest.approx(1 / 3)
        assert iou_3d(a, a + [0, 0, 0.5, 0, 0, 0, 0]) == pytest.approx(1 / 3)

    def test_rotated_square_octagon(self):
        a = np.array([0, 0, 0, 0, 1, 1, 1.0])
        b = np.array([0, 0, 0, np.pi / 4, 1, 1, 1.0])
        inter = 2 * (np.sqrt(2) - 1)
        assert iou_bev(a, b) == pytest.approx(inter / (2 - inter), rel=1e-9)

    def test_rotation_by_pi_is_same_box(self):
        a = np.array([1, 2, 0, 0.2, 4, 2, 1.5])
        assert iou_3d(a, a + [0, 0, 0, np.pi, 0, 0, 0]) == pytest.approx(1.0)

    def test_matrix(self):
        a = np.array([[0, 0, 0, 0, 1, 1, 1.0], [10, 0, 0, 0, 1, 1, 1.0]])
        m = iou_matrix(a, a[::-1])
        assert np.allclose(m, [[0, 1], [1, 0]])
