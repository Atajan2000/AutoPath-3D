"""Visualisation correctness: replay reconstruction, colours, projection, BEV, events, recording."""

import dataclasses
import json
import subprocess
import sys
from pathlib import Path

import numpy as np
import pytest

from conftest import REAL_DETS, REAL_KITTI, REPO, make_det, requires_real_data
from trackscope.tracking import LifecycleConfig, MultiObjectTracker, TrackerConfig
from trackscope.viz.overlays import (
    clip_segment_to_rect, footprint_world, id_color, project_box_edges, world_to_bev,
)
from trackscope.viz.replay import build_replay, load_events, load_replay

RESULTS = REPO / "results"
HAVE_RESULTS = (RESULTS / "pointrcnn_mahalanobis" / "frames" / "0014.jsonl").exists()
needs_results = pytest.mark.skipif(not HAVE_RESULTS, reason="saved tracking results not present")


def to_records(results):
    """FrameResult objects -> the JSONL record subset the replay reads."""
    out = []
    for r in results:
        d = dataclasses.asdict(r.diagnostics)
        out.append({"frame": r.frame, "t": r.t, "T_world_rect": np.eye(4).ravel().tolist(),
                    "T_world_velo": np.eye(4).ravel().tolist(), "detections": [], "diagnostics": d,
                    "tracks": [{"id": o.track_id, "cls": o.cls, "status": o.status, "source": o.source,
                                "box": o.box.tolist(), "velocity": o.velocity.tolist(), "pos_std": o.pos_std.tolist(),
                                "score": o.score, "hits": o.hits, "age": o.age,
                                "time_since_update": o.time_since_update, "det_id": o.det_id} for o in r.tracks]})
    return out


def run(frames, output_lost):
    trk = MultiObjectTracker(TrackerConfig(lifecycle=LifecycleConfig(output_lost=output_lost)))
    return [trk.step(f, 0.1 * f, d) for f, d in enumerate(frames)]


# ------------------------------------------------------------------ predicted-state reconstruction
def test_predicted_states_match_live_tracker_synthetic():
    frames = [[make_det(10 + 0.8 * f, 3, det_id=0)] if f not in (6, 7, 12) else [] for f in range(16)]
    replay = build_replay(to_records(run(frames, output_lost=False)))
    live = run(frames, output_lost=True)
    for rf, lf in zip(replay, live):
        want = {(o.track_id, o.source): o.box for o in lf.tracks}
        got = {(s.track_id, s.source): s.box for s in rf.tracks}
        assert want.keys() == got.keys(), rf.frame
        for k in want:
            assert np.allclose(want[k], got[k], atol=1e-9)
    assert [s.source for s in replay[6].tracks] == ["predicted"] and replay[6].tracks[0].time_since_update == 1
    assert replay[8].tracks[0].source == "measured" and replay[8].tracks[0].track_id == 0  # same ID resumes


def test_terminated_track_not_shown_and_new_id_not_reused():
    frames = [[make_det(10 + 0.8 * f, 3)] if not 6 <= f < 10 else [] for f in range(14)]
    replay = build_replay(to_records(run(frames, output_lost=False)))
    assert [len(r.tracks) for r in replay[6:10]] == [1, 1, 0, 0]  # 2 predicted frames, then deleted
    assert all(s.track_id != 0 for r in replay[10:] for s in r.tracks)


@requires_real_data
@needs_results
def test_predicted_states_match_live_tracker_real_0014():
    """Reconstruction from saved Mahalanobis outputs == live tracker with output_lost=True."""
    from trackscope.config import load_config
    from trackscope.data import KittiTrackingSequence, load_sequence_detections, to_tracking_detections
    cfg = load_config(REPO / "configs" / "default.yaml", {"tracker.lifecycle.output_lost": True})
    seq = KittiTrackingSequence(REAL_KITTI, "0014")
    dets = load_sequence_detections(REAL_DETS, "0014", list(cfg.tracker.classes))
    trk = MultiObjectTracker(cfg.tracker)
    replay = load_replay(RESULTS, "pointrcnn_mahalanobis", "0014")
    n_pred = 0
    for f, rf in enumerate(replay):
        live = trk.step(f, seq.timestamp(f), to_tracking_detections(dets.get(f, []), seq.T_world_rect[f]))
        want = {(o.track_id, o.source): o.box for o in live.tracks}
        got = {(s.track_id, s.source): s.box for s in rf.tracks}
        assert want.keys() == got.keys(), f
        for k in want:
            assert np.allclose(want[k], got[k], atol=2e-3), (f, k)  # saved JSON is rounded to 1e-4
        n_pred += len(rf.predicted)
    assert n_pred > 10


@needs_results
def test_history_ends_at_current_state_and_is_ordered():
    for rf in load_replay(RESULTS, "pointrcnn_mahalanobis", "0014"):
        for s in rf.tracks:
            h = rf.history[s.track_id]
            assert h[-1][0] == rf.frame and np.allclose(h[-1][1], s.box[:3])
            assert [x[0] for x in h] == sorted({x[0] for x in h})
            assert h[-1][2] == s.source


def test_empty_scene_replay():
    replay = build_replay(to_records(run([[] for _ in range(5)], output_lost=False)))
    assert all(r.tracks == [] and r.history == {} for r in replay)


# ------------------------------------------------------------------ colours
def test_id_colors_stable_and_distinct():
    assert id_color(7, "mahalanobis") == id_color(7, "mahalanobis")
    cols = [id_color(i, "mahalanobis")[:3] for i in range(20)]
    assert len(set(cols)) == 20
    d = [np.abs(np.subtract(cols[i], cols[i + 1])).sum() for i in range(19)]
    assert min(d) > 60  # consecutive IDs are visually different
    assert id_color(7, "center") != id_color(7, "iou")  # same number, independent trackers
    assert id_color(7, "m", predicted=True) != id_color(7, "m")


# ------------------------------------------------------------------ camera projection
P2 = np.array([[700.0, 0, 600, 0], [0, 700.0, 180, 0], [0, 0, 1, 0]])
T_RECT_WORLD = np.array([[0, -1, 0, 0], [0, 0, -1, 0], [1, 0, 0, 0], [0, 0, 0, 1.0]])  # world x fwd, z up


def test_projection_box_in_front_matches_centre():
    segs = project_box_edges([20, 0, 0, 0, 4, 1.8, 1.5], T_RECT_WORLD, P2, (1224, 370))
    a = np.vstack(segs)
    assert len(segs) == 14 and abs(a[:, 0].mean() - 600) < 1 and 150 < a[:, 1].mean() < 210


def test_projection_behind_camera_and_partial():
    assert project_box_edges([-20, 0, 0, 0, 4, 1.8, 1.5], T_RECT_WORLD, P2, (1224, 370)) == []
    segs = project_box_edges([1.0, 2.5, 0, 0, 4.5, 1.8, 1.5], T_RECT_WORLD, P2, (1224, 370))  # straddles z = 0
    assert segs and all(np.isfinite(s).all() for s in segs)


def test_overlays_never_leave_the_image():
    """Regression: unclipped segments (up to x = 18878 px in seq 0014) made the camera view re-fit
    its bounds every frame, which looked like camera shake."""
    rng = np.random.default_rng(0)
    for _ in range(300):
        box = [rng.uniform(-5, 60), rng.uniform(-30, 30), rng.uniform(-1, 1), rng.uniform(-3, 3), 4.2, 1.8, 1.5]
        for s in project_box_edges(box, T_RECT_WORLD, P2, (1224, 370)):
            assert s[:, 0].min() >= -1e-6 and s[:, 0].max() <= 1224 + 1e-6
            assert s[:, 1].min() >= -1e-6 and s[:, 1].max() <= 370 + 1e-6


def test_clip_segment():
    assert np.allclose(clip_segment_to_rect(np.array([[-10, 5], [10, 5]]), 100, 10), [[0, 5], [10, 5]])
    assert clip_segment_to_rect(np.array([[-10, -5], [-1, -1]]), 100, 10) is None
    assert np.allclose(clip_segment_to_rect(np.array([[1, 1], [2, 2]]), 100, 10), [[1, 1], [2, 2]])


@requires_real_data
@needs_results
def test_projected_tracks_agree_with_detector_2d_boxes_real():
    """Frame sync + calibration: a measured track's projected box overlaps the 2D box of the
    PointRCNN detection it was updated with (independent 2D output of the detector)."""
    from trackscope.data import KittiTrackingSequence, load_sequence_detections
    from trackscope.evaluation.protocol import box_iou_2d
    seq = KittiTrackingSequence(REAL_KITTI, "0014")
    dets = load_sequence_detections(REAL_DETS, "0014", ["Car", "Pedestrian", "Cyclist"])
    ious = []
    for rf in load_replay(RESULTS, "pointrcnn_mahalanobis", "0014")[::5]:
        T = np.linalg.inv(rf.T_world_rect)
        for s in rf.measured:
            segs = project_box_edges(s.box, T, seq.calib.P2, seq.image_size, front_cross=False)
            if segs:
                a = np.vstack(segs)
                bb = [a[:, 0].min(), a[:, 1].min(), a[:, 0].max(), a[:, 1].max()]
                ious.append(box_iou_2d([bb], [dets[rf.frame][s.det_id].bbox2d])[0, 0])
    assert len(ious) > 50 and np.median(ious) > 0.7


# ------------------------------------------------------------------ BEV
def test_bev_axes():
    T = np.eye(4)
    T[:3, 3] = [100, 50, 0]
    T[:3, :3] = [[0, -1, 0], [1, 0, 0], [0, 0, 1]]  # ego heading = world +y
    ahead, left = world_to_bev(np.array([[100, 60, 0], [90, 50, 0]]), T)
    assert np.allclose(ahead, [0, -10]) and np.allclose(left, [-10, 0])  # ahead = up, left = left
    fp = footprint_world([0, 0, 0, np.pi / 2, 4, 2, 1.5])
    assert np.allclose(fp[0], fp[-1]) and np.allclose(fp[0, :2], [-1, 2])  # closed, front-left first


# ------------------------------------------------------------------ evaluation events
@needs_results
def test_events_are_exactly_the_evaluation_rows():
    import csv
    rows = [r for r in csv.DictReader(open(RESULTS / "evaluation" / "failure_cases.csv"))
            if r["seq"] == "0016" and r["method"] == "center" and r["iou_thr"] == "0.25" and r["type"] in ("IDSW", "FRAG")]
    ev = load_events(RESULTS / "evaluation" / "failure_cases.csv", "0016", "center")
    assert len(ev) == len(rows)
    swap = [e for e in ev if e.kind == "IDSW" and e.cause == "identity_swap" and e.cls == "Car"]
    assert {(e.frame, e.old_track, e.new_track) for e in swap} == {(173, 0, 1), (175, 1, 435)}
    assert "swapped" in swap[0].describe()


# ------------------------------------------------------------------ recording + launcher
@requires_real_data
@needs_results
def test_launcher_writes_valid_recording(tmp_path):
    pytest.importorskip("rerun")
    out = tmp_path / "w.rrd"
    r = subprocess.run([sys.executable, str(REPO / "scripts" / "view.py"), "--frames", "60:66", "--compare",
                        "--save", str(out), "--no-open"], cwd=REPO, capture_output=True, text=True, timeout=300)
    assert r.returncode == 0, r.stderr
    assert out.exists() and out.stat().st_size > 1_000_000
    rerun_exe = Path(sys.executable).parent / ("rerun.exe" if sys.platform == "win32" else "rerun")
    p = subprocess.run([str(rerun_exe), "rrd", "verify", str(out)], capture_output=True, text=True, timeout=120)
    assert p.returncode == 0, p.stderr


@needs_results
def test_launcher_lists_events():
    r = subprocess.run([sys.executable, str(REPO / "scripts" / "view.py"), "--seq", "16", "--method", "center",
                        "--list-events"], cwd=REPO, capture_output=True, text=True, timeout=120)
    assert r.returncode == 0 and "frame  173" in r.stdout


def test_track_labels():
    pytest.importorskip("rerun")
    from trackscope.viz.rerun_view import track_label
    from trackscope.viz.replay import TrackState
    s = TrackState(7, "Car", np.zeros(7), np.array([3.0, 4.0]), "measured", "confirmed", 1.0, 5, 5, 0, 2)
    p = dataclasses.replace(s, source="predicted", status="lost", time_since_update=2)
    assert track_label(s, "mahalanobis", False) == "ID 7 Car 5.0 m/s"
    assert track_label(p, "mahalanobis", False) == "ID 7 Car PREDICTED (+2)"
    assert track_label(s, "center", True, short=True) == "C7" and track_label(p, "iou", True, short=True) == "I7 PRED"
