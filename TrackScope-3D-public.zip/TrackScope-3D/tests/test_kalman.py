import numpy as np
import pytest
from scipy.stats import chi2

from trackscope.tracking import kalman as kf

P = kf.KalmanParams()


def meas(x, y, z=0.8, yaw=0.0, l=3.9, w=1.6, h=1.5):
    return np.array([x, y, z, yaw, l, w, h], float)


def test_predict_constant_velocity_exact():
    x, Pm = kf.initiate(meas(1.0, 2.0), P)
    x[3:5] = [3.0, -1.0]
    x2, P2 = kf.predict(x, Pm, 0.5, P)
    assert np.allclose(x2[:3], [2.5, 1.5, 0.8])
    assert np.allclose(x2[3:5], [3.0, -1.0])
    assert np.all(np.diag(P2) >= np.diag(Pm) - 1e-12)  # uncertainty never shrinks on predict


def test_update_reduces_uncertainty():
    x, Pm = kf.initiate(meas(0, 0), P)
    x, Pm = kf.predict(x, Pm, 0.1, P)
    tr = np.trace(Pm)
    x, Pm, y, S, flipped = kf.update(x, Pm, meas(0.1, 0.0), P)
    assert np.trace(Pm) < tr and not flipped
    assert np.allclose(Pm, Pm.T) and np.all(np.linalg.eigvalsh(Pm) > 0)


def test_variable_dt_composes_exactly():
    """Q is the exact CWNA discretisation: one 0.2 s step == two 0.1 s steps."""
    x, Pm = kf.initiate(meas(0, 0), P)
    xa, Pa = kf.predict(*kf.predict(x, Pm, 0.1, P), 0.1, P)
    xb, Pb = kf.predict(x, Pm, 0.2, P)
    assert np.allclose(xa, xb) and np.allclose(Pa, Pb)


def test_negative_dt_rejected():
    x, Pm = kf.initiate(meas(0, 0), P)
    with pytest.raises(ValueError):
        kf.predict(x, Pm, -0.1, P)


def test_converges_to_true_velocity_noiseless():
    v = np.array([8.0, -2.0])
    x, Pm = kf.initiate(meas(0, 0), P)
    for k in range(1, 40):
        x, Pm = kf.predict(x, Pm, 0.1, P)
        x, Pm, *_ = kf.update(x, Pm, meas(*(v * 0.1 * k)), P)
    assert np.allclose(x[3:5], v, atol=1e-3)


@pytest.mark.parametrize("seed", range(5))
def test_velocity_error_consistent_with_covariance(seed):
    rng = np.random.default_rng(seed)
    v = np.array([8.0, -2.0])
    x, Pm = kf.initiate(meas(0, 0), P)
    for k in range(1, 40):
        x, Pm = kf.predict(x, Pm, 0.1, P)
        x, Pm, *_ = kf.update(x, Pm, meas(*(v * 0.1 * k + rng.normal(0, P.meas_pos, 2))), P)
    err = x[3:5] - v
    assert err @ np.linalg.solve(Pm[3:5, 3:5], err) < chi2.ppf(0.999, 2)
    assert np.sqrt(Pm[3, 3]) < P.init_vel / 5  # velocity became observable


def test_yaw_wraps_across_pi():
    x, Pm = kf.initiate(meas(0, 0, yaw=3.1), P)
    _, _, y, _, flipped = kf.update(x, Pm, meas(0, 0, yaw=-3.1), P)
    assert y[kf.YAW_MEAS] == pytest.approx(2 * np.pi - 6.2, abs=1e-9) and not flipped
    x2, *_ = kf.update(x, Pm, meas(0, 0, yaw=-3.1), P)
    assert abs(abs(x2[kf.IDX_YAW]) - np.pi) < 0.1  # stays near +-pi, never averages to 0


def test_front_back_flip():
    x, Pm = kf.initiate(meas(0, 0, yaw=0.0), P)
    x2, _, y, _, flipped = kf.update(x, Pm, meas(0, 0, yaw=np.pi - 0.05), P)
    assert flipped and y[kf.YAW_MEAS] == pytest.approx(-0.05, abs=1e-9)
    assert abs(x2[kf.IDX_YAW]) < 0.05


def test_filter_consistency_nis():
    """With data generated from the filter's own model, the mean NIS must match chi2(7)."""
    rng = np.random.default_rng(1)
    dt, n = 0.1, 3000
    Q, R = kf.process_noise(dt, P), P.R
    truth = np.zeros(kf.STATE_DIM)
    truth[3:5] = [5.0, 1.0]
    truth[6:9] = [3.9, 1.6, 1.5]
    x, Pm = kf.initiate(kf.H @ truth + rng.multivariate_normal(np.zeros(7), R), P)
    Lq = np.linalg.cholesky(Q + 1e-15 * np.eye(kf.STATE_DIM))
    nis = []
    for k in range(n):
        truth = kf.transition(dt) @ truth + Lq @ rng.normal(size=kf.STATE_DIM)
        z = kf.H @ truth + rng.multivariate_normal(np.zeros(7), R)
        x, Pm = kf.predict(x, Pm, dt, P)
        x, Pm, y, S, _ = kf.update(x, Pm, z, P)
        if k > 50:
            nis.append(y @ np.linalg.solve(S, y))
    lo, hi = chi2.ppf([0.005, 0.995], df=7 * len(nis)) / len(nis)  # 99% band for the mean
    assert lo < np.mean(nis) < hi
