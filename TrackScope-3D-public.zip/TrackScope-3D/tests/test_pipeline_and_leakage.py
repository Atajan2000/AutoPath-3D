"""End-to-end pipeline on a synthetic KITTI-layout sequence, and ground-truth isolation."""

import ast
import builtins
import dataclasses
import io
import json
import pathlib
from pathlib import Path

import numpy as np
import pytest

from conftest import REPO
from trackscope.config import ExperimentConfig, DataConfig, load_config
from trackscope.pipeline import run_experiment, run_sequence
from trackscope.types import Detection

SRC = REPO / "src" / "trackscope"
INFERENCE_PATHS = [SRC / "data", SRC / "tracking", SRC / "geometry", SRC / "pipeline.py",
                   SRC / "config.py", SRC / "types.py"]


def _py_files():
    for p in INFERENCE_PATHS:
        yield from (p.rglob("*.py") if p.is_dir() else [p])


def test_inference_code_never_imports_evaluation():
    for path in _py_files():
        tree = ast.parse(path.read_text(encoding="utf-8"))
        docstrings = {id(n.body[0].value) for n in ast.walk(tree)
                      if isinstance(n, (ast.Module, ast.ClassDef, ast.FunctionDef)) and n.body
                      and isinstance(n.body[0], ast.Expr) and isinstance(n.body[0].value, ast.Constant)}
        for node in ast.walk(tree):
            if id(node) in docstrings:
                continue
            names = []
            if isinstance(node, ast.Import):
                names = [a.name for a in node.names]
            elif isinstance(node, ast.ImportFrom):
                names = [("." * node.level) + (node.module or "")]
            for n in names:
                assert "evaluation" not in n and "ground_truth" not in n, f"{path}: imports {n}"
            if isinstance(node, ast.Constant) and isinstance(node.value, str):
                assert "label_02" not in node.value, f"{path}: references annotation dir"


def test_detection_type_has_no_identity_field():
    assert {f.name for f in dataclasses.fields(Detection)} == {"cls", "score", "box", "det_id", "bbox2d"}


def _cfg(root, det_dir, tmp_path, method="mahalanobis"):
    from trackscope.config import tracker_config_from_dict
    tr = tracker_config_from_dict({"association": {"method": method}})
    return ExperimentConfig(name="syn", data=DataConfig(kitti_root=str(root), detections_root=str(det_dir),
                                                        sequences=("0000",)),
                            tracker=tr, output_dir=str(tmp_path / "results"))


def test_pipeline_never_opens_annotations(synthetic_kitti, tmp_path, monkeypatch):
    root, det_dir, _ = synthetic_kitti({"parked": lambda f: (40.0, 3.0, 0.0)})
    opened = []
    real_open, real_io_open = builtins.open, io.open

    def spy(file, *a, **k):
        opened.append(str(file))
        return real_open(file, *a, **k)

    real_read_text = pathlib.Path.read_text

    def spy_read_text(self, *a, **k):
        opened.append(str(self))
        return real_read_text(self, *a, **k)

    monkeypatch.setattr(builtins, "open", spy)
    monkeypatch.setattr(io, "open", spy)
    monkeypatch.setattr(pathlib.Path, "read_text", spy_read_text)
    run_sequence(_cfg(root, det_dir, tmp_path), "0000", out_root=None)
    monkeypatch.setattr(builtins, "open", real_open)
    monkeypatch.setattr(io, "open", real_io_open)
    assert opened, "spy did not observe any file access"
    assert not any("label_02" in p for p in opened)


@pytest.mark.parametrize("method", ["center", "mahalanobis", "iou"])
def test_ego_compensated_velocity(synthetic_kitti, tmp_path, method):
    """Ego drives east at 8 m/s. A parked car must have ~0 world speed and a car driving
    alongside at 8 m/s must have ~8 m/s - even though in the sensor frame it is the parked
    car that appears to move and the escorting car that appears static."""
    root, det_dir, seq = synthetic_kitti({
        "parked": lambda f: (40.0, 3.5, 0.0),
        "escort": lambda f: (10.0 + 0.8 * f, -3.5, 0.0),
    }, n_frames=30, ego_speed=8.0)
    cfg = _cfg(root, det_dir, tmp_path, method)
    summary = run_experiment(cfg)
    assert summary["sequences"][0]["tracks_confirmed"] == 2
    recs = [json.loads(l) for l in open(Path(cfg.output_dir) / "syn" / "frames" / "0000.jsonl")]
    last = {round(t["box"][1]): t for t in recs[-1]["tracks"]}
    assert last[4]["speed"] == pytest.approx(0.0, abs=0.2)  # parked (y = +3.5)
    assert last[-4]["speed"] == pytest.approx(8.0, abs=0.2)  # escort (y = -3.5)


def test_kitti_output_roundtrip(synthetic_kitti, tmp_path):
    root, det_dir, seq = synthetic_kitti({"parked": lambda f: (40.0, 3.5, 0.3)}, n_frames=12)
    cfg = _cfg(root, det_dir, tmp_path)
    run_experiment(cfg)
    rows = (Path(cfg.output_dir) / "syn" / "kitti" / "0000.txt").read_text().splitlines()
    dets = {int(l.split(",")[0]): l.split(",") for l in (det_dir / "Car" / "0000.txt").read_text().splitlines()}
    assert len(rows) == 12 - 2  # confirmed from the 3rd frame on
    for r in rows:
        p = r.split()
        f = int(p[0])
        assert p[2] == "Car" and len(p) == 18
        out_loc = np.array(p[13:16], float)
        in_loc = np.array(dets[f][10:13], float)
        assert np.allclose(out_loc, in_loc, atol=0.1)  # filtered, so close but not identical
        assert abs(float(p[16]) - float(dets[f][13])) < 0.05


def test_default_config_loads():
    cfg = load_config(REPO / "configs" / "default.yaml", {"tracker.association.method": "iou",
                                                          "data.sequences": [1, "6"]})
    assert cfg.tracker.association.method == "iou"
    assert cfg.data.sequences == ("0001", "0006")
    assert cfg.tracker.kalman_for("Pedestrian").sigma_acc == 1.5
    assert cfg.tracker.kalman_for("Pedestrian").meas_yaw == 0.2  # inherited from kalman_default


def test_config_rejects_unknown_keys(tmp_path):
    p = tmp_path / "c.yaml"
    p.write_text("tracker:\n  association:\n    mehtod: center\n")
    with pytest.raises(ValueError, match="mehtod"):
        load_config(p)
