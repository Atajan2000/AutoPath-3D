"""Deterministic tests for evaluation preprocessing and tracking metrics."""

import numpy as np
import pytest

from trackscope.evaluation.ground_truth import KittiObject, load_kitti_tracking_file
from trackscope.evaluation.metrics import clear_mot, detection_counts, evaluate_frames, finalize, identity
from trackscope.evaluation.protocol import (
    AB3DMOT_TRAIN, AB3DMOT_VAL, DEV_SEQUENCES, HELDOUT_SEQUENCES, FrameEval, box_iou_2d,
    preprocess_frame, preprocess_sequence, similarity_3d,
)

try:
    from trackscope.evaluation.trackeval_bridge import import_trackeval, trackeval_metrics_on_frames
    import_trackeval()
    HAVE_TRACKEVAL = True
except Exception:  # pragma: no cover
    HAVE_TRACKEVAL = False
needs_trackeval = pytest.mark.skipif(not HAVE_TRACKEVAL, reason="TrackEval not installed")


def obj(tid, x=0.0, z=20.0, cls="Car", frame=0, ry=0.0, occ=0, trunc=0, dims=(1.5, 1.6, 3.9), bbox=None):
    h, w, l = dims
    bbox = np.array(bbox if bbox is not None else [100 + 10 * x, 150, 160 + 10 * x, 200], float)
    return KittiObject(frame=frame, track_id=tid, cls=cls, truncated=trunc, occluded=occ, alpha=0.0,
                       bbox2d=bbox, dims_hwl=np.array([h, w, l]), loc=np.array([x, 1.6, z]), ry=ry)


def seq_frames(gt_seq, trk_seq, cls="Car", mode="3d", thr=0.5):
    """gt_seq / trk_seq: list (per frame) of lists of objects."""
    gt = {f: o for f, o in enumerate(gt_seq)}
    trk = {f: o for f, o in enumerate(trk_seq)}
    return preprocess_sequence(gt, trk, len(gt_seq), cls, mode, thr)


def metrics(gt_seq, trk_seq, thr=0.5, **kw):
    c, ev = evaluate_frames(seq_frames(gt_seq, trk_seq, thr=thr, **kw), thr)
    return finalize(c), ev


# ---------------------------------------------------------------- core metric cases
def test_perfect_tracking():
    gt = [[obj(1, x=0), obj(2, x=8)] for _ in range(10)]
    m, ev = metrics(gt, [[obj(10, x=0), obj(20, x=8)] for _ in range(10)])
    assert (m["TP"], m["FP"], m["FN"], m["IDSW"], m["Frag"]) == (20, 0, 0, 0, 0)
    assert m["MOTA"] == 1.0 and m["IDF1"] == 1.0 and m["MT"] == 2 and m["MOTP"] == pytest.approx(1.0)


def test_identity_swap_between_two_objects():
    gt = [[obj(1, x=0), obj(2, x=8)] for _ in range(10)]
    trk = [[obj(10, x=0), obj(20, x=8)] if f < 5 else [obj(20, x=0), obj(10, x=8)] for f in range(10)]
    m, ev = metrics(gt, trk)
    assert m["IDSW"] == 2 and m["FP"] == 0 and m["FN"] == 0
    assert m["MOTA"] == pytest.approx((20 - 2) / 20)
    assert m["IDTP"] == 10 and m["IDF1"] == pytest.approx(0.5)  # identity-level, not frame-level
    assert sorted((e[0], e[1]) for e in ev.idsw) == [(5, 1), (5, 2)]


def test_idf1_is_identity_level():
    """Frame-by-frame every GT box is covered (MOTA 0.9), but half of the trajectory has the
    wrong identity, so IDF1 = 0.5."""
    gt = [[obj(1)] for _ in range(10)]
    trk = [[obj(10 if f < 5 else 11)] for f in range(10)]
    m, _ = metrics(gt, trk)
    assert m["MOTA"] == pytest.approx(0.9) and m["Recall"] == 1.0
    assert m["IDF1"] == pytest.approx(0.5) and m["IDTP"] == 5 and m["IDFP"] == 5 and m["IDFN"] == 5


def test_missed_detections_and_fragmentation_same_id():
    gt = [[obj(1)] for _ in range(10)]
    trk = [[obj(10)] if f not in (4, 5) else [obj(99, x=50)] for f in range(10)]  # far FP keeps frame non-empty
    m, ev = metrics(gt, trk)
    assert m["FN"] == 2 and m["FP"] == 2 and m["IDSW"] == 0 and m["Frag"] == 1
    assert ev.frag == [(6, 1, 10, 3)]


def test_fragmentation_with_new_id_counts_switch_after_gap():
    gt = [[obj(1)] for _ in range(10)]
    trk = [[obj(10)] if f < 4 else ([obj(99, x=50)] if f < 6 else [obj(11)]) for f in range(10)]
    m, ev = metrics(gt, trk)
    assert m["IDSW"] == 1 and m["Frag"] == 1  # IDSW counted against last match, frames earlier
    assert ev.idsw == [(6, 1, 10, 11, 3)]


def test_trackeval_quirk_empty_tracker_frame_is_not_interruption():
    gt = [[obj(1)] for _ in range(6)]
    trk = [[obj(10)] if f != 3 else [] for f in range(6)]
    m, ev = metrics(gt, trk)
    assert m["FN"] == 1 and m["Frag"] == 0  # documented TrackEval-compatible behaviour
    assert m["Frag_strict"] == 1 and ev.frag_strict == [(4, 1, 10, 2)]


def test_false_positives_only():
    gt = [[obj(1)] for _ in range(5)]
    trk = [[obj(10), obj(11, x=30)] for _ in range(5)]
    m, _ = metrics(gt, trk)
    assert m["FP"] == 5 and m["TP"] == 5 and m["MOTA"] == 0.0 and m["Precision"] == 0.5


def test_empty_sequences():
    m, _ = metrics([[] for _ in range(5)], [[] for _ in range(5)])
    assert m["GT"] == m["TP"] == m["FP"] == m["FN"] == 0 and m["MOTA"] == 0.0
    m, _ = metrics([[obj(1)] for _ in range(5)], [[] for _ in range(5)])
    assert m["FN"] == 5 and m["ML"] == 1 and m["IDF1"] == 0.0
    m, _ = metrics([[] for _ in range(5)], [[obj(1)] for _ in range(5)])
    assert m["FP"] == 5 and m["GT"] == 0


def test_match_priority_keeps_previous_identity():
    """A tracker object with lower IoU that continues the previous match beats a better one."""
    gt = [[obj(1)], [obj(1)]]
    trk = [[obj(10)], [obj(10, x=0.6), obj(11)]]
    m, _ = metrics(gt, trk, thr=0.25)
    assert m["IDSW"] == 0 and m["FP"] == 1


def test_mt_pt_ml():
    gt = [[obj(1), obj(2, x=8), obj(3, x=16)] for _ in range(10)]
    trk = [[obj(10)] + ([obj(20, x=8)] if f < 5 else []) + ([obj(30, x=16)] if f < 1 else [])
           for f in range(10)]
    m, _ = metrics(gt, trk)
    assert (m["MT"], m["PT"], m["ML"]) == (1, 1, 1)


# ---------------------------------------------------------------- ignore rules
def test_distractor_van_is_ignored():
    fe = preprocess_frame(0, [obj(1, cls="Van")], [obj(10)], "Car", "3d", 0.5)
    assert len(fe.trk_ids) == 0 and len(fe.gt_ids) == 0 and fe.removed == [(10, "distractor")]


def test_person_is_pedestrian_distractor():
    p = dict(cls="Pedestrian", dims=(1.7, 0.6, 0.8))
    fe = preprocess_frame(0, [obj(1, **{**p, "cls": "Person"})], [obj(10, **p)], "Pedestrian", "3d", 0.5)
    assert fe.removed == [(10, "distractor")]


def test_occluded_and_truncated_gt_ignored():
    for kw in ({"occ": 3}, {"trunc": 1}):
        fe = preprocess_frame(0, [obj(1, **kw)], [obj(10)], "Car", "3d", 0.5)
        assert len(fe.gt_ids) == 0 and fe.removed == [(10, "occluded_or_truncated_gt")]
    # unmatched tracker objects stay FPs even if an ignored GT is nearby
    fe = preprocess_frame(0, [obj(1, occ=3)], [obj(10, x=30)], "Car", "3d", 0.5)
    assert fe.trk_ids.tolist() == [10]


def test_dontcare_region_and_min_height():
    dc = obj(-1, cls="DontCare", bbox=[400, 100, 600, 300])
    inside = obj(10, x=50, bbox=[450, 150, 500, 200])  # 100 % inside DontCare, unmatched
    small = obj(11, x=80, bbox=[700, 150, 760, 175])  # height 25 px -> removed (<= 25)
    tall = obj(12, x=120, bbox=[800, 150, 860, 175.5])
    fe = preprocess_frame(0, [dc], [inside, small, tall], "Car", "3d", 0.5)
    assert dict(fe.removed) == {10: "dontcare_region", 11: "too_small"}
    assert fe.trk_ids.tolist() == [12]


def test_class_specific_evaluation():
    gt = [obj(1), obj(2, x=8, cls="Pedestrian", dims=(1.7, 0.6, 0.8))]
    trk = [obj(10), obj(20, x=8, cls="Pedestrian", dims=(1.7, 0.6, 0.8)), obj(30, x=20, cls="Cyclist")]
    car = preprocess_frame(0, gt, trk, "Car", "3d", 0.5)
    ped = preprocess_frame(0, gt, trk, "Pedestrian", "3d", 0.5)
    assert car.gt_ids.tolist() == [1] and car.trk_ids.tolist() == [10]
    assert ped.gt_ids.tolist() == [2] and ped.trk_ids.tolist() == [20]


# ---------------------------------------------------------------- 3D IoU / thresholds
def test_rotated_3d_boxes():
    a = obj(1, dims=(1.0, 1.0, 1.0))
    b = obj(10, dims=(1.0, 1.0, 1.0), ry=np.pi / 4)  # square rotated 45 deg about vertical
    inter = 2 * (np.sqrt(2) - 1)
    assert similarity_3d([a], [b])[0, 0] == pytest.approx(inter / (2 - inter), rel=1e-9)
    c = obj(10, dims=(1.5, 1.6, 3.9), ry=np.pi)  # same box, opposite heading
    assert similarity_3d([obj(1)], [c])[0, 0] == pytest.approx(1.0)
    d = obj(10, dims=(1.5, 1.6, 3.9), ry=np.pi / 2)  # car rotated 90 deg: 1.6x1.6 overlap
    assert similarity_3d([obj(1)], [d])[0, 0] == pytest.approx(1.6**2 / (2 * 1.6 * 3.9 - 1.6**2))


def test_threshold_boundaries():
    # shift along the length axis so IoU = (l - s) / (l + s) exactly 1/3 for s = l/2
    l = 4.0
    gt = [[obj(1, dims=(1.5, 1.6, l))]]
    trk = [[obj(10, x=l / 2, dims=(1.5, 1.6, l))]]  # ry=0 -> length along camera x
    sim = seq_frames(gt, trk, thr=0.25)[0].sim[0, 0]
    assert sim == pytest.approx(1 / 3)
    assert metrics(gt, trk, thr=1 / 3)[0]["TP"] == 1  # >= threshold (with eps) matches
    assert metrics(gt, trk, thr=1 / 3 + 1e-6)[0]["TP"] == 0
    assert metrics(gt, trk, thr=0.25)[0]["TP"] == 1 and metrics(gt, trk, thr=0.5)[0]["TP"] == 0


def test_monte_carlo_3d_iou_independent_check():
    """Rotated, offset boxes: polygon-clipping IoU vs. a Monte-Carlo volume estimate."""
    rng = np.random.default_rng(7)
    from trackscope.geometry import iou_3d, points_in_box7
    for _ in range(4):
        a = np.array([0, 0, 0, rng.uniform(-3, 3), 4.0, 1.8, 1.5])
        b = a + np.array([*rng.normal(0, 0.8, 2), rng.normal(0, 0.3), rng.uniform(-1, 1), 0, 0, 0])
        pts = rng.uniform(-4, 4, size=(400_000, 3)) * [1, 1, 0.5]
        vol = 8 * 8 * 4 / len(pts)
        ia, ib = points_in_box7(pts, a), points_in_box7(pts, b)
        inter = (ia & ib).sum() * vol
        mc = inter / (a[4] * a[5] * a[6] + b[4] * b[5] * b[6] - inter)
        assert iou_3d(a, b) == pytest.approx(mc, abs=0.01)


def test_box_iou_2d_and_ioa():
    a = np.array([[0, 0, 10, 10]])
    assert box_iou_2d(a, [[5, 0, 15, 10]])[0, 0] == pytest.approx(50 / 150)
    assert box_iou_2d([[0, 0, 4, 4]], a, ioa=True)[0, 0] == 1.0


def test_detection_counts():
    fe = FrameEval(0, np.array([1, 2]), np.array([7, 8, 9]), np.array([[0.9, 0.1, 0.0], [0.0, 0.3, 0.6]]))
    assert detection_counts([fe], 0.5) == {"GT": 2, "TRK": 3, "TP": 2, "FP": 1, "FN": 0,
                                           "MOTP_sum": pytest.approx(1.5), "frames": 1}


def test_duplicate_ids_rejected():
    with pytest.raises(ValueError):
        seq_frames([[obj(1)]], [[obj(10), obj(10, x=20)]])


def test_result_file_roundtrip(tmp_path):
    p = tmp_path / "r.txt"
    p.write_text("3 5 Car -1 -1 0.1 10 20 30 40 1.5 1.6 3.9 1.0 1.6 20.0 0.2 7.5\n")
    (o,) = load_kitti_tracking_file(p)[3]
    assert o.track_id == 5 and o.score == 7.5 and o.truncated == -1
    p.write_text("3 5 Car -1\n")
    with pytest.raises(ValueError):
        load_kitti_tracking_file(p)


# ---------------------------------------------------------------- split integrity
def test_split_integrity():
    assert set(DEV_SEQUENCES).isdisjoint(HELDOUT_SEQUENCES)
    assert set(DEV_SEQUENCES) | set(HELDOUT_SEQUENCES) == set(AB3DMOT_VAL)
    assert set(AB3DMOT_VAL).isdisjoint(AB3DMOT_TRAIN) and len(AB3DMOT_VAL) + len(AB3DMOT_TRAIN) == 21


# ---------------------------------------------------------------- independent cross-check
def _random_frames(rng, n_frames=40, n_gt=6, n_trk=9):
    frames = []
    for f in range(n_frames):
        g = np.sort(rng.choice(n_gt, rng.integers(0, n_gt + 1), replace=False)) + 100
        t = np.sort(rng.choice(n_trk, rng.integers(0, n_trk + 1), replace=False)) + 500
        sim = rng.uniform(0, 1, (len(g), len(t))) ** 2
        frames.append(FrameEval(f, g.astype(int), t.astype(int), sim))
    return frames


@needs_trackeval
@pytest.mark.parametrize("seed", range(25))
@pytest.mark.parametrize("thr", [0.25, 0.5])
def test_metrics_agree_with_trackeval(seed, thr):
    frames = _random_frames(np.random.default_rng(seed))
    ours, _ = clear_mot(frames, thr)
    ours.update(identity(frames, thr))
    ours = finalize(ours)
    ref = trackeval_metrics_on_frames(frames, thr)
    for k in ("TP", "FP", "FN", "IDSW", "Frag", "MT", "PT", "ML", "IDTP", "IDFP", "IDFN"):
        assert ours[k] == ref[k], k
    assert ours["MOTA"] == pytest.approx(ref["MOTA"]) and ours["IDF1"] == pytest.approx(ref["IDF1"])
