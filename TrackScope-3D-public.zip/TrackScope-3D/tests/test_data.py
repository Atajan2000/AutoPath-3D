"""Calibration, ego poses, detection parsing and malformed-input handling."""

import numpy as np
import pytest

from conftest import REAL_DETS, REAL_KITTI, requires_real_data, synthetic_calib_text, synthetic_oxts_rows
from trackscope.data import (
    DetectionFormatError, KittiCalibration, KittiTrackingSequence, load_detection_file,
    load_sequence_detections, oxts_to_poses, parse_detection_line, to_tracking_detections,
)
from trackscope.data.oxts import EARTH_RADIUS, load_oxts
from trackscope.evaluation.ground_truth import load_ground_truth
from trackscope.geometry import T_ZUP_CAM

GOOD = "0,2,458.03,182.39,568.59,217.02,12.7438,1.4120,1.6439,4.4688,-4.1151,1.8319,30.8234,0.0368,0.1695"


class TestCalibration:
    def test_parse_tracking_style(self):
        c = KittiCalibration.from_text(synthetic_calib_text())
        # velo forward (x) maps to rect forward (z); velo left (y) maps to rect -x
        assert np.allclose(c.T_rect_velo[:3, :3] @ [1, 0, 0], [0, 0, 1])
        assert np.allclose(c.T_rect_velo[:3, :3] @ [0, 1, 0], [-1, 0, 0])
        assert np.allclose(c.T_velo_rect @ c.T_rect_velo, np.eye(4))

    def test_object_style_aliases(self):
        txt = synthetic_calib_text().replace("R_rect", "R0_rect:").replace("Tr_velo_cam", "Tr_velo_to_cam:")
        txt = txt.replace("Tr_imu_velo", "Tr_imu_to_velo:")
        assert KittiCalibration.from_text(txt).P2.shape == (3, 4)

    def test_projection_principal_point(self):
        c = KittiCalibration.from_text(synthetic_calib_text())
        uv, depth = c.project_rect_to_image(np.array([[0.0, 0.0, 10.0]]))
        assert depth[0] == pytest.approx(10.0)
        assert np.allclose(uv[0], [600 + 45 / 10, 180])  # P2 baseline term shifts u by fx*tx/z

    @pytest.mark.parametrize("mutate", [
        lambda t: "\n".join(l for l in t.splitlines() if not l.startswith("Tr_velo_cam")),
        lambda t: t.replace("R_rect 1.000000000000e+00", "R_rect"),
        lambda t: t.replace("P2: 7.0", "P2: abc"),
    ])
    def test_malformed(self, mutate):
        with pytest.raises(ValueError):
            KittiCalibration.from_text(mutate(synthetic_calib_text()))

    @requires_real_data
    def test_real_calibration_sanity(self):
        c = KittiCalibration.from_file(REAL_KITTI / "training" / "calib" / "0014.txt")
        p = c.T_rect_velo @ [10.0, 0, 0, 1]  # 10 m ahead of the LiDAR
        assert p[2] == pytest.approx(10.0, abs=0.5) and abs(p[0]) < 0.5
        R = c.T_rect_velo[:3, :3]
        assert np.allclose(R @ R.T, np.eye(3), atol=1e-4)


class TestOxts:
    def test_eastward_motion(self):
        poses = oxts_to_poses(synthetic_oxts_rows(11, ego_speed=5.0))
        assert np.allclose(poses[0][:3, 3], 0)
        assert np.allclose(poses[10][:3, 3], [5.0, 0, 0], atol=1e-6)  # 1 s at 5 m/s, east

    def test_north_and_heading(self):
        rows = synthetic_oxts_rows(2, 0.0)
        rows[1, 0] += np.rad2deg(10.0 / EARTH_RADIUS)  # 10 m of arc north
        rows[1, 5] = np.pi / 2  # heading north
        poses = oxts_to_poses(rows)
        # scaled Mercator: d(ty)/d(lat) = scale * R * sec(lat) = R near lat0 -> true metres
        assert poses[1][1, 3] == pytest.approx(10.0, rel=1e-4)
        assert abs(poses[1][0, 3]) < 1e-9
        assert np.allclose(poses[1][:3, :3] @ [1, 0, 0], [0, 1, 0], atol=1e-9)

    def test_bad_oxts(self, tmp_path):
        p = tmp_path / "o.txt"
        np.savetxt(p, np.zeros((3, 12)))
        with pytest.raises(ValueError):
            load_oxts(p)


class TestDetectionParsing:
    def test_good_line(self):
        d = parse_detection_line(GOOD)
        assert d.cls == "Car" and d.frame == 0 and d.score == pytest.approx(12.7438)
        assert np.allclose(d.dims_hwl, [1.412, 1.6439, 4.4688])
        assert np.allclose(d.loc, [-4.1151, 1.8319, 30.8234])

    @pytest.mark.parametrize("bad", [
        GOOD.rsplit(",", 1)[0],  # 14 columns
        GOOD + ",1.0",  # 16 columns
        GOOD.replace("12.7438", "nan"),
        GOOD.replace("1.4120", "-1.4120"),  # negative height
        GOOD.replace("0,2,", "0,7,", 1),  # unknown type
        GOOD.replace("0,2,", "-1,2,", 1),  # negative frame
        GOOD.replace("0,2,", "0.5,2,", 1),  # fractional frame
        GOOD.replace("12.7438", "abc"),
    ])
    def test_malformed_lines(self, bad):
        with pytest.raises(DetectionFormatError):
            parse_detection_line(bad)

    def test_empty_file_and_blank_lines(self, tmp_path):
        p = tmp_path / "x.txt"
        p.write_text("")
        assert load_detection_file(p) == []
        p.write_text(f"\n{GOOD}\n\n")
        assert len(load_detection_file(p)) == 1

    def test_error_reports_location(self, tmp_path):
        p = tmp_path / "x.txt"
        p.write_text(f"{GOOD}\n1,2,3\n")
        with pytest.raises(DetectionFormatError, match=r"x\.txt:2"):
            load_detection_file(p)

    def test_class_file_mismatch(self, tmp_path):
        for c in ("Car", "Pedestrian"):
            (tmp_path / c).mkdir()
        (tmp_path / "Car" / "0001.txt").write_text(GOOD + "\n")
        (tmp_path / "Pedestrian" / "0001.txt").write_text(GOOD + "\n")  # a Car row in Ped file
        with pytest.raises(DetectionFormatError):
            load_sequence_detections(tmp_path, "0001", ["Car", "Pedestrian"])

    def test_missing_file(self, tmp_path):
        with pytest.raises(FileNotFoundError):
            load_sequence_detections(tmp_path, "0001", ["Car"])

    def test_to_world_uses_pose(self):
        d = parse_detection_line(GOOD)
        T = T_ZUP_CAM.copy()
        T[:3, 3] = [100.0, 50.0, 0.0]
        (w,) = to_tracking_detections([d], T)
        assert w.box[0] == pytest.approx(100.0 + 30.8234) and w.det_id == 0 and w.cls == "Car"


@requires_real_data
class TestRealData:
    def test_real_detections_load(self):
        dets = load_sequence_detections(REAL_DETS, "0014", ["Car", "Pedestrian", "Cyclist"])
        assert set(dets) <= set(range(106)) and sum(map(len, dets.values())) > 500

    def test_sequence_and_static_car_in_world(self):
        """A parked car (GT track 4 in seq 0014) must be ~static in the world frame although
        it moves >10 m in the camera frame (validates calib + OXTS + box conversion chain)."""
        from trackscope.geometry import cam_box_to_zup

        seq = KittiTrackingSequence(REAL_KITTI, "0014")
        gt = load_ground_truth(REAL_KITTI / "training" / "label_02" / "0014.txt")
        world, cam = [], []
        for f in sorted(gt):
            for o in gt[f]:
                if o.track_id == 4:
                    world.append(cam_box_to_zup(o.loc, o.dims_hwl, o.ry, seq.T_world_rect[f])[:2])
                    cam.append(o.loc[[0, 2]])
        assert len(world) > 20
        assert np.linalg.norm(world[-1] - world[0]) < 0.5
        assert np.linalg.norm(cam[-1] - cam[0]) > 10.0
