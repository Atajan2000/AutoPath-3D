# TrackScope-3D

TrackScope-3D tracks 3D objects in KITTI Tracking using precomputed PointRCNN detections.
It uses calibration and OXTS poses to express detections in a common frame before estimating
object motion with a constant-velocity Kalman filter. The same Hungarian assignment and
track lifecycle are used with centre-distance, Mahalanobis and 3D IoU association costs.

![TrackScope-3D Rerun viewer: KITTI Tracking seq 0014, frame 41](assets/demo/trackscope3d_overview.png)

*Screenshot of the interactive Rerun viewer (not a rendering), KITTI Tracking seq 0014, frame 41, replaying the saved
Mahalanobis-association results. 3D view: Velodyne points, tracked 3D boxes with persistent IDs, class and speed,
40-frame trails, ego vehicle and path. Bottom: tracks projected into Camera 02. Right: bird's-eye view, the tracker's
per-frame diagnostics (recorded during the tracking run), track counts and evaluation events.*

## Visual demonstration

The demo capture script uses the saved tracking outputs listed below. The 78-second
MP4 is a local export.

Every viewer frame in the video is a window capture of the real Rerun viewer replaying **saved** tracking results
(`results/pointrcnn_<method>/frames/`). The tracker is not re-run.

| # | Scene | Data |
|---|---|---|
| intro + 1 | Tracking in action: 3D boxes, persistent IDs, trails, velocity arrows, camera projection, BEV | seq 0014 (development), all 106 frames |
| 2 | Kalman prediction and lifecycle: at frame 20, tracks 0, 2, 3 and 29 coast on the prediction (thin `PREDICTED (+k)` boxes); at frame 21, 0, 2 and 29 are re-associated with the same IDs and track 3 is terminated (`max_age = 2`) | seq 0014, frames 14–33 |
| 3 | Center-distance, Mahalanobis and 3D-IoU association side by side on the same detections | seq 0014 |
| 4 | Identity swap under center association (frames 173–175), with evaluation events from `results/evaluation/failure_cases.csv` | held-out seq 0016, frames 153–193 (tracks and detections only: no LiDAR downloaded) |
| summary | Accuracy, throughput and detector dependence | 10 held-out sequences |

The replay runs slower than real time (0.23–0.64×, measured for each scene and shown in its caption), because the
viewer is rendering-bound while it is captured. Every caption number is read from `results/`. To regenerate the media
(Windows, needs a 1920×1080 display): `python scripts/capture_demo.py build|screenshot|video|verify`.

### Evaluation figures (10 held-out sequences, 3D IoU 0.25, custom evaluation)

![Association method comparison](results/evaluation/figures/association_comparison.png)

| | |
|---|---|
| ![Performance by class](results/evaluation/figures/performance_by_class.png) | ![ID switches by sequence](results/evaluation/figures/idsw_by_sequence.png) |

| Measure (Mahalanobis association, held-out) | Car | Pedestrian |
|---|---|---|
| MOTA / IDF1 | 0.821 / 0.866 | 0.595 / 0.670 |
| ID switches | 13 | 53 |
| Detector-only recall → tracker recall | 0.931 → 0.897 | 0.793 → 0.744 |
| Detector-only precision → tracker precision | 0.721 → 0.923 | 0.689 → 0.838 |

**Throughput** (single CPU thread, Python, all 11 val sequences): **800 FPS** for the tracker step alone and
**484 FPS** end-to-end (loading, conversion, tracking, writing). **PointRCNN inference is not included**: the
detections are precomputed, so neither figure is the frame rate of a full perception system. Source:
`results/evaluation/metrics.json` (`runtime`) and [docs/EVALUATION.md](docs/EVALUATION.md).

For cars, Mahalanobis association reduced false positives from 644 to 596 compared with
centre distance. The evaluation traces most of that reduction to fewer confirmed tracks
that never match ground truth. Association changes did little for recall because many
missed objects had no overlapping detection. The centre-distance run on sequence 0016
also contains an identity swap across frames 173–175.
[Error analysis](docs/EVALUATION.md).

### Limitations

* **Detector-bound.** 58% of missed cars and 77% of missed pedestrians have no overlapping detection at all. The
  tracker cannot recover what PointRCNN misses, and nearly all of its false positives are propagated detector false
  positives.
* **Not official KITTI scores.** These are custom 3D evaluations on 10 held-out training sequences. The differences
  between association methods are small (< 1 MOTA point), and their confidence intervals come from only 10 sequences.
* **Not tuned.** The score threshold, `min_hits`, `max_age` and the Kalman noise are untuned. The filter is
  over-conservative (mean NIS 2.4 for Car against an expected 7.0).
* **Sensor data for seq 0014 only.** Other sequences replay tracks and detections without LiDAR or camera data.

## Run the tracker and viewer

Use Python 3.13 with the versions in `requirements-lock.txt`. On Windows, from the repository root:

```powershell
py -3.13 -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements-lock.txt
python -m pip install -e . --no-deps
python scripts/download_data.py --sequences 0014 --velodyne --images
python scripts/run_tracking.py
python scripts/view.py
```

To reproduce the evaluation, generate results for each method with the same sequence list.
The evaluator separates development sequence 0014 from the held-out aggregate. The other
sequences need metadata and detections for tracking. Their LiDAR scans and images are optional.

```powershell
python scripts/run_tracking.py --sequences 1 6 8 10 12 13 14 15 16 18 19 --method center --name pointrcnn_center
python scripts/run_tracking.py --sequences 1 6 8 10 12 13 14 15 16 18 19 --method mahalanobis --name pointrcnn_mahalanobis
python scripts/run_tracking.py --sequences 1 6 8 10 12 13 14 15 16 18 19 --method iou --name pointrcnn_iou
python scripts/evaluate.py
python scripts/make_figures.py
python -m pytest
```

Documentation: [ARCHITECTURE.md](ARCHITECTURE.md) (frames, state and measurement vectors, association, lifecycle) · [DATASET_REPORT.md](DATASET_REPORT.md) (provenance, formats, validation, licences).

Data licences: KITTI is CC BY-NC-SA 3.0. The PointRCNN detections come from AB3DMOT (CMU non-commercial research licence) and are downloaded, not redistributed. This repository contains no AB3DMOT code.

The code license is pending confirmation. The dataset and detection terms apply independently.
