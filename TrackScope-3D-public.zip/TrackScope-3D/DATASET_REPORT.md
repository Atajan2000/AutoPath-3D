# Dataset Report

Audit date: 2026-11-04. Everything below was measured on the downloaded files, not copied from documentation.

## 1. What is used

| Component | Source | Size on disk | Role |
|---|---|---|---|
| Labels `label_02` (21 train seqs) | KITTI `data_tracking_label_2.zip` | 2.3 MB zip | **Evaluation / validation only** |
| Calibration | KITTI `data_tracking_calib.zip` | 0.1 MB | camera/LiDAR/IMU geometry |
| OXTS GPS/IMU | KITTI `data_tracking_oxts.zip` | 8.4 MB | ego poses for motion compensation |
| PointRCNN 3D detections | AB3DMOT repo @ `61f3bd7` (`data/KITTI/detection/pointrcnn_{Car,Pedestrian,Cyclist}_val/*.txt`) | 8.5 MB | **tracker input** |
| LiDAR scans, seq 0014 | KITTI `data_tracking_velodyne.zip` (36.8 GB) — 106 members only | 198 MB | visualisation, geometry validation |
| Left colour images, seq 0014 | KITTI `data_tracking_image_2.zip` (15.8 GB) — 106 members only | 80 MB | camera panel, projection checks |

The LiDAR and image members were extracted from the remote archives with HTTP range requests (`scripts/download_data.py`): 298 MB were transferred instead of 52.6 GB, and `zipfile` verified CRC-32 for every member. Free disk space on `C:` was 13 GB at audit time (18 GB after cleanup elsewhere), so whole-archive downloads were never an option.

Reproduce with:

```bash
python scripts/download_data.py --sequences 0014 --velodyne --images
```

## 2. Sequence selection

AB3DMOT defines the KITTI Tracking split used with these detections (`AB3DMOT_libs/utils.py`):

* train: 0000 0002 0003 0004 0005 0007 0009 0011 0017 0020
* **val: 0001 0006 0008 0010 0012 0013 0014 0015 0016 0018 0019**

The repository folder is called `*_val` but contains files for all 21 training sequences. Results are reported **only on val sequences**: the PointRCNN model was trained on the KITTI object split that matches the AB3DMOT train sequences, so detections on those sequences are expected to be optimistic. Train sequences may be used for choosing hyperparameters (Phase 2).

Val sequence statistics (computed from `label_02` and `oxts`):

| seq | frames | Car IDs | Ped IDs | Cyc IDs | Car label rows | ego speed mean / max [m/s] |
|---|---|---|---|---|---|---|
| 0001 | 447 | 89 | 3 | 0 | 2681 | 7.2 / 11.4 |
| 0006 | 270 | 11 | 0 | 0 | 550 | 1.8 / 9.2 |
| 0008 | 390 | 21 | 0 | 0 | 1046 | 14.3 / 17.0 |
| 0010 | 294 | 13 | 2 | 1 | 603 | 13.8 / 15.2 |
| 0012 | 78 | 2 | 1 | 1 | 144 | 0.0 / 0.0 |
| 0013 | 340 | 2 | 42 | 8 | 55 | 5.6 / 7.2 |
| **0014** | **106** | **14** | **2** | 0 | **455** | **4.6 / 9.7** |
| 0015 | 376 | 9 | 11 | 5 | 899 | 1.8 / 11.6 |
| 0016 | 209 | 4 | 19 | 5 | 836 | 0.0 / 0.0 |
| 0018 | 339 | 18 | 0 | 0 | 1354 | 7.3 / 15.3 |
| 0019 | 1059 | 7 | 62 | 8 | 927 | 2.1 / 5.7 |

**Primary development sequence: 0014.** It is the second-smallest val sequence (106 frames, ~200 MB of LiDAR) but still has 14 cars, 2 pedestrians, parked and moving vehicles, and a *moving* ego vehicle, so ego-motion compensation is actually exercised. 0012 is smaller but static and almost empty. Seq 0014 also contains 72 `Van` and 149 `DontCare` label rows, which matter for evaluation (Phase 2).

Labels, calibration, OXTS and detections are available for all 11 val sequences, so tracking and evaluation can run on the whole val split without any further LiDAR download.

## 3. Formats (verified)

### PointRCNN detections (AB3DMOT layout)
Comma-separated, 15 columns, one detection per row, one file per class and sequence:

```
frame, type, x1, y1, x2, y2, score, h, w, l, x, y, z, ry, alpha
0,     2,    458.03, 182.39, 568.59, 217.02, 12.7438, 1.412, 1.644, 4.469, -4.115, 1.832, 30.823, 0.0368, 0.1695
```

* `type`: 1 = Pedestrian, 2 = Car, 3 = Cyclist (AB3DMOT `det_id2str`).
* Dimension order **h, w, l**, confirmed by medians on seq 0014: Car 1.52 / 1.61 / 3.85 m, Pedestrian 1.73 / 0.64 / 0.82 m, Cyclist 1.70 / 0.59 / 1.75 m.
* `x, y, z` = bottom-face centre in the **rectified camera-0 frame**; `ry` = rotation about camera y.
* `score` is an **unnormalised logit** (seq 0014 Car: 10th / 50th / 90th percentile = −0.22 / 4.78 / 11.46). Threshold 0 corresponds to probability 0.5.
* Seq 0014 detections: 654 Car, 353 Pedestrian, 52 Cyclist rows, covering frames 0–105. File sizes match the GitHub listing byte for byte.

### KITTI Tracking labels
Space-separated, 17 columns: `frame track_id type truncated occluded alpha x1 y1 x2 y2 h w l x y z ry`. Same camera-frame convention as above. `DontCare` rows have `track_id = -1`.

### Calibration
`P0..P3:` (3x4), `R_rect` (3x3), `Tr_velo_cam` (3x4), `Tr_imu_velo` (3x4). Note that the tracking files have no colon after the last three keys, unlike the object benchmark (`R0_rect:`, `Tr_velo_to_cam:`); the parser accepts both.

### OXTS
30 values per frame (lat, lon, alt, roll, pitch, yaw, velocities, …). There are **no timestamps** in the tracking release; frames are consecutive 10 Hz sweeps, so `t = 0.1 * frame`.

## 4. Geometry validation on real data (seq 0014)

| Check | Result |
|---|---|
| LiDAR points inside GT Car boxes (frames 0/30/60/90, n = 15) | median **34**, no empty box |
| Same, if `loc` were wrongly treated as the box centre | median 8, which confirms the bottom-centre convention |
| LiDAR points inside PointRCNN boxes (score > 2, frame 30) | 85, 21, 8, 45, 15, 40 |
| Parked cars (GT IDs 3, 4, 5, 8–13): displacement in **world** frame | 0.19–1.18 m over 2.3–7.2 s |
| Same cars, displacement in **camera** frame | 13–33 m (ego motion) |
| Moving GT cars 6 and 7, world speed | 8.1 and 7.8 m/s |
| camera → world → camera round trip | 7e-6 m / 7e-6 rad (pitch dropped by the BEV yaw) |

These checks use GT boxes as *validation oracles only*; they are not part of tracking.

## 5. Licences and provenance

* **KITTI**: CC BY-NC-SA 3.0, non-commercial. Raw data is never committed (`data/` is git-ignored).
* **AB3DMOT detections**: the AB3DMOT repository uses a *CMU academic / non-profit non-commercial research licence*. TrackScope-3D contains **no AB3DMOT code**; the detection files are downloaded by the user at runtime from the pinned commit and are not redistributed. Cite Weng et al., "3D Multi-Object Tracking: A Baseline and New Evaluation Metrics" (IROS 2020) and Shi et al., "PointRCNN" (CVPR 2019).
* Provenance is written to `data/detections/pointrcnn/SOURCE.txt` by the download script.
