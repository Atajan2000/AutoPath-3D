# Architecture

## Package layout

```
src/trackscope/
  types.py            CameraDetection (raw), Detection (tracker input; no identity field)
  config.py           YAML -> typed configs, strict key checking, dotted overrides
  pipeline.py         KITTI sequence -> tracker -> result files (kitti/, frames/, summary.json)
  geometry/
    transforms.py     SE(3) helpers, wrap_angle
    boxes.py          camera <-> z-up box conversion, corners, rotated BEV / 3D IoU
  data/               (detector outputs + sensor metadata only; never annotations)
    calibration.py    KITTI tracking calib parsing and frame chain
    oxts.py           OXTS -> T_world_imu (devkit Mercator convention)
    kitti_tracking.py sequence access: poses, LiDAR, images, timestamps
    detections.py     AB3DMOT/PointRCNN loader with strict validation
  tracking/           (pure algorithm: no files, no KITTI, no viz)
    kalman.py         constant-velocity KF (functional API)
    association.py    center / Mahalanobis / IoU costs, feasibility checks, Hungarian
    track.py          Track state + lifecycle state machine + history
    tracker.py        MultiObjectTracker.step(frame, t, detections) -> FrameResult
  evaluation/         (may read annotations; never imported by the inference path)
    ground_truth.py   KITTI tracking-format reader (labels and results)
    protocol.py       split, KITTI ignore rules, 2D/3D similarity, per-frame preprocessing
    metrics.py        CLEAR-MOT, IDF1, detection counts (TrackEval-compatible + Frag_strict)
    runner.py         evaluate result files / raw detections per sequence and class
    analysis.py       error attribution (detector / initiation / association / estimation)
    trackeval_bridge.py  optional independent cross-check with TrackEval
  viz/                (replays saved results; never runs the tracker)
    replay.py         JSONL -> frames with measured + reconstructed predicted states, histories, events
    overlays.py       ID colours, camera projection with clipping, ego-frame BEV transform
    rerun_view.py     Rerun logging + blueprint (only module importing rerun)
scripts/  download_data.py, run_tracking.py, evaluate.py, make_figures.py, view.py
configs/  default.yaml
tests/    unit + synthetic end-to-end + real-data sanity tests
```

Dependency direction: `geometry` ← `data`, `tracking` ← `pipeline`. `evaluation` may import anything; nothing in the inference path imports `evaluation` (enforced by `tests/test_pipeline_and_leakage.py`, both statically via AST and dynamically by spying on file access during a pipeline run).

## Coordinate frames

`T_a_b` maps coordinates from frame `b` into frame `a` (`p_a = T_a_b p_b`).

| Frame | Axes | Notes |
|---|---|---|
| `rect` | x right, y down, z forward | rectified camera 0; detections and labels |
| `velo` | x fwd, y left, z up | Velodyne HDL-64E |
| `imu` | x fwd, y left, z up | OXTS unit |
| `world` | x east, y north, z up | origin at frame-0 IMU position; gravity-aligned (ENU) |

Chain per frame: `T_world_rect = T_world_imu · (R_rect · Tr_velo_cam · Tr_imu_velo)^-1`.

**Tracking happens in `world`.** Detections are transformed into the world frame with that frame's ego pose before association, so the Kalman velocity is *ego-motion compensated* (velocity over ground, not relative to the sensor). This is validated on real data (parked cars ≈ 0.15–0.36 m/s, moving cars ≈ 8 m/s with heading aligned to velocity) and by a synthetic test where a parked car and a car escorting the ego vehicle must come out at 0 and 8 m/s respectively.

Ego poses come from OXTS (RTK GPS/IMU), not from LiDAR odometry. Their errors therefore show up as apparent motion of static objects. On seq 0014 that is about 0.15 m/s, which includes label noise.

## Box parameterisations

* Camera box (KITTI): `loc` = **bottom-face centre**, `dims = (h, w, l)`, `ry` about camera y; the length axis is `(cos ry, 0, −sin ry)`.
* Tracking box `box7 = [x, y, z, yaw, l, w, h]`: **geometric centre**, `yaw` CCW from world +x.

Conversion adds `−h/2` along camera y and recovers yaw from the transformed heading vector. Road pitch and roll are dropped, which is the standard BEV assumption; the round-trip error on real poses is about 1e-5.

## Kalman filter

* State `x = [px, py, pz, vx, vy, yaw, l, w, h]` (9).
* Measurement `z = [px, py, pz, yaw, l, w, h]` (7), the detected box.
* Motion: constant velocity in the ground plane. `pz`, `yaw` and the dimensions are random walks. There is no vertical velocity, because in a gravity-aligned frame it would only integrate detector z-noise.
* Process noise: exact discretisation of continuous white-noise acceleration (`q·[[dt³/3, dt²/2],[dt²/2, dt]]`) plus `σ²·dt` random walks. This composes exactly under variable `dt`, and a test verifies that one 0.2 s prediction equals two 0.1 s predictions.
* Yaw: wrapped after predict and update; the innovation is wrapped. If |innovation| > π/2, the measurement is flipped by π, which handles front/back ambiguity of the detector.
* Joseph-form covariance update; covariance symmetrised.
* Initial velocity: zero mean with class-specific prior std (`init_vel`).
* Consistency: on data generated from the model, mean NIS lies within the χ²(7) 99% band (test). On real data the noise parameters are documented priors, not fitted values. Fitting them on the train split is planned for Phase 2.

## Association

All methods compare the **predicted** track box with the current detections, so the comparison isolates the matching criterion:

| method | cost | gate |
|---|---|---|
| `center` | BEV centre distance | `d < center_gate[cls]` (Car 3 m, Ped 1.5 m, Cyc 2 m) |
| `mahalanobis` | `d² + ln det S` (Gaussian NLL), S = 3D-centre innovation covariance | `d² < χ²₃(0.99) = 11.34` |
| `iou` | `1 − IoU` (3D or BEV, rotated) | `IoU > 0.01` |

Feasibility checks shared by all methods:
- **Class compatibility.**
- **Physical plausibility:** displacement since the last *measurement* must be at most `max_speed[cls]·Δt + 1 m`. Speeds are world-frame: Car 40, Ped 4, Cyc 15 m/s.
- **Size consistency:** volume ratio of at most 3.

`scipy.optimize.linear_sum_assignment` solves the assignment with infeasible pairs at cost 1e6, which yields a maximum-cardinality feasible matching first and then minimum cost; infeasible pairs it returns are dropped. For each unmatched track, the diagnostics record why its nearest same-class detection was rejected (`gate`, `speed`, `size`, `assigned_elsewhere`).

## Track lifecycle

```
birth -> TENTATIVE --min_hits consecutive hits--> CONFIRMED <--hit-- LOST
            |any miss                                  |miss          |> max_age misses
            v                                          v              v
         DELETED                                     LOST          DELETED
```

`min_hits = 3`, `max_age = 2` frames (0.2 s). IDs are monotonically increasing and never reused. Each track keeps a bounded history, and every entry is tagged `measured` (posterior after update) or `predicted` (coasting). Outputs report `source` per frame, so measured, predicted and extrapolated states are always distinguishable.

## Outputs (`results/<experiment>/`)

* `kitti/<seq>.txt`: KITTI tracking result format in each frame's camera coordinates. The 2D box is the projection of the 3D box with `P2`, clipped to the image. Truncation and occlusion are `-1`; score is the last associated detection score.
* `frames/<seq>.jsonl`: per frame: ego poses, input detections (world), tracks (box, velocity, speed, position std, status, source, hits, age), and diagnostics (counts, births, confirmations, losses, deletions, matches with costs, rejections with reasons, timing).
* `summary.json`: configuration, per-sequence statistics, tracker FPS.

## ROS 2 readiness (future)

`MultiObjectTracker.step(frame, t, detections)` is the only entry point and has no I/O. A ROS 2 node would convert incoming detection messages plus TF ego pose into `Detection`s in a fixed frame, call `step`, and publish `TrackOutput`s and history as tracked-object and marker messages. No ROS code is included yet.
