# Interactive Viewer (Rerun)

![Rerun viewer, sequence 0014, frame 28](../assets/viewer_seq0014_frame28.png)

The viewer replays **saved** tracking results; it never re-runs the tracker. It reads:
- `results/pointrcnn_<method>/frames/<seq>.jsonl`: per-frame tracks, detections, diagnostics and ego poses written by `scripts/run_tracking.py`.
- `results/evaluation/failure_cases.csv`: evaluation events (Phase 2).
- The local KITTI data: calibration, and LiDAR plus images where they were downloaded (sequence 0014).

## Launch

```bash
pip install -e .[viz]        # rerun-sdk 0.41, pillow
python scripts/view.py       # seq 0014, Mahalanobis association, opens the Rerun viewer
```

| Command | Shows |
|---|---|
| `python scripts/view.py --compare` | BEVs of all three association methods side by side, plus the 3D and camera views |
| `python scripts/view.py --show-gt` | additionally draws ground-truth boxes (white, analysis layer) |
| `python scripts/view.py --seq 16 --method center --list-events` | numbered evaluation events (ID switches, fragmentations) |
| `python scripts/view.py --seq 16 --method center --event 62 --compare` | ±20 frames around an event (here the frame-173 car swap under center association) |
| `python scripts/view.py --seq 19 --frames 240:290 --compare` | an arbitrary frame window |
| `python scripts/view.py --save results/viz/seq0014.rrd --no-open` | writes a recording; open it later with `rerun results/viz/seq0014.rrd` |

Use the time panel to play, pause and scrub (the `frame` timeline, 10 Hz). Click any track box to see its inspection values in the selection panel: ID, class, lifecycle status, state source, speed and velocity, position, yaw, size, last detection score, hits, age, frames since the last detection, and position std.

## Views

| View | Content |
|---|---|
| **3D · LiDAR + tracks** | Velodyne points coloured by height, track boxes with ID, class and speed labels, 1-second velocity arrows, trails of the last 40 states, grey PointRCNN detections, ego vehicle with axes and driven path. The chase camera follows the ego vehicle. |
| **BEV** | Ego-centred top-down view (driving direction up, rings every 10 m), above-ground LiDAR returns, footprints, trails, velocity arrows, detections. |
| **Camera 02** | KITTI left colour image with the track boxes projected through `P2`. Edges are clipped at the near plane in 3D and at the image border in 2D. The cross marks each box's front face. |
| **Tracking diagnostics** | Saved per-frame values only: confirmed and coasting tracks, tentative count, births, confirmations, losses, terminations, detections in/used, associations, unmatched-track reasons, and the tracker step time recorded during the tracking run. |
| **Track counts** | Time series of confirmed, predicted-only and detection counts per method. |
| **Evaluation events / Legend** | Evaluation events logged at their frames, with their causes; colour and style legend. |

## How to read it

* **Identity.** Each track ID has a fixed colour, derived deterministically from ID and method. Box, label, trail and arrow share it across all frames and views.
* **Measured vs predicted.**
  - A **filled box with a thick outline** means the state was updated with a detection in this frame.
  - A **thin, desaturated wireframe labelled `PREDICTED (+k)`** is a confirmed track coasting on the Kalman prediction, k frames after its last detection. It keeps its ID, and returns to the filled style when a detection is associated again (same ID).
  - With the frozen setting `max_age = 2`, a track that coasts longer is terminated; a later detection of the same object starts a *new* ID.
* **Predicted states are reconstructed, not re-tracked.** The result files contain only detection-updated states (`output_lost: false`). The viewer rebuilds the coasting states from the saved lifecycle diagnostics as the Kalman predicted mean: last posterior plus velocity·Δt, with yaw and size unchanged. `tests/test_viz.py` checks this against a live tracker run on all 106 frames of 0014.
* **Tentative tracks** (fewer than 3 hits) are not saved, so they are not drawn; their count appears in the diagnostics.
* **Evaluation events.** These are shown in magenta, only where `failure_cases.csv` contains them (3D IoU 0.25 by default; `--iou-thr 0.5` selects the other setting):
  - **ID switch:** the GT object was matched to tracker ID *old* and is now matched to *new*.
  - **Fragmentation:** the object was re-acquired after an untracked gap.

  Each event carries the cause assigned in Phase 2: detector dropout longer than `max_age` (track terminated), association failure although detections existed, or identity swap while the old track was alive. A new ID is never labelled an ID switch unless the evaluation established it. Ground truth appears only as a white annotation box; it never changes a displayed track.
* **Comparison mode.** IDs are prefixed `C`/`M`/`I` and coloured per method, because numeric IDs from independent trackers are **not** comparable. The 3D and camera views show the primary method.

## Data availability

LiDAR scans and images were downloaded for sequence **0014** only. For other sequences (e.g. the failure cases in 0001, 0016 and 0019), the viewer runs a **tracks-and-detections replay**: the 3D view, BEV, diagnostics and events, with no point cloud or camera view. To add sensor data for another sequence:
```bash
python scripts/download_data.py --skip-metadata --skip-detections --sequences 0016 --velodyne --images
```

## Performance notes

* Logging all of sequence 0014 takes about 2 s. Its recording is about 290 MB, mostly LiDAR points (~120k per scan, all kept) and the original PNG images. Recording size was not optimized.
* The latency in the diagnostics is the tracker step time measured during the tracking run. It is unrelated to viewer playback speed. Detector inference is not included anywhere.

## Verification status

* Rendering was inspected in the native Rerun viewer (window captures) for:
  - sequence 0014 single-method (frames 4, 28, 72)
  - sequence 0014 comparison (frame 29)
  - the sequence 0016 event window (frames 162, 172, 190)
* The camera panel no longer re-fits per frame. A capture at frame 4 and one at frame 28 show the image at identical panel coordinates.
* Automated checks (`tests/test_viz.py`):
  - predicted-state reconstruction vs a live tracker (synthetic data and real 0014)
  - stable, distinct ID colours
  - projection geometry, near-plane and image clipping, and agreement of projected tracks with PointRCNN 2D boxes on real frames (median IoU > 0.7)
  - BEV axes; history consistency; empty scenes
  - evaluation events identical to the CSV rows
  - launcher output, validated with `rerun rrd verify`
