# Phase 2 — Tracking Evaluation

> **Labelling.** Everything here is a **custom KITTI 3D tracking evaluation** (oriented 3D IoU) or a **KITTI-protocol 2D evaluation of projected 3D boxes**, computed on KITTI Tracking *training* sequences (the AB3DMOT validation split). These are **not official KITTI leaderboard scores** and are not directly comparable with published numbers obtained under different protocols. AMOTA, sAMOTA and HOTA are not reported.

Machine-readable results: `results/evaluation/` (`summary.csv`, `per_sequence.csv`, `per_class.csv`, `association_comparison.csv`, `failure_cases.csv`, `metrics.json`). Figures: `results/evaluation/figures/`.

## 1. Protocol

| Item | Value |
|---|---|
| Detector input | PointRCNN 3D detections published by AB3DMOT (commit `61f3bd7`), all three classes |
| Detection score threshold | logit ≥ 0.0 for every class (Phase-1 default, unchanged) |
| Development sequence | **0014**: used in Phase 1 for development and geometry validation |
| Held-out sequences | **0001 0006 0008 0010 0012 0013 0015 0016 0018 0019** (rest of the AB3DMOT val split) |
| Configuration | `configs/default.yaml`, sha256 `15c73109…c0e9fb`, frozen **before** any metric was computed; only `association.method` varies |
| Classes | Car and Pedestrian (KITTI tracking classes); Cyclist reported as supplementary in 3D |
| Settings | 3D IoU 0.25, 3D IoU 0.5, 2D box IoU 0.5 (KITTI protocol) |
| Aggregation | counts summed over sequences, ratios recomputed; classes never pooled |
| Software | trackscope 0.1.0 (src sha256 in `metrics.json`), Python 3.13.4, NumPy 2.5.4, SciPy 1.18.1, TrackEval `12c8791` |

**Ignore rules.** These follow the KITTI protocol exactly as implemented in TrackEval `Kitti2DBox`:
- **Distractor classes:** Van for Car; Person (sitting) for Pedestrian.
- **Hidden GT:** GT with occlusion > 2 or truncation > 0 is ignored. Tracker boxes matching distractors or ignored GT are removed rather than counted as FP.
- **Unmatched tracker boxes** are also removed if their 2D height is ≤ 25 px or if they lie more than 50% inside a DontCare region.

The 3D evaluation uses the same rules and changes only the similarity, to oriented 3D IoU. Its preprocessing match uses the evaluation threshold.

**Metric definitions.** These are CLEAR-MOT (MOTA, MOTP, FP, FN, IDSW, Frag, MT/PT/ML) and identity metrics (IDF1, IDP, IDR) with TrackEval semantics:
- **IDF1** uses a global one-to-one GT-ID ↔ tracker-ID assignment, not frame-wise matching.
- **TrackEval Frag quirk:** a frame where a class has zero tracker outputs is skipped. This hides fragmentation in sparse scenes, as the synthetic test `test_attribution_on_synthetic_gap` shows. `Frag_strict` (same definition, nothing skipped) is therefore reported as well.

**Split integrity.**
- 0014 is reported separately and never enters held-out aggregates.
- No parameter was tuned in Phase 2.
- The evaluation script refuses to compare experiments whose configurations differ beyond the association method.
- The inference code cannot read annotations: this is enforced statically (AST import scan) and dynamically (file-access spy during a pipeline run).

## 2. Verification

| Check | Result |
|---|---|
| TrackEval `Kitti2DBox` full pipeline (its own file parsing, ignore rules, CLEAR, Identity) vs ours, 2D IoU 0.5 | **66/66** sequence×class×method results identical on all 11 count fields |
| TrackEval CLEAR + Identity metric classes on our preprocessed 3D frames | **198/198** identical |
| Randomised synthetic sequences vs TrackEval (25 seeds × 2 thresholds) | 50/50 identical (unit test) |
| Deterministic metric tests | perfect tracking, ID swaps, IDF1 vs frame-level, missed detections, FPs, fragmentation with and without new ID, empty sequences, MT/PT/ML, match priority, distractors, occlusion/truncation, DontCare, min height, class separation, rotated 3D boxes, IoU threshold boundaries |
| 3D IoU | analytic cases (half shift = 1/3, 45° square = octagon, 90° rotated car, π symmetry) and Monte-Carlo volume estimates of random rotated, offset box pairs (±0.01) |
| Error attribution | synthetic end-to-end case with a known 4-frame detector gap reproduces the expected FN, IDSW and Frag causes exactly |

TrackEval `12c8791` uses `np.float`, `np.int` and `np.bool`, which NumPy 2 removed. The bridge (`evaluation/trackeval_bridge.py`) restores them as the builtins they aliased; TrackEval's logic is not modified.

## 3. Results (held-out, 10 sequences)

### 3.1 Custom 3D evaluation — 3D IoU 0.25

| Class | Method | MOTA | IDF1 | IDSW | FP | FN | Frag | Frag_strict | Prec | Rec | MT | ML |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Car (GT 7968) | Center | 0.816 | 0.850 | 18 | 644 | 805 | 76 | 88 | 0.918 | 0.899 | 124 | 4 |
| | **Mahalanobis** | **0.821** | **0.866** | **13** | **596** | 818 | 73 | 86 | 0.923 | 0.897 | 121 | 4 |
| | 3D IoU | 0.814 | 0.858 | 15 | 658 | 809 | 74 | 86 | 0.916 | 0.898 | 123 | 4 |
| Pedestrian (GT 9666) | Center | 0.592 | 0.665 | 63 | 1410 | 2475 | 241 | 249 | 0.836 | 0.744 | 81 | 12 |
| | **Mahalanobis** | **0.595** | **0.670** | 53 | 1394 | 2472 | 237 | 245 | 0.838 | 0.744 | 81 | 12 |
| | 3D IoU | 0.593 | 0.662 | **52** | **1381** | 2501 | 227 | 233 | 0.838 | 0.741 | 81 | 13 |

### 3.2 Custom 3D evaluation — 3D IoU 0.5

| Class | Method | MOTA | IDF1 | IDSW | FP | FN | Frag |
|---|---|---|---|---|---|---|---|
| Car | Center | 0.798 | 0.842 | 17 | 716 | 874 | 82 |
| | **Mahalanobis** | **0.808** | **0.860** | **13** | **647** | 872 | 77 |
| | 3D IoU | 0.799 | 0.852 | 14 | 716 | 868 | 80 |
| Pedestrian | Center | 0.545 | 0.644 | 58 | 1654 | 2682 | 264 |
| | Mahalanobis | 0.550 | **0.650** | **51** | 1629 | 2672 | 258 |
| | 3D IoU | **0.552** | 0.643 | **51** | **1592** | 2683 | 250 |

### 3.3 KITTI-protocol 2D evaluation of projected boxes — 2D IoU 0.5 (TrackEval-verified)

| Class | Method | MOTA | IDF1 | IDSW | FP | FN | Frag |
|---|---|---|---|---|---|---|---|
| Car | Center | 0.816 | 0.850 | 20 | 642 | 801 | 78 |
| | Mahalanobis | 0.821 | 0.866 | 14 | 595 | 819 | 74 |
| | 3D IoU | 0.814 | 0.858 | 16 | 661 | 808 | 75 |
| Pedestrian | Center | 0.497 | 0.627 | 85 | 1782 | 2991 | 446 |
| | Mahalanobis | 0.500 | 0.632 | 78 | 1767 | 2988 | 445 |
| | 3D IoU | 0.501 | 0.625 | 75 | 1742 | 3006 | 435 |

These 2D boxes are image projections of the *filtered 3D boxes*, not detector 2D boxes. The likely explanation for the lower Pedestrian 2D scores (MOTA 0.50 vs 0.60 in 3D at 0.25) is that small depth and size errors shift the projected boxes of these small objects enough to fall below 2D IoU 0.5. This hypothesis was not tested separately. Car results are nearly identical to 3D at 0.25.

**Development sequence 0014** (3D 0.25, not part of the aggregates above):
- Car: MOTA 0.835, IDF1 0.914, 0 IDSW for all three methods.
- Pedestrian: MOTA 0.612 / 0.612 / 0.645 (center / Mahalanobis / IoU), only 121 GT boxes.

**Cyclist** (supplementary, not a KITTI tracking class), 3D 0.25, Mahalanobis: MOTA 0.63, IDF1 0.71, 1,348 GT boxes.

## 4. Association-method comparison

Same detections, same filter, same lifecycle; only the association criterion differs. The differences are A − B with 95% CIs from 10,000 paired bootstrap resamples of the 10 held-out sequences:

| Comparison (3D 0.25) | ΔMOTA [95% CI] | ΔIDF1 [95% CI] | ΔIDSW [95% CI] | sequences better / worse / tied (MOTA) |
|---|---|---|---|---|
| Car: Mahalanobis − Center | +0.0050 [+0.0021, +0.0094] | +0.016 [+0.001, +0.037] | −5 [−10, 0] | 8 / 1 / 1 |
| Car: Mahalanobis − IoU | +0.0069 [+0.0031, +0.0120] | +0.008 [+0.002, +0.014] | −2 [−5, 0] | 8 / 1 / 1 |
| Car: IoU − Center | −0.0019 [−0.0058, +0.0014] | +0.009 [−0.002, +0.031] | −3 [−7, 0] | 2 / 4 / 4 |
| Ped: Mahalanobis − Center | +0.0030 [+0.0021, +0.0074] | +0.006 [+0.003, +0.007] | −10 [−20, −2] | 5 / 0 / 5 |
| Ped: Mahalanobis − IoU | +0.0016 [−0.0062, +0.0066] | +0.008 [−0.001, +0.013] | +1 [−2, +4] | 5 / 1 / 4 |
| Ped: IoU − Center | +0.0014 [−0.0030, +0.0127] | −0.003 [−0.008, +0.007] | −11 [−20, −3] | 3 / 3 / 4 |

**Interpretation**
* **Mahalanobis-gated Hungarian is the best overall choice.** It has the highest MOTA and IDF1 for Car at both 3D thresholds and in 2D, and the highest MOTA and IDF1 for Pedestrian at 3D 0.25. For Pedestrian at 3D 0.5, IoU association has a marginally higher MOTA (0.552 vs 0.550) and the fewest FP.
* **The effects are small** (< 1 MOTA point, < 2 IDF1 points). The CIs come from only 10 sequences and are not corrected for multiple comparisons, so they show direction rather than strong significance.
* **Where the Car MOTA gain comes from:** decomposing ΔMOTA (Mahalanobis − Center) gives +0.0060 from fewer FP, −0.0016 from more FN, and +0.0006 from fewer IDSW. The FP reduction is a *lifecycle* effect: 121 vs 129 confirmed tracks never match any GT ("false tracks"), and they produce 495 vs 538 FP frames. Fewer chains of false detections reach the 3-hit confirmation threshold; the mechanism (e.g., z-aware, uncertainty-scaled gating of young tracks) was not isolated.
* **Where the IDSW reduction comes from:** genuine association. ID swaps where the old track is still alive (`identity_swap`) drop from 3 Car / 11 Pedestrian (Center) to 0 / 5 (Mahalanobis) and 0 / 3 (IoU). Example: in seq 0016, frames 173–175, Center association swaps the identities of two cars (GT 0/1 ↔ tracks 0/1); both other methods keep them.
* **IoU association** helps pedestrians (fewest swaps) but does not improve Car MOTA. Its tracker step is also the slowest.

## 5. Detector vs tracker

Held-out, 3D 0.25. The detector-only rows use per-frame matching of the raw boxes with the same ignore rules and no identities:

| Class | Detector (score ≥ 0) Recall / Precision / MODA | Tracker (Mahalanobis) Recall / Precision / MOTA |
|---|---|---|
| Car | 0.931 / 0.721 / 0.57 | 0.897 / 0.923 / 0.821 |
| Pedestrian | 0.793 / 0.689 / 0.43 | 0.744 / 0.838 / 0.595 |
| Cyclist* | 0.97 / 0.48 / −0.07 | 0.94 / 0.75 / 0.63 |

With all detection scores, Car / Pedestrian recall rises only to 0.940 / 0.802. The detector's recall ceiling therefore bounds the tracker.

The tracker trades about 3–5 points of recall for 15–27 points of precision. Most of the gain from tracking is **suppression of transient false detections** by the confirmation rule.

### Error decomposition (Mahalanobis, held-out, 3D 0.25)

| Error | Car | Pedestrian | Responsible component |
|---|---|---|---|
| FN: no overlapping detection | 476 (58%) | 1903 (77%) | detector |
| FN: overlapping detection below score threshold | 69 (8%) | 93 (4%) | detector / threshold |
| FN: tentative-track initiation delay | 271 (33%) | 462 (19%) | track initiation (`min_hits=3`) |
| FN: detection left unassociated | 2 | 3 | association |
| FN: output box off although associated | 0 | 11 | state estimation |
| FP: propagated detector false positives | 596 (100%) | 1390 (99.7%) | detector + confirmation |
| IDSW: track lost in detector gap > `max_age` | 12 / 13 | 46 / 53 | detector + termination (`max_age=2`) |
| IDSW: track lost although detections were available | 1 | 1 | association (gating) |
| IDSW: identity swap / parallel-track takeover | 0 | 6 | association |
| Frag (strict): detector gap > `max_age` | 83 / 86 | 239 / 245 | detector + termination |

**Motion prediction** is not a limiting factor:
- **Innovation (Car):** median 0.11 m, 95th percentile 0.59 m.
- **Innovation (Pedestrian):** median 0.06 m, 95th percentile 0.16 m.
- **Filter consistency:** the filter is **over-conservative**. Mean NIS is 2.4 (Car) and 1.7 (Pedestrian) against an expected 7.0 for a consistent filter. The priors in `R`/`Q` are larger than the actual residuals. This does not cause errors here, but it widens the gates.

## 6. Failure cases (`results/evaluation/failure_cases.csv`)

The file contains 448 IDSW events and 2,214 strict fragmentation events, each with frame, GT ID, old/new track, gap length and cause, for all methods and both 3D thresholds. It also lists 552 hot-spot frames (top 3 per sequence × class × method × threshold).

* **ID switches concentrate in seq 0019 (pedestrians):** 40–44 of 52–63 pedestrian IDSW. It is a long, crowded pedestrian scene with frequent detector dropouts; the median gap before a track-loss IDSW is 8 frames. Car IDSW are spread over 0001, 0015 and 0016.
* **Hot-spot frames 0–1** in every sequence are initiation delay: no track can be confirmed before its third hit. Other hot spots: seq 0016 frames 0–1 (pedestrians), seq 0008 frames 157–188 (pedestrians), seq 0013 frame 235.
* **Candidate scenes for the Phase-3 viewer:**
  - 0016 frames 165–180: Center Car swap and pedestrian swaps.
  - 0019 frames 240–290 and 510–530: pedestrian swaps, takeover and association failure.
  - 0001 frame ~183: Car association failure.

## 7. Runtime

All 11 val sequences, 3,908 frames; Windows laptop CPU, single thread, Python:

| Method | Tracker step mean / median / p95 / max (ms) | Tracker-step FPS | End-to-end FPS excl. detector |
|---|---|---|---|
| Center | 0.76 / 0.69 / 1.52 / 5.1 | 1312 | 631 |
| Mahalanobis | 1.25 / 1.14 / 2.52 / 7.8 | 800 | 484 |
| 3D IoU | 1.37 / 1.28 / 2.74 / 11.4 | 731 | 459 |

"End-to-end" covers loading calibration, OXTS and detections, converting frames, running the tracker, and formatting and writing results. For Mahalanobis, of the 8.1 s total the tracker is 4.9 s and result formatting is 1.9 s.

**PointRCNN inference is not included**, because the detections are precomputed. These numbers are **not** the frame rate of a full LiDAR perception system; the detector would dominate. Visualisation playback is not part of this measurement.

## 8. Limitations and threats to validity

* **Small sample.** Ten held-out sequences, and one sequence (0019) dominates the pedestrian ID switches. Sequence-level bootstrap CIs with n = 10 are rough.
* **Not tuned, possibly not optimal.** The detector score threshold, `min_hits`, `max_age` and the KF noise were not tuned. NIS shows the KF noise is mis-scaled.
* **Detector training overlap.** That PointRCNN was not trained on these sequences is taken from the AB3DMOT split definition and was not independently verified.
* **2D results are not leaderboard results.** They are computed on training labels, with 2D boxes derived from 3D tracks.
* **Supplementary metrics.** Cyclist is not a KITTI tracking class. `Frag_strict` is a documented deviation from TrackEval.

## 9. Reproduce

```bash
pip install --no-deps "git+https://github.com/JonathonLuiten/TrackEval.git@12c8791b303e0a0b50f753af204249e622d0281a"  # optional, cross-check
for m in center mahalanobis iou; do
  python scripts/run_tracking.py --sequences 1 6 8 10 12 13 14 15 16 18 19 --method $m --name pointrcnn_$m
done
python scripts/evaluate.py         # ~1 min, includes TrackEval cross-checks
python scripts/make_figures.py
pytest
```
