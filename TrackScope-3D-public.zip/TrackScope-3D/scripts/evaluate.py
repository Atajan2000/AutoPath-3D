"""Phase-2 evaluation: custom 3D + KITTI-compatible 2D tracking metrics, detector-only
reference, error attribution, runtime, and TrackEval cross-checks.

Usage (after running scripts/run_tracking.py for each association method)::

    python scripts/evaluate.py
    python scripts/evaluate.py --experiments pointrcnn_center pointrcnn_mahalanobis pointrcnn_iou

Outputs go to results/evaluation/ (CSV + metrics.json + tables.md).
"""

from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import json
import platform
import shutil
import sys
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
import scipy
from scipy.stats import chi2

from trackscope.config import config_to_dict, load_config
from trackscope.evaluation.analysis import attribute_errors, innovation_stats, load_frame_records
from trackscope.evaluation.metrics import finalize, sum_counts
from trackscope.evaluation.protocol import (
    AB3DMOT_VAL, CLASS_SPECS, DEV_SEQUENCES, DONTCARE_IOA, HELDOUT_SEQUENCES, MAX_OCCLUSION,
    MAX_TRUNCATION, MIN_HEIGHT,
)
from trackscope.evaluation.runner import evaluate_detector, evaluate_tracking, load_inputs, load_tracker_results

REPO = Path(__file__).resolve().parents[1]
SETTINGS = [("3d", 0.25), ("3d", 0.5), ("2d", 0.5)]  # (mode, IoU threshold)
CLASSES_3D = ["Car", "Pedestrian", "Cyclist"]  # Cyclist: supplementary, not a KITTI tracking class
CLASSES_2D = ["Car", "Pedestrian"]  # official KITTI tracking classes
EVAL_LABEL = {"3d": "custom KITTI 3D tracking evaluation (oriented 3D IoU)",
              "2d": "KITTI-protocol 2D evaluation of projected 3D boxes (2D box IoU)"}
METRIC_COLS = ["GT", "GT_IDS", "TRK", "TRK_IDS", "TP", "FP", "FN", "IDSW", "Frag", "Frag_strict", "MT", "PT", "ML",
               "MOTA", "MOTP", "IDF1", "IDP", "IDR", "Precision", "Recall", "MODA", "IDTP", "IDFP", "IDFN"]


def split_of(seq):
    return "dev" if seq in DEV_SEQUENCES else "heldout"


def method_of(exp):
    return exp.replace("pointrcnn_", "")


def tree_hash(paths):
    h = hashlib.sha256()
    for p in sorted(paths):
        h.update(str(p.relative_to(REPO)).replace("\\", "/").encode())
        h.update(p.read_bytes())
    return h.hexdigest()


def write_csv(path: Path, rows: list[dict], cols: list[str] | None = None):
    cols = cols or list(dict.fromkeys(k for r in rows for k in r))
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow({k: (round(v, 6) if isinstance(v, float) else v) for k, v in r.items()})


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--experiments", nargs="*",
                    default=["pointrcnn_center", "pointrcnn_mahalanobis", "pointrcnn_iou"])
    ap.add_argument("--results-root", default="results")
    ap.add_argument("--out", default="results/evaluation")
    ap.add_argument("--no-trackeval", action="store_true", help="skip TrackEval cross-checks")
    args = ap.parse_args(argv)

    cfg = load_config(args.config)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    res_root = Path(args.results_root)
    classes_trk = list(cfg.tracker.classes)
    max_age = cfg.tracker.lifecycle.max_age
    seqs = list(AB3DMOT_VAL)

    # ---------------------------------------------------------------- inputs
    inputs = {s: load_inputs(cfg.data.kitti_root, cfg.data.detections_root, s, classes_trk) for s in seqs}
    summaries = {e: json.loads((res_root / e / "summary.json").read_text()) for e in args.experiments}
    for e, s in summaries.items():  # all experiments must share the frozen config except the method
        c = s["config"]
        c["tracker"]["association"].pop("method")
        c.pop("name")
    base = json.dumps(summaries[args.experiments[0]]["config"], sort_keys=True, default=str)
    for e in args.experiments[1:]:
        if json.dumps(summaries[e]["config"], sort_keys=True, default=str) != base:
            raise SystemExit(f"{e}: configuration differs from {args.experiments[0]} beyond the method")

    per_seq_rows, seq_evals, attributions = [], {}, {}
    records_cache = {}
    for exp in args.experiments:
        for s in seqs:
            gt, cam_dets, n = inputs[s]
            trk = load_tracker_results(res_root / exp / "kitti", s)
            for mode, thr in SETTINGS:
                for cls in (CLASSES_3D if mode == "3d" else CLASSES_2D):
                    se = evaluate_tracking(gt, trk, n, s, cls, mode, thr,
                                           match_threshold=0.5 if mode == "2d" else thr)
                    seq_evals[(exp, mode, thr, cls, s)] = se
                    per_seq_rows.append({"eval": mode, "iou_thr": thr, "method": method_of(exp), "class": cls,
                                         "seq": s, "split": split_of(s), **finalize(se.counts)})
                    if mode == "3d":
                        if (exp, s) not in records_cache:
                            records_cache[(exp, s)] = load_frame_records(res_root / exp / "frames" / f"{s}.jsonl")
                        attributions[(exp, thr, cls, s)] = attribute_errors(
                            se, gt, cam_dets, records_cache[(exp, s)],
                            cfg.tracker.score_threshold.get(cls, -np.inf), max_age)
        print(f"evaluated {exp}")

    # detector-only reference (identical preprocessing, no identities)
    det_rows = []
    for s in seqs:
        gt, cam_dets, n = inputs[s]
        for thr in (0.25, 0.5):
            for cls in CLASSES_3D:
                for label, smin in (("detector(score>=thr)", cfg.tracker.score_threshold.get(cls, -np.inf)),
                                    ("detector(all scores)", -np.inf)):
                    c = evaluate_detector(gt, cam_dets, n, cls, "3d", thr, smin)
                    det_rows.append({"eval": "3d", "iou_thr": thr, "method": label, "class": cls, "seq": s,
                                     "split": split_of(s), **finalize(c)})
    per_seq_rows += det_rows
    write_csv(out / "per_sequence.csv", per_seq_rows,
              ["eval", "iou_thr", "method", "class", "seq", "split"] + METRIC_COLS)

    # ---------------------------------------------------------------- aggregation
    def aggregate(rows_filter, split):
        groups = defaultdict(list)
        for r in per_seq_rows:
            if rows_filter(r) and (split == "all_val" or r["split"] == split):
                groups[(r["eval"], r["iou_thr"], r["method"], r["class"])].append(r)
        agg = []
        for (mode, thr, m, cls), rs in sorted(groups.items()):
            counts = sum_counts([{k: r[k] for k in r if k in ("GT", "GT_IDS", "TRK", "TRK_IDS", "TP", "FP", "FN",
                                                              "IDSW", "Frag", "Frag_strict", "MT", "PT", "ML", "IDTP", "IDFP",
                                                              "IDFN") and k in r}
                                 | {"MOTP_sum": r["MOTP"] * r["TP"]} for r in rs])
            agg.append({"eval": mode, "iou_thr": thr, "method": m, "class": cls, "split": split,
                        "n_seqs": len(rs), **finalize(counts)})
        return agg

    per_class = []
    for split in ("heldout", "dev", "all_val"):
        per_class += aggregate(lambda r: True, split)
    write_csv(out / "per_class.csv", per_class, ["eval", "iou_thr", "method", "class", "split", "n_seqs"] + METRIC_COLS)
    agg_index = {(r["eval"], r["iou_thr"], r["method"], r["class"], r["split"]): r for r in per_class}

    # ---------------------------------------------------------------- runtime
    runtime = {}
    for exp, s in summaries.items():
        lat = s["tracker_step_latency_overall"]
        stages = Counter()
        for q in s["sequences"]:
            stages.update(q["stage_time_s"])
        runtime[method_of(exp)] = {
            "frames": s["total_frames"], "sequences": [q["sequence"] for q in s["sequences"]],
            "tracker_step_fps": s["tracker_fps_overall"], **{f"tracker_step_{k}": v for k, v in lat.items()},
            "end_to_end_fps_excl_detector": s["end_to_end_fps_excl_detector"],
            "stage_time_s": dict(stages),
            "tracks_born_all_classes": {q["sequence"]: q["tracks_born"] for q in s["sequences"]},
            "tracks_confirmed_all_classes": {q["sequence"]: q["tracks_confirmed"] for q in s["sequences"]},
        }

    # ---------------------------------------------------------------- attribution aggregates
    attr_agg = {}
    for (exp, thr, cls, s), a in attributions.items():
        if split_of(s) != "heldout":
            continue
        key = (method_of(exp), thr, cls)
        d = attr_agg.setdefault(key, {"fn": Counter(), "fp": Counter(), "idsw": Counter(), "frag": Counter()})
        for k in d:
            d[k].update(a[k])

    # motion-prediction residuals (held-out, per method and class)
    motion = {}
    gate99 = float(chi2.ppf(0.99, 7))
    for exp in args.experiments:
        pooled = defaultdict(lambda: {"innov_xy": [], "nis": []})
        for s in HELDOUT_SEQUENCES:
            for cls, v in innovation_stats(records_cache[(exp, s)]).items():
                pooled[cls]["innov_xy"] += v["innov_xy"]
                pooled[cls]["nis"] += v["nis"]
        motion[method_of(exp)] = {cls: {
            "n_updates": len(v["nis"]),
            "innov_xy_median_m": float(np.median(v["innov_xy"])), "innov_xy_p95_m": float(np.percentile(v["innov_xy"], 95)),
            "nis_mean": float(np.mean(v["nis"])), "nis_median": float(np.median(v["nis"])),
            "nis_expected_mean_chi2_7": 7.0, "frac_nis_above_chi2_7_99pct": float(np.mean(np.array(v["nis"]) > gate99)),
        } for cls, v in pooled.items() if v["nis"]}

    # ---------------------------------------------------------------- false tracks (lifecycle)
    def false_track_stats(exp, mode, thr, cls):
        n_ids = n_false = fp_from_false = 0
        for s in HELDOUT_SEQUENCES:
            se = seq_evals[(exp, mode, thr, cls, s)]
            ids = {int(t) for fe in se.frames for t in fe.trk_ids}
            hit = {t for ms in se.events.matches.values() for _, t, _ in ms}
            false = ids - hit
            n_ids += len(ids)
            n_false += len(false)
            fp_from_false += sum(1 for v in se.events.fp.values() for t in v if t in false)
        return {"tracker_ids": n_ids, "false_tracks": n_false, "FP_from_false_tracks": fp_from_false}

    # ---------------------------------------------------------------- paired bootstrap over sequences
    rng = np.random.default_rng(0)
    B = 10000
    boot_idx = rng.integers(0, len(HELDOUT_SEQUENCES), size=(B, len(HELDOUT_SEQUENCES)))

    def seq_counts(m, mode, thr, cls):
        rs = {r["seq"]: r for r in per_seq_rows if r["method"] == m and r["eval"] == mode
              and r["iou_thr"] == thr and r["class"] == cls}
        keys = ("GT", "TP", "FP", "FN", "IDSW", "IDTP", "IDFP", "IDFN")
        return np.array([[rs[s][k] for k in keys] for s in HELDOUT_SEQUENCES], float)

    def mota_idf1(arr):  # arr (..., n_seq, 8) -> sums over sequences
        s = arr.sum(axis=-2)
        mota = (s[..., 1] - s[..., 2] - s[..., 4]) / np.maximum(1, s[..., 0])
        idf1 = s[..., 5] / np.maximum(1, s[..., 5] + 0.5 * s[..., 6] + 0.5 * s[..., 7])
        return mota, idf1

    def paired(a_m, b_m, mode, thr, cls):
        A, Bc = seq_counts(a_m, mode, thr, cls), seq_counts(b_m, mode, thr, cls)
        ma, ia = mota_idf1(A[boot_idx])
        mb, ib = mota_idf1(Bc[boot_idx])
        dm, di = ma - mb, ia - ib
        dsw = A[boot_idx][..., 4].sum(-1) - Bc[boot_idx][..., 4].sum(-1)
        per_m = mota_idf1(A[:, None, :])[0] - mota_idf1(Bc[:, None, :])[0]
        return {"dMOTA": float(mota_idf1(A)[0] - mota_idf1(Bc)[0]),
                "dMOTA_CI95": [float(np.percentile(dm, 2.5)), float(np.percentile(dm, 97.5))],
                "dIDF1": float(mota_idf1(A)[1] - mota_idf1(Bc)[1]),
                "dIDF1_CI95": [float(np.percentile(di, 2.5)), float(np.percentile(di, 97.5))],
                "dIDSW": int(A[:, 4].sum() - Bc[:, 4].sum()),
                "dIDSW_CI95": [float(np.percentile(dsw, 2.5)), float(np.percentile(dsw, 97.5))],
                "seqs_MOTA_better": int((per_m > 1e-12).sum()), "seqs_MOTA_worse": int((per_m < -1e-12).sum()),
                "seqs_MOTA_tied": int((np.abs(per_m) <= 1e-12).sum())}

    paired_results = {}
    meths = [method_of(e) for e in args.experiments]
    for mode, thr in SETTINGS:
        for cls in (["Car", "Pedestrian"]):
            for a_m in meths:
                for b_m in meths:
                    if a_m != b_m:
                        paired_results[f"{a_m}-vs-{b_m}|{cls}|{mode}@{thr}"] = paired(a_m, b_m, mode, thr, cls)

    # ---------------------------------------------------------------- association comparison
    comp_rows = []
    for mode, thr in SETTINGS:
        for cls in (CLASSES_3D if mode == "3d" else CLASSES_2D):
            ref = agg_index.get((mode, thr, "center", cls, "heldout"))
            for exp in args.experiments:
                m = method_of(exp)
                r = agg_index[(mode, thr, m, cls, "heldout")]
                row = {"eval": mode, "iou_thr": thr, "class": cls, "method": m,
                       **{k: r[k] for k in ("MOTA", "IDF1", "IDSW", "FP", "FN", "Frag", "Frag_strict", "MT", "ML", "Precision",
                                            "Recall", "GT", "TRK_IDS", "GT_IDS")},
                       "tracker_step_fps": runtime[m]["tracker_step_fps"],
                       "tracker_step_p95_ms": runtime[m]["tracker_step_p95_ms"],
                       "tracks_born_heldout_all_classes": sum(v for k, v in runtime[m]["tracks_born_all_classes"].items()
                                                             if k in HELDOUT_SEQUENCES)}
                if ref is not None:
                    gtn = max(1, r["GT"])
                    row["dMOTA_vs_center"] = r["MOTA"] - ref["MOTA"]
                    row["dMOTA_from_FN"] = -(r["FN"] - ref["FN"]) / gtn
                    row["dMOTA_from_FP"] = -(r["FP"] - ref["FP"]) / gtn
                    row["dMOTA_from_IDSW"] = -(r["IDSW"] - ref["IDSW"]) / gtn
                    row["dIDF1_vs_center"] = r["IDF1"] - ref["IDF1"]
                    if m != "center" and cls in ("Car", "Pedestrian"):
                        p = paired_results[f"{m}-vs-center|{cls}|{mode}@{thr}"]
                        row["dMOTA_CI95_lo"], row["dMOTA_CI95_hi"] = p["dMOTA_CI95"]
                        row["dIDF1_CI95_lo"], row["dIDF1_CI95_hi"] = p["dIDF1_CI95"]
                        row["seqs_MOTA_better_worse_tied"] = (f"{p['seqs_MOTA_better']}/{p['seqs_MOTA_worse']}/"
                                                              f"{p['seqs_MOTA_tied']}")
                row.update(false_track_stats(exp, mode, thr, cls))
                if mode == "3d":
                    a = attr_agg.get((m, thr, cls), {})
                    for kind in ("fn", "fp", "idsw", "frag"):
                        for cause, n in sorted(a.get(kind, {}).items()):
                            row[f"{kind}_{cause}"] = n
                comp_rows.append(row)
    write_csv(out / "association_comparison.csv", comp_rows)

    # ---------------------------------------------------------------- summary (headline)
    summary_rows = []
    for mode, thr in SETTINGS:
        for cls in (["Car", "Pedestrian"]):
            for exp in args.experiments:
                m = method_of(exp)
                r = agg_index[(mode, thr, m, cls, "heldout")]
                summary_rows.append({"evaluation": EVAL_LABEL[mode], "iou_thr": thr, "class": cls, "method": m,
                                     **{k: r[k] for k in ("MOTA", "IDF1", "IDSW", "FP", "FN", "Frag", "Frag_strict", "Precision",
                                                          "Recall", "MOTP", "MT", "ML", "GT")},
                                     "tracker_step_fps": runtime[m]["tracker_step_fps"]})
            if mode == "3d":
                for label in ("detector(score>=thr)", "detector(all scores)"):
                    r = agg_index[(mode, thr, label, cls, "heldout")]
                    summary_rows.append({"evaluation": EVAL_LABEL[mode] + " - detector only", "iou_thr": thr,
                                         "class": cls, "method": label,
                                         **{k: r[k] for k in ("FP", "FN", "Precision", "Recall", "MOTP", "GT")},
                                         "MODA": r["MODA"]})
    write_csv(out / "summary.csv", summary_rows)

    # ---------------------------------------------------------------- failure cases
    fail_rows = []
    for (exp, thr, cls, s), a in sorted(attributions.items()):
        for e in a["idsw_events"]:
            fail_rows.append({"type": "IDSW", "method": method_of(exp), "iou_thr": thr, "class": cls, "seq": s,
                              "split": split_of(s), **e})
        for e in a["frag_events"]:
            fail_rows.append({"type": "FRAG", "method": method_of(exp), "iou_thr": thr, "class": cls, "seq": s,
                              "split": split_of(s), **e})
        # error hot-spot frames: FN + FP + IDSW per frame
        per_frame = Counter()
        for f, _, _ in a["fn_events"]:
            per_frame[f] += 1
        for f, _, _ in a["fp_events"]:
            per_frame[f] += 1
        for e in a["idsw_events"]:
            per_frame[e["frame"]] += 1
        for f, n in per_frame.most_common(3):
            fail_rows.append({"type": "HOTSPOT_FRAME", "method": method_of(exp), "iou_thr": thr, "class": cls,
                              "seq": s, "split": split_of(s), "frame": f, "errors_in_frame": n,
                              "cause": "FN+FP+IDSW count"})
    write_csv(out / "failure_cases.csv", fail_rows,
              ["type", "method", "iou_thr", "class", "seq", "split", "frame", "gt_id", "old_track", "new_track",
               "track", "last_match_frame", "gap_frames", "detector_coverage_in_gap", "errors_in_frame", "cause"])

    idsw_by_seq = defaultdict(dict)
    for r in per_seq_rows:
        if r["eval"] == "3d" and r["method"] in map(method_of, args.experiments):
            idsw_by_seq[f"{r['method']}|{r['class']}|{r['iou_thr']}"][r["seq"]] = r["IDSW"]

    # ---------------------------------------------------------------- TrackEval cross-checks
    crosscheck = {"performed": False}
    if not args.no_trackeval:
        try:
            from trackscope.evaluation.trackeval_bridge import (
                TRACKEVAL_COMMIT, trackeval_kitti_2d, trackeval_metrics_on_frames,
            )
            fields = ["TP", "FP", "FN", "IDSW", "Frag", "MT", "PT", "ML", "IDTP", "IDFP", "IDFN"]
            mism, n2d, n3d, examples = 0, 0, 0, []
            lengths = {s: inputs[s][2] for s in seqs}
            for exp in args.experiments:
                te2d = trackeval_kitti_2d(Path(cfg.data.kitti_root) / "training" / "label_02", res_root, exp,
                                          "kitti", lengths, out / "_trackeval" / exp)
                for (s, cls), ref in te2d.items():
                    ours = seq_evals[(exp, "2d", 0.5, cls, s)].counts
                    n2d += 1
                    bad = [k for k in fields if ours[k] != ref[k]]
                    if bad:
                        mism += 1
                        examples.append({"check": "2d", "exp": exp, "seq": s, "cls": cls,
                                         "ours": {k: ours[k] for k in bad}, "trackeval": {k: ref[k] for k in bad}})
                for (e, mode, thr, cls, s), se in seq_evals.items():
                    if e != exp or mode != "3d":
                        continue
                    ref = trackeval_metrics_on_frames(se.frames, thr)
                    n3d += 1
                    bad = [k for k in fields if se.counts[k] != ref[k]]
                    if bad:
                        mism += 1
                        examples.append({"check": "3d", "exp": exp, "seq": s, "cls": cls, "thr": thr,
                                         "ours": {k: se.counts[k] for k in bad}, "trackeval": {k: ref[k] for k in bad}})
            crosscheck = {"performed": True, "trackeval_commit": TRACKEVAL_COMMIT,
                          "kitti2d_full_pipeline_comparisons": n2d, "metric_only_3d_comparisons": n3d,
                          "fields_compared": fields, "mismatching_comparisons": mism, "mismatch_examples": examples[:20]}
            print(f"TrackEval cross-check: {n2d} full 2D + {n3d} 3D comparisons, {mism} mismatching")
            shutil.rmtree(out / "_trackeval", ignore_errors=True)  # scratch: copied KITTI labels
        except ImportError as e:
            crosscheck = {"performed": False, "reason": f"TrackEval not importable: {e}"}

    # ---------------------------------------------------------------- metrics.json
    src_files = list((REPO / "src" / "trackscope").rglob("*.py"))
    metrics = {
        "generated": dt.datetime.now().isoformat(timespec="seconds"),
        "label": "Custom KITTI 3D tracking evaluation and KITTI-protocol 2D evaluation of projected boxes on "
                 "KITTI Tracking *training* sequences (AB3DMOT val split). NOT official KITTI leaderboard results.",
        "protocol": {
            "dev_sequences": list(DEV_SEQUENCES), "heldout_sequences": list(HELDOUT_SEQUENCES),
            "split_note": "0014 was used for Phase-1 development and geometry validation; the 10 other AB3DMOT val "
                          "sequences are held out. The configuration was frozen before any metric was computed; "
                          "no parameter was tuned in Phase 2.",
            "classes_3d": CLASSES_3D, "classes_2d": CLASSES_2D,
            "distractors": {k: list(v.distractors) for k, v in CLASS_SPECS.items()},
            "ignore_rules": {"max_occlusion": MAX_OCCLUSION, "max_truncation": MAX_TRUNCATION,
                             "min_height_px": MIN_HEIGHT, "dontcare_ioa": DONTCARE_IOA},
            "settings": [{"eval": m, "iou_thr": t, "label": EVAL_LABEL[m],
                          "preprocessing_match_thr": 0.5 if m == "2d" else t} for m, t in SETTINGS],
            "detector": cfg.data.detector_name, "detector_score_threshold": dict(cfg.tracker.score_threshold),
            "aggregation": "counts summed over sequences, ratios recomputed from sums; classes reported separately",
            "not_reported": "AMOTA/sAMOTA/HOTA (protocols not implemented/validated here)",
        },
        "versions": {
            "trackscope": "0.1.0", "src_sha256": tree_hash(src_files),
            "config_file": args.config, "config_sha256": hashlib.sha256(Path(args.config).read_bytes()).hexdigest(),
            "python": platform.python_version(), "numpy": np.__version__, "scipy": scipy.__version__,
            "detections": (Path(cfg.data.detections_root) / "SOURCE.txt").read_text().splitlines()[1],
        },
        "frozen_config": config_to_dict(cfg),
        "experiments": args.experiments,
        "heldout_results": [r for r in per_class if r["split"] == "heldout"],
        "dev_results": [r for r in per_class if r["split"] == "dev"],
        "error_attribution_heldout": {f"{m}|{cls}|{thr}": {k: dict(v) for k, v in d.items()}
                                      for (m, thr, cls), d in sorted(attr_agg.items())},
        "motion_prediction_heldout": motion,
        "runtime": runtime,
        "runtime_note": "tracker_step_* = MultiObjectTracker.step only (CPU, single thread, Python). "
                        "end_to_end_fps_excl_detector includes loading, conversion and result writing. PointRCNN "
                        "inference time is not measured here (precomputed detections), so these figures are NOT "
                        "full perception-system frame rates.",
        "idsw_by_sequence_3d": idsw_by_seq,
        "paired_bootstrap_heldout": {"note": f"A-vs-B differences (A minus B); 95% percentile CI from {B} "
                                             "bootstrap resamples of the 10 held-out sequences (seed 0).",
                                     "results": paired_results},
        "trackeval_crosscheck": crosscheck,
    }
    (out / "metrics.json").write_text(json.dumps(metrics, indent=2, default=lambda o: o.item() if hasattr(o, "item") else str(o)))
    print(f"wrote {out}/: summary.csv per_sequence.csv per_class.csv association_comparison.csv failure_cases.csv metrics.json")
    return 0


if __name__ == "__main__":
    sys.exit(main())
