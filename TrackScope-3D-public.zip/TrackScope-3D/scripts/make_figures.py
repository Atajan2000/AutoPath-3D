"""Phase-2 figures from results/evaluation/*.csv (no recomputation).

    python scripts/make_figures.py

Writes results/evaluation/figures/{association_comparison,idsw_by_sequence,performance_by_class}.png
"""

from __future__ import annotations

import csv
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402

EVAL = Path("results/evaluation")
FIG = EVAL / "figures"
# Categorical slots 1-4 of the validated reference palette (light mode); colour follows entity.
COLORS = {"center": "#2a78d6", "mahalanobis": "#eb6834", "iou": "#1baf7a", "detector": "#eda100"}
LABELS = {"center": "Center distance", "mahalanobis": "Mahalanobis gated", "iou": "3D IoU",
          "detector": "Detector only (score ≥ 0)"}
METHODS = ["center", "mahalanobis", "iou"]
INK, INK2, MUTED, GRID, AXIS, SURFACE = "#0b0b0b", "#52514e", "#898781", "#e1e0d9", "#c3c2b7", "#fcfcfb"

plt.rcParams.update({
    "figure.facecolor": SURFACE, "axes.facecolor": SURFACE, "savefig.facecolor": SURFACE,
    "axes.edgecolor": AXIS, "axes.labelcolor": INK2, "xtick.color": MUTED, "ytick.color": MUTED,
    "text.color": INK, "font.size": 9, "axes.titlesize": 10, "axes.titleweight": "bold",
    "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True, "axes.grid.axis": "y",
    "grid.color": GRID, "grid.linewidth": 0.6, "axes.axisbelow": True, "legend.frameon": False,
})


def rows(name):
    return list(csv.DictReader(open(EVAL / name)))


def bars(ax, groups, series, values, fmt="{:.3f}", width=0.26):
    """Grouped bars with a 2px-equivalent gap and direct value labels (contrast relief)."""
    x = np.arange(len(groups))
    n = len(series)
    for i, s in enumerate(series):
        v = np.array(values[s], float)
        pos = x + (i - (n - 1) / 2) * width
        ax.bar(pos, v, width * 0.9, color=COLORS[s], label=LABELS[s], zorder=2)
        for p, val in zip(pos, v):
            if np.isfinite(val):
                ax.text(p, val, fmt.format(val), ha="center", va="bottom", fontsize=7, color=INK2)
    ax.set_xticks(x, groups)
    ax.tick_params(axis="x", colors=INK2, length=0)


def fig_association():
    pc = {(r["eval"], r["iou_thr"], r["method"], r["class"], r["split"]): r for r in rows("per_class.csv")}
    boot = json.load(open(EVAL / "metrics.json"))["paired_bootstrap_heldout"]["results"]
    fig, axes = plt.subplots(2, 3, figsize=(12.5, 6.2), gridspec_kw={"width_ratios": [1.25, 0.9, 1.25]})
    for row, cls in enumerate(["Car", "Pedestrian"]):
        ax = axes[row, 0]  # absolute MOTA / IDF1 as horizontal bars, labels at bar ends
        groups = [f"{met} @{t}" for t in ("0.25", "0.5") for met in ("MOTA", "IDF1")]
        h = 0.26
        for i, m in enumerate(METHODS):
            v = [float(pc[("3d", t, m, cls, "heldout")][met]) for t in ("0.25", "0.5") for met in ("MOTA", "IDF1")]
            pos = np.arange(len(groups)) + (i - 1) * h
            ax.barh(pos, v, h * 0.9, color=COLORS[m], label=LABELS[m], zorder=2)
            for p, val in zip(pos, v):
                ax.text(val + 0.01, p, f"{val:.3f}", va="center", fontsize=7, color=INK2)
        ax.set_yticks(range(len(groups)), groups, color=INK2)
        ax.invert_yaxis()
        ax.set_xlim(0, 1.08)
        ax.grid(axis="x")
        ax.grid(axis="y", visible=False)
        ax.set_title(f"{cls} · MOTA and IDF1", loc="left")
        ax = axes[row, 1]
        vals = {m: [float(pc[("3d", t, m, cls, "heldout")]["IDSW"]) for t in ("0.25", "0.5")] for m in METHODS}
        bars(ax, ["IoU 0.25", "IoU 0.5"], METHODS, vals, fmt="{:.0f}")
        ax.set_title(f"{cls} · ID switches", loc="left")
        ax = axes[row, 2]  # paired difference vs centre, bootstrap CI
        labels, pos = [], 0
        for t in ("0.25", "0.5"):
            for m in ("mahalanobis", "iou"):
                b = boot[f"{m}-vs-center|{cls}|3d@{t}"]
                lo, hi = b["dMOTA_CI95"]
                ax.errorbar(b["dMOTA"], pos, xerr=[[b["dMOTA"] - lo], [hi - b["dMOTA"]]], fmt="o", ms=6,
                            color=COLORS[m], ecolor=COLORS[m], elinewidth=2, capsize=3, zorder=3)
                labels.append(f"{LABELS[m]} @{t}")
                pos += 1
        ax.axvline(0, color=AXIS, lw=1, zorder=1)
        ax.set_yticks(range(pos), labels, fontsize=8, color=INK2)
        ax.invert_yaxis()
        ax.grid(axis="x")
        ax.grid(axis="y", visible=False)
        ax.set_title(f"{cls} · ΔMOTA vs center, 95% CI", loc="left")
        ax.set_xlabel("MOTA difference")
    h, lab = axes[0, 0].get_legend_handles_labels()
    fig.legend(h, lab, loc="upper center", ncol=3, bbox_to_anchor=(0.5, 1.0))
    fig.suptitle("Association methods · custom KITTI 3D tracking evaluation · 10 held-out val sequences",
                 y=0.94, fontsize=10, color=INK2)
    fig.text(0.01, 0.005, "Identical PointRCNN detections and frozen settings; only the association criterion "
             "differs. CIs: paired bootstrap over sequences (10k). Not official KITTI scores.",
             fontsize=7, color=MUTED)
    fig.tight_layout(rect=(0, 0.03, 1, 0.92))
    fig.savefig(FIG / "association_comparison.png", dpi=150)
    plt.close(fig)


def fig_idsw_by_sequence():
    ps = [r for r in rows("per_sequence.csv") if r["eval"] == "3d" and r["iou_thr"] == "0.25"]
    seqs = sorted({r["seq"] for r in ps})
    fig, axes = plt.subplots(2, 1, figsize=(11, 5.8), sharex=True)
    for ax, cls in zip(axes, ["Car", "Pedestrian"]):
        idx = {(r["method"], r["seq"]): r for r in ps if r["class"] == cls}
        vals = {m: [int(idx[(m, s)]["IDSW"]) for s in seqs] for m in METHODS}
        bars(ax, [f"{s}\n(dev)" if s == "0014" else s for s in seqs], METHODS, vals, fmt="{:.0f}")
        ax.set_title(f"{cls} · ID switches per sequence (3D IoU 0.25)", loc="left")
        ax.set_ylabel("ID switches")
    h, lab = axes[0].get_legend_handles_labels()
    fig.legend(h, lab, loc="upper center", ncol=3, bbox_to_anchor=(0.5, 1.0))
    fig.text(0.01, 0.005, "0014 = development sequence (excluded from held-out aggregates). "
             "Custom KITTI 3D tracking evaluation.", fontsize=7, color=MUTED)
    fig.tight_layout(rect=(0, 0.03, 1, 0.95))
    fig.savefig(FIG / "idsw_by_sequence.png", dpi=150)
    plt.close(fig)


def fig_by_class():
    pc = {(r["method"], r["class"]): r for r in rows("per_class.csv")
          if r["eval"] == "3d" and r["iou_thr"] == "0.25" and r["split"] == "heldout"}
    classes = ["Car", "Pedestrian", "Cyclist"]
    det, trk = "detector(score>=thr)", "mahalanobis"
    fig, axes = plt.subplots(1, 4, figsize=(12.5, 3.8))
    panels = [("Recall", "Recall", "Recall"), ("Precision", "Precision", "Precision"),
              ("MOTA (tracker) · MODA (detector)", "MODA", "MOTA"), ("IDF1 (tracker only)", None, "IDF1")]
    for ax, (title, det_metric, trk_metric) in zip(axes, panels):
        vals = {}
        if det_metric:
            vals["detector"] = [float(pc[(det, c)][det_metric]) for c in classes]
        vals["mahalanobis"] = [float(pc[(trk, c)][trk_metric]) for c in classes]
        bars(ax, ["Car", "Pedestrian", "Cyclist*"], list(vals), vals, width=0.38, fmt="{:.2f}")
        ax.set_title(title, loc="left")
        ax.set_ylim(min(0, min(min(v) for v in vals.values()) - 0.05), 1.08)
        ax.axhline(0, color=AXIS, lw=0.8)
    h, lab = axes[0].get_legend_handles_labels()
    fig.legend(h, ["Detector only (PointRCNN, score ≥ 0)", "Tracker (Mahalanobis gated, default)"],
               loc="upper center", ncol=2, bbox_to_anchor=(0.5, 1.02))
    fig.text(0.01, 0.01, "Custom KITTI 3D tracking evaluation, 3D IoU 0.25, 10 held-out sequences. Detector only = "
             "per-frame matching of raw boxes (no identities, so MODA instead of MOTA). "
             "*Cyclist is not a KITTI tracking benchmark class (supplementary).", fontsize=7, color=MUTED)
    fig.tight_layout(rect=(0, 0.05, 1, 0.9))
    fig.savefig(FIG / "performance_by_class.png", dpi=150)
    plt.close(fig)


if __name__ == "__main__":
    FIG.mkdir(parents=True, exist_ok=True)
    fig_association()
    fig_idsw_by_sequence()
    fig_by_class()
    print(f"wrote {sorted(p.name for p in FIG.glob('*.png'))}")
