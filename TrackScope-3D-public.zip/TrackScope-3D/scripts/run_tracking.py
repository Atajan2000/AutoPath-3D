"""Run TrackScope-3D on KITTI Tracking sequences.

Examples::

    python scripts/run_tracking.py                                   # configs/default.yaml
    python scripts/run_tracking.py --sequences 1 6 8 10 12 13 14 15 16 18 19
    python scripts/run_tracking.py --method center --name pointrcnn_center
"""

from __future__ import annotations

import argparse
import sys

from trackscope.config import load_config
from trackscope.pipeline import run_experiment


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--sequences", nargs="*", help="override data.sequences (e.g. 14 or 0014)")
    ap.add_argument("--method", choices=["center", "mahalanobis", "iou"], help="override association method")
    ap.add_argument("--name", help="override experiment name (output sub-directory)")
    args = ap.parse_args(argv)

    overrides = {}
    if args.method:
        overrides["tracker.association.method"] = args.method
    if args.name:
        overrides["name"] = args.name
    if args.sequences:
        overrides["data.sequences"] = args.sequences
    cfg = load_config(args.config, overrides)

    summary = run_experiment(cfg)
    print(f"experiment {summary['experiment']}  (association={cfg.tracker.association.method})")
    print(f"{'seq':>5} {'frames':>6} {'dets in':>7} {'used':>5} {'born':>5} {'confirmed':>9} {'rows':>5} {'trk FPS':>8}")
    for s in summary["sequences"]:
        print(f"{s['sequence']:>5} {s['frames']:6d} {s['detections_in']:7d} {s['detections_used']:5d} "
              f"{s['tracks_born']:5d} {s['tracks_confirmed']:9d} {s['output_rows_kitti']:5d} {s['tracker_fps']:8.0f}")
    print(f"overall tracker FPS: {summary['tracker_fps_overall']:.0f}  ->  {cfg.output_dir}/{cfg.name}/")
    return 0


if __name__ == "__main__":
    sys.exit(main())
