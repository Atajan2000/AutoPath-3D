"""Download the minimal KITTI Tracking + PointRCNN data needed by TrackScope-3D.

Stdlib only. What it fetches (into ``--data-root``, default ``data/``):

1. KITTI Tracking metadata zips (labels 2.3 MB, calib 0.1 MB, oxts 8.4 MB), extracted
   to ``kitti_tracking/{training,testing}/...``.
2. PointRCNN 3D detections on KITTI Tracking *training* sequences, as published by
   AB3DMOT (pinned commit), into ``detections/pointrcnn/<Class>/<seq>.txt``.
3. Optionally, for selected sequences only, the LiDAR scans (``--velodyne``) and left
   colour images (``--images``). These live inside 36.8 GB / 15.8 GB zip files; instead of
   downloading them, we read the zip central directory with HTTP range requests and
   pull only the members of the requested sequences (~2 MB per scan, ~0.9 MB per image).

Example::

    python scripts/download_data.py --sequences 0014 --velodyne --images
"""

from __future__ import annotations

import argparse
import http.client
import io
import time
import shutil
import sys
import urllib.request
import zipfile
from pathlib import Path

KITTI_BASE = "https://s3.eu-central-1.amazonaws.com/avg-kitti"
AB3DMOT_COMMIT = "61f3bd72574093e367916c757b4747ca445f978c"  # master, 2023-05-24
AB3DMOT_DET_URL = (
    "https://raw.githubusercontent.com/xinshuoweng/AB3DMOT/"
    f"{AB3DMOT_COMMIT}/data/KITTI/detection/pointrcnn_{{cls}}_val/{{seq}}.txt"
)
METADATA_ZIPS = ["data_tracking_label_2.zip", "data_tracking_calib.zip", "data_tracking_oxts.zip"]
CLASSES = ["Car", "Pedestrian", "Cyclist"]
TRAINING_SEQS = [f"{i:04d}" for i in range(21)]
USER_AGENT = "TrackScope-3D-downloader/0.1"


def _get(url: str, headers: dict | None = None) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, **(headers or {})})
    with urllib.request.urlopen(req, timeout=120) as r:
        return r.read()


def _content_length(url: str) -> int:
    req = urllib.request.Request(url, method="HEAD", headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=60) as r:
        return int(r.headers["Content-Length"])


class HttpRangeFile(io.RawIOBase):
    """Read-only, seekable file over HTTP using Range requests, with a read-ahead buffer.

    Lets :mod:`zipfile` open a multi-GB remote archive while transferring only the central
    directory and the requested members.
    """

    def __init__(self, url: str, readahead: int = 8 << 20):
        self.url, self.readahead = url, readahead
        self.size = _content_length(url)
        self.pos = 0
        self._buf_start, self._buf = 0, b""
        self.bytes_fetched = 0

    def seekable(self) -> bool:
        return True

    def readable(self) -> bool:
        return True

    def tell(self) -> int:
        return self.pos

    def seek(self, offset: int, whence: int = io.SEEK_SET) -> int:
        base = {io.SEEK_SET: 0, io.SEEK_CUR: self.pos, io.SEEK_END: self.size}[whence]
        self.pos = base + offset
        return self.pos

    def _fetch(self, start: int, length: int, retries: int = 8) -> None:
        end = min(self.size, start + max(length, self.readahead)) - 1
        chunks, got = [], 0
        for attempt in range(retries + 1):
            try:
                chunks.append(_get(self.url, {"Range": f"bytes={start + got}-{end}"}))
                got += len(chunks[-1])
            except (http.client.IncompleteRead, OSError) as e:
                partial = getattr(e, "partial", b"")
                if partial:  # keep what arrived and resume from there
                    chunks.append(partial)
                    got += len(partial)
                if attempt == retries:
                    raise
                time.sleep(1.0 + attempt)
            if got >= end - start + 1:
                break
        data = b"".join(chunks)
        if len(data) != end - start + 1:
            raise IOError(f"short range read: wanted {end - start + 1}, got {len(data)}")
        self._buf_start, self._buf = start, data
        self.bytes_fetched += len(data)

    def read(self, n: int = -1) -> bytes:
        if n is None or n < 0:
            n = self.size - self.pos
        n = min(n, self.size - self.pos)
        if n <= 0:
            return b""
        off = self.pos - self._buf_start
        if not (0 <= off and off + n <= len(self._buf)):
            self._fetch(self.pos, n)
            off = 0
        out = self._buf[off : off + n]
        self.pos += n
        return out

    def readinto(self, b) -> int:  # pragma: no cover - zipfile uses read()
        data = self.read(len(b))
        b[: len(data)] = data
        return len(data)


def fetch_metadata(root: Path) -> None:
    dl = root / "downloads"
    dl.mkdir(parents=True, exist_ok=True)
    for name in METADATA_ZIPS:
        dst = dl / name
        url = f"{KITTI_BASE}/{name}"
        expected = _content_length(url)
        if not dst.exists() or dst.stat().st_size != expected:
            print(f"[meta] downloading {name} ({expected / 1e6:.1f} MB)")
            dst.write_bytes(_get(url))
        if dst.stat().st_size != expected:
            raise IOError(f"{name}: size mismatch")
        with zipfile.ZipFile(dst) as zf:
            zf.extractall(root / "kitti_tracking")
        print(f"[meta] extracted {name}")


def fetch_detections(root: Path, seqs: list[str]) -> None:
    for cls in CLASSES:
        out_dir = root / "detections" / "pointrcnn" / cls
        out_dir.mkdir(parents=True, exist_ok=True)
        for seq in seqs:
            dst = out_dir / f"{seq}.txt"
            if dst.exists() and dst.stat().st_size > 0:
                continue
            dst.write_bytes(_get(AB3DMOT_DET_URL.format(cls=cls, seq=seq)))
        print(f"[det] PointRCNN {cls}: {len(seqs)} sequences -> {out_dir}")
    (root / "detections" / "pointrcnn" / "SOURCE.txt").write_text(
        "PointRCNN detections on KITTI Tracking training sequences, from AB3DMOT\n"
        f"commit {AB3DMOT_COMMIT}\n"
        f"url template: {AB3DMOT_DET_URL}\n"
        "row format: frame,type(1=Ped,2=Car,3=Cyc),x1,y1,x2,y2,score,h,w,l,x,y,z,ry,alpha\n"
    )


def fetch_sequence_members(root: Path, zip_name: str, subdir: str, seqs: list[str]) -> None:
    url = f"{KITTI_BASE}/{zip_name}"
    rf = HttpRangeFile(url)
    with zipfile.ZipFile(io.BufferedReader(rf, buffer_size=1 << 20)) as zf:
        print(f"[{subdir}] remote zip {zip_name}: {rf.size / 1e9:.1f} GB, "
              f"{len(zf.infolist())} members (central dir fetched)")
        for seq in seqs:
            prefix = f"training/{subdir}/{seq}/"
            members = sorted(
                (i for i in zf.infolist() if i.filename.startswith(prefix) and not i.is_dir()),
                key=lambda i: i.header_offset,
            )
            if not members:
                raise FileNotFoundError(f"no members under {prefix} in {zip_name}")
            n_new = 0
            for info in members:
                dst = root / "kitti_tracking" / info.filename
                if dst.exists() and dst.stat().st_size == info.file_size:
                    continue
                dst.parent.mkdir(parents=True, exist_ok=True)
                with zf.open(info) as src, open(dst, "wb") as out:  # CRC checked by zipfile
                    shutil.copyfileobj(src, out)
                n_new += 1
            print(f"[{subdir}] seq {seq}: {len(members)} files ({n_new} new), "
                  f"{sum(i.file_size for i in members) / 1e6:.0f} MB")
    print(f"[{subdir}] transferred {rf.bytes_fetched / 1e6:.0f} MB in total")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--data-root", type=Path, default=Path("data"))
    ap.add_argument("--sequences", nargs="*", default=["0014"],
                    help="training sequences for which to fetch LiDAR/images")
    ap.add_argument("--velodyne", action="store_true", help="fetch LiDAR scans for --sequences")
    ap.add_argument("--images", action="store_true", help="fetch image_02 for --sequences")
    ap.add_argument("--skip-metadata", action="store_true")
    ap.add_argument("--skip-detections", action="store_true")
    args = ap.parse_args(argv)
    root: Path = args.data_root
    if not args.skip_metadata:
        fetch_metadata(root)
    if not args.skip_detections:
        fetch_detections(root, TRAINING_SEQS)
    if args.velodyne:
        fetch_sequence_members(root, "data_tracking_velodyne.zip", "velodyne", args.sequences)
    if args.images:
        fetch_sequence_members(root, "data_tracking_image_2.zip", "image_02", args.sequences)
    return 0


if __name__ == "__main__":
    sys.exit(main())
