#!/usr/bin/env python
"""Capture the README hero screenshot and the demo video from the real Rerun viewer (Windows).

    python scripts/capture_demo.py build        # .rrd recordings + capture layouts (saved results, no re-tracking)
    python scripts/capture_demo.py screenshot   # assets/demo/trackscope3d_overview.png
    python scripts/capture_demo.py video        # assets/demo/TrackScope3D_Demo.mp4
    python scripts/capture_demo.py verify       # decode check, blank-frame check, contact sheet

Every viewer frame is a capture of the viewer window itself (Win32 PrintWindow via _viewer_capture.py;
other windows and the desktop cannot appear). Recordings are logged by the project's own
``trackscope.viz.rerun_view.SequenceLogger`` (the code behind scripts/view.py) from saved tracking
results; the tracker is not re-run. Layouts are the viewer's own ``build_blueprint`` layouts, only with
the time panel set for capture. Every number in captions is read from results/.
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import subprocess
import sys
import threading
import time
from pathlib import Path

import numpy as np

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "scripts"))
DEMO = REPO / "results/demo"           # git-ignored work dir (results/* is ignored)
SEG = DEMO / "segments"
OUT = REPO / "assets/demo"
APP_ID = "TrackScope-3D"
FPS = 30
TOP_BAR, TIME_STRIP = 36, 30

# name: (sequence, methods (primary first), frame window [start, end), viewer playback fps)
RECORDINGS = {
    "hero":     ("0014", ["mahalanobis"], (0, 42), 1000.0),          # snapshot -> stops on frame 41
    "intro":    ("0014", ["mahalanobis"], (0, 106), 5.0),            # whole sequence, 0.5x
    "predict":  ("0014", ["mahalanobis"], (14, 34), 2.5),            # coasting + re-association, 0.25x
    "compare":  ("0014", ["mahalanobis", "center", "iou"], (0, 106), 10.0),
    "swap":     ("0016", ["center", "mahalanobis", "iou"], (153, 194), 5.0),  # event 62 window (+-20 frames)
}


# --------------------------------------------------------------------------------------------- build
def build() -> None:
    import rerun as rr
    import rerun.blueprint as rrb
    from trackscope.config import load_config
    from trackscope.viz.rerun_view import SequenceLogger, ViewerConfig, build_blueprint

    exp = load_config("configs/default.yaml")
    DEMO.mkdir(parents=True, exist_ok=True)
    meta = {}
    for name, (seq, methods, frames, fps) in RECORDINGS.items():
        t = time.perf_counter()
        cfg = ViewerConfig(seq=seq, methods=methods, frames=frames, show_gt=False, event_iou_thr=0.25,
                           score_threshold=dict(exp.tracker.score_threshold), kitti_root=exp.data.kitti_root)
        rrd = DEMO / f"{name}.rrd"
        # same logging as trackscope.viz.rerun_view.record(), but no embedded default blueprint
        # (it would load after the capture layout and replace it)
        rec = rr.RecordingStream(application_id=APP_ID, recording_id=f"capture-{name}")
        rec.save(str(rrd))
        lg = SequenceLogger(cfg, rec)
        first = lg.frame_window().start
        bp = build_blueprint(cfg, lg.has_images, lg.replays[cfg.primary][first].T_world_velo, lg.seq.image_size)
        win = lg.log_all()
        rec.flush()
        rec.disconnect()
        play = (dict(fps=1000.0, play_state="playing", loop_mode="off") if fps >= 1000
                else dict(fps=fps, play_state="paused", loop_mode="off"))
        layout = rrb.Blueprint(bp.root_container, rrb.TimePanel(state="collapsed", timeline="frame", **play),
                               rrb.BlueprintPanel(state="collapsed"), rrb.SelectionPanel(state="collapsed"),
                               auto_layout=False, auto_views=False)
        layout.save(APP_ID, str(DEMO / f"{name}.rbl"))
        meta[name] = {"seq": seq, "methods": methods, "frames": [win.start, win.stop - 1], "viewer_fps": fps,
                      "lidar": lg.has_lidar, "camera": lg.has_images}
        print(f"{name}: seq {seq} {methods} frames {win.start}-{win.stop - 1} -> {rrd.name} "
              f"({rrd.stat().st_size / 2**20:.0f} MB, {time.perf_counter() - t:.0f} s)")
    (DEMO / "recordings.json").write_text(json.dumps(meta, indent=2))


# ------------------------------------------------------------------------------------------- capture
class _session:
    """ViewerSession with every persisted viewer layout (APPDATA/rerun/data/blueprints/*.rbl) set aside
    for the duration of the session (the viewer restores them and they override the command-line
    layout); they are always moved back afterwards."""

    def __init__(self, name: str):
        self.args = (DEMO / f"{name}.rrd", DEMO / f"{name}.rbl")
        self.dir = Path(os.environ["APPDATA"]) / "rerun/data/blueprints"
        self.aside = self.dir / "_capture_aside"

    def __enter__(self):
        from _viewer_capture import ViewerSession
        if self.aside.exists() and any(self.aside.iterdir()):
            raise RuntimeError(f"{self.aside} is not empty: move its files back to {self.dir} first")
        self.aside.mkdir(exist_ok=True)
        self.moved = []
        for p in self.dir.glob("*.rbl"):
            p.rename(self.aside / p.name)
            self.moved.append(p.name)
        try:
            self.s = ViewerSession(*self.args)
        except BaseException:
            self._restore()
            raise
        return self.s

    def _restore(self):
        for n in self.moved:
            (self.dir / n).unlink(missing_ok=True)
            (self.aside / n).rename(self.dir / n)
        self.aside.rmdir()

    def __exit__(self, *exc):
        try:
            self.s.close()
        finally:
            self._restore()


def _wait_rendered(s, timeout: float = 60.0, settle: float = 2.0, min_wait: float = 9.0) -> None:
    """Content present and stable; ``min_wait`` skips the viewer's update toast (~2.5-5.5 s after start)."""
    from _viewer_capture import is_blank
    t0, prev, still = time.time(), None, None
    while time.time() - t0 < timeout:
        f = s.grab()[::4, ::4].astype(np.int16)
        if time.time() - t0 > min_wait and not is_blank(f, background=(12, 14, 18)) and prev is not None \
                and np.abs(f - prev).mean() < 0.05:
            still = still or time.time()
            if time.time() - still >= settle:
                return
        else:
            still = None
        prev = f
        time.sleep(0.25)
    raise RuntimeError("viewer did not settle")


def _record(s, path: Path, seconds: float) -> int:
    from _ffmpeg_io import ffmpeg_exe
    g = s._grabber
    ff = subprocess.Popen([ffmpeg_exe(), "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "bgra",
                           "-s", f"{g.w}x{g.h}", "-framerate", str(FPS), "-i", "-", "-c:v", "libx264",
                           "-preset", "ultrafast", "-crf", "10", "-pix_fmt", "yuv444p", str(path)],
                          stdin=subprocess.PIPE)
    n, written, t0 = int(seconds * FPS), 0, time.perf_counter()
    frame = g.grab_bgra().tobytes()
    while written < n:
        due = int((time.perf_counter() - t0) * FPS)
        if written <= due:
            frame = g.grab_bgra().tobytes()
        while written <= min(due, n - 1):
            ff.stdin.write(frame)
            written += 1
        time.sleep(max(0.0, written / FPS - (time.perf_counter() - t0)))
    ff.stdin.close()
    if ff.wait():
        raise RuntimeError("ffmpeg failed")
    return written


def _frames(path: Path):
    from _ffmpeg_io import read_frames
    yield from read_frames(path)


def capture(name: str, seconds: float, play: bool) -> Path:
    path = SEG / f"{name}.mp4"
    with _session(name) as s:
        _wait_rendered(s)
        if play:
            threading.Timer(1.0, s.press_space).start()
        _record(s, path, seconds)
    return path


def screenshot() -> None:
    from PIL import Image
    from _viewer_capture import is_blank
    OUT.mkdir(parents=True, exist_ok=True)
    with _session("hero") as s:
        _wait_rendered(s)
        img = s.grab()
    if is_blank(img, background=(12, 14, 18)):
        raise RuntimeError("blank capture")
    p = OUT / "trackscope3d_overview.png"
    Image.fromarray(img[TOP_BAR:-TIME_STRIP]).save(p, optimize=True)
    print(f"hero -> {p} ({p.stat().st_size / 2**20:.2f} MB)")


# ------------------------------------------------------------------------------------------ assembly
def _font(size: int, bold: bool = False):
    from PIL import ImageFont
    return ImageFont.truetype("segoeuib.ttf" if bold else "segoeui.ttf", size)


def _caption(lines: list[str], w: int = 1920, h: int = 1080) -> np.ndarray:
    """Full-width bottom band; covers the viewer's time strip (UI chrome), not the data views' centres."""
    from PIL import Image, ImageDraw
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    f0, f1 = _font(26, True), _font(21)
    bh = 20 + 36 + 30 * (len(lines) - 1)
    y0 = h - bh - 4
    d.rectangle([0, y0, w, h], fill=(0, 0, 0, 225))
    d.line([0, y0, w, y0], fill=(90, 170, 255, 255), width=2)
    d.text((32, y0 + 10), lines[0], font=f0, fill=(255, 255, 255, 255))
    for i, t in enumerate(lines[1:]):
        d.text((32, y0 + 48 + 30 * i), t, font=f1, fill=(225, 225, 220, 255))
    return np.asarray(img)


def _title(title: str, sub: str, note: str, w: int = 1920, h: int = 1080) -> np.ndarray:
    from PIL import Image, ImageDraw
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    ft, fs, fn = _font(72, True), _font(34), _font(22)
    bw = max(d.textlength(title, font=ft), d.textlength(sub, font=fs), d.textlength(note, font=fn)) + 120
    x0, y0, bh = (w - bw) / 2, h / 2 - 130, 250
    d.rounded_rectangle([x0, y0, x0 + bw, y0 + bh], radius=16, fill=(8, 8, 10, 228))
    d.text((w / 2, y0 + 70), title, font=ft, fill=(255, 255, 255, 255), anchor="mm")
    d.text((w / 2, y0 + 145), sub, font=fs, fill=(90, 170, 255, 255), anchor="mm")
    d.text((w / 2, y0 + 205), note, font=fn, fill=(200, 200, 195, 255), anchor="mm")
    return np.asarray(img)


def _blend(frame, ov, alpha_scale: float = 1.0):
    a = ov[:, :, 3:4].astype(np.float32) / 255.0 * alpha_scale
    return (frame.astype(np.float32) * (1 - a) + ov[:, :, :3].astype(np.float32) * a).astype(np.uint8)


def _active_span(path: Path) -> tuple[int, int, int]:
    """First/last capture index where the picture changes (playback start/end)."""
    prev, diffs = None, []
    for f in _frames(path):
        g = f[::4, ::4].astype(np.int16)
        diffs.append(0.0 if prev is None else float(np.abs(g - prev).mean()))
        prev = g
    moving = [i for i, v in enumerate(diffs) if v > 0.02]
    if not moving or moving[-1] >= len(diffs) - FPS // 2:
        raise RuntimeError(f"{path.name}: playback did not finish inside the capture")
    return moving[0], moving[-1], len(diffs)


def _results() -> dict:
    """Numbers for captions and the summary card, read from saved evaluation outputs."""
    rows = list(csv.DictReader(open(REPO / "results/evaluation/summary.csv", newline="")))

    def get(cls, method, thr="0.25", ev="custom KITTI 3D tracking evaluation (oriented 3D IoU)"):
        return next(r for r in rows if r["evaluation"] == ev and r["iou_thr"] == thr and r["class"] == cls
                    and r["method"] == method)
    det = "custom KITTI 3D tracking evaluation (oriented 3D IoU) - detector only"
    m = json.loads((REPO / "results/evaluation/metrics.json").read_text())
    return {"get": get, "det": det, "metrics": m}


def summary_card() -> np.ndarray:
    from PIL import Image, ImageDraw
    R = _results()
    get = R["get"]
    img = Image.new("RGB", (1920, 1080), (12, 14, 18))
    d = ImageDraw.Draw(img)
    d.text((80, 55), "Evaluation summary", font=_font(54, True), fill=(255, 255, 255))
    d.text((80, 130), "10 held-out KITTI Tracking sequences · real PointRCNN detections · custom 3D evaluation "
                      "(3D IoU 0.25), not official KITTI scores", font=_font(24), fill=(200, 200, 195))
    y = 200
    d.text((80, y), "Tracking accuracy (Mahalanobis-gated Hungarian)", font=_font(28, True), fill=(225, 225, 220))
    y += 50
    for cls in ("Car", "Pedestrian"):
        r = get(cls, "mahalanobis")
        d.text((100, y), cls, font=_font(26), fill=(200, 200, 195))
        d.text((330, y), f"MOTA {float(r['MOTA']):.3f}   IDF1 {float(r['IDF1']):.3f}   IDSW {int(float(r['IDSW']))}",
               font=_font(26, True), fill=(90, 170, 255))
        y += 44
    y += 22
    d.text((80, y), "Throughput (single CPU thread, Python, all 11 val sequences)", font=_font(28, True),
           fill=(225, 225, 220))
    y += 50
    car = get("Car", "mahalanobis")
    rt = R["metrics"].get("runtime", {})
    e2e = rt.get("mahalanobis", {}).get("end_to_end_fps_excl_detector") if isinstance(rt, dict) else None
    d.text((100, y), f"Tracker step only: {float(car['tracker_step_fps']):.0f} FPS", font=_font(26, True),
           fill=(90, 170, 255))
    y += 42
    if e2e:
        d.text((100, y), f"End-to-end processing, detector excluded: {float(e2e):.0f} FPS", font=_font(26, True),
               fill=(90, 170, 255))
        y += 42
    d.text((100, y), "PointRCNN inference is NOT included (detections are precomputed); a full perception",
           font=_font(23), fill=(200, 200, 195))
    y += 34
    d.text((100, y), "system would be dominated by the detector.", font=_font(23), fill=(200, 200, 195))
    y += 56
    d.text((80, y), "Detector dependence", font=_font(28, True), fill=(225, 225, 220))
    y += 50
    for cls in ("Car", "Pedestrian"):
        dr = get(cls, "detector(score>=thr)", ev=R["det"])
        tr = get(cls, "mahalanobis")
        d.text((100, y), f"{cls}: detector recall {float(dr['Recall']):.3f} -> tracker recall {float(tr['Recall']):.3f};"
                         f" precision {float(dr['Precision']):.3f} -> {float(tr['Precision']):.3f}",
               font=_font(23), fill=(200, 200, 195))
        y += 36
    d.text((100, y), "Most misses have no overlapping detection: the detector's recall bounds the tracker.",
           font=_font(23), fill=(200, 200, 195))
    fig = Image.open(REPO / "results/evaluation/figures/association_comparison.png").convert("RGB")
    fw = 820
    fig = fig.resize((fw, int(fig.height * fw / fig.width)), Image.LANCZOS)
    img.paste(fig, (1920 - fw - 50, 200))
    d.text((1920 - fw - 50, 200 + fig.height + 10), "results/evaluation/figures/association_comparison.png",
           font=_font(19), fill=(150, 150, 145))
    return np.asarray(img)


def video() -> None:
    from _ffmpeg_io import Writer
    SEG.mkdir(parents=True, exist_ok=True)
    R = _results()
    get = R["get"]
    car_m, ped_m = get("Car", "mahalanobis"), get("Pedestrian", "mahalanobis")
    idsw = {m: int(float(get("Car", m)["IDSW"])) for m in ("center", "mahalanobis", "iou")}
    # (recording, capture seconds, caption lines; None = title over the first seconds)
    scenes = [
        ("intro", 30.0, [
            ["1  3D multi-object tracking · KITTI Tracking seq 0014 (development sequence), {speed}",
             "Saved tracker output (Mahalanobis-gated Hungarian) on real PointRCNN detections: 3D boxes, persistent IDs,",
             "40-frame trails, 1 s velocity arrows, LiDAR, camera projection (Camera 02) and bird's-eye view. Grey = detections."]]),
        ("predict", 16.0, [
            ["2  Kalman prediction and re-association · seq 0014, frames 14-33, {speed}",
             "Solid box = updated with a detection this frame. Thin wireframe 'PREDICTED (+k)' = confirmed track coasting",
             "on the constant-velocity Kalman prediction. Frame 20: tracks 0, 2, 3, 29 coast. Frame 21: 0, 2, 29 re-associated with",
             "the same IDs; track 3 is terminated (no detection for longer than max_age = 2). Values: results/pointrcnn_mahalanobis."]]),
        ("compare", 18.0, [
            ["3  Association methods on the same detections · seq 0014, {speed}",
             "BEV: Mahalanobis (M), center distance (C), 3D IoU (I). IDs are per tracker and not comparable across methods.",
             "Same detections, Kalman filter and lifecycle; only the association criterion differs."]]),
        ("swap", 14.0, [
            ["4  Identity swap · held-out seq 0016, frames 153-193, {speed} (tracks and detections only: no LiDAR downloaded)",
             "Magenta = evaluation event from results/evaluation/failure_cases.csv. Center association swaps two cars",
             f"(frames 173-175); Mahalanobis and IoU keep them. Held-out Car ID switches: center {idsw['center']}, "
             f"Mahalanobis {idsw['mahalanobis']}, IoU {idsw['iou']}."]]),
    ]
    raw = []
    for name, secs, _ in scenes:
        p = SEG / f"{name}.mp4"
        if not p.is_file():
            print("capturing", name, flush=True)
            capture(name, secs, play=True)
        raw.append(p)

    out = OUT / "TrackScope3D_Demo.mp4"
    OUT.mkdir(parents=True, exist_ok=True)
    w = Writer(out, 1920, 1080, fps=FPS, crf=20)
    title = _title("TrackScope-3D", "3D Multi-Object Tracking with Kalman Filtering and Data Association",
                   "Real Rerun viewer · KITTI Tracking · saved tracker outputs (not re-run)")
    log = []
    try:
        for (name, _, caps), p in zip(scenes, raw):
            a, b, n = _active_span(p)
            lo, hi = max(0, a - FPS // 2), min(n - 1, b + int(1.5 * FPS))
            _, _, (f0, f1), _ = RECORDINGS[name]
            speed = (f1 - f0) / 10.0 / ((b - a) / FPS)  # measured: sensor time / on-screen playback time
            cap = [c.replace("{speed}", f"replay at about {speed:.2f}x real time (measured)") for c in caps[0]]
            ov = _caption(cap)
            count = 0
            for i, f in enumerate(_frames(p)):
                if i < lo:
                    continue
                if i > hi:
                    break
                t = (i - lo) / FPS
                if name == "intro" and t < 6.0:  # title over the first 6 s of the first replay
                    f = f.copy()
                    f[-TIME_STRIP:] = (12, 14, 18)  # time strip = UI chrome
                    f = _blend(f, title, min(1.0, t / 0.5, (6.0 - t) / 0.6))
                else:
                    f = _blend(f, ov)
                w.append(f)
                count += 1
            log.append({"segment": p.name, "frames": count, "seconds": round(count / FPS, 2), "replay_speed_x": round(speed, 3), "caption": cap})
        card = summary_card()
        for _ in range(int(12 * FPS)):
            w.append(card)
        log.append({"segment": "summary card (results/evaluation)", "frames": int(12 * FPS), "seconds": 12.0})
    finally:
        w.close()
    (DEMO / "video_segments.json").write_text(json.dumps(log, indent=2))
    print(json.dumps(log, indent=2))
    print(f"video -> {out} ({out.stat().st_size / 2**20:.1f} MB, {sum(x['seconds'] for x in log):.1f} s)")


def verify() -> None:
    from PIL import Image
    from _ffmpeg_io import probe
    from _viewer_capture import is_blank
    out = OUT / "TrackScope3D_Demo.mp4"
    meta = probe(out)
    thumbs, blanks, n = [], [], 0
    for i, f in enumerate(_frames(out)):
        n += 1
        if f.mean() < 3:
            blanks.append(i)
        if i % (2 * FPS) == 0:
            thumbs.append(Image.fromarray(f).resize((384, 216)))
            if is_blank(f, background=(12, 14, 18)):
                blanks.append(i)
    sheet = Image.new("RGB", (384 * 6, 216 * ((len(thumbs) + 5) // 6)))
    for i, t in enumerate(thumbs):
        sheet.paste(t, (384 * (i % 6), 216 * (i // 6)))
    (DEMO / "verify").mkdir(parents=True, exist_ok=True)
    sheet.save(DEMO / "verify/video_contact_sheet.png")
    rep = {"file": str(out), "decoded_frames": n, "fps": meta["fps"], "size": [meta["width"], meta["height"]],
           "duration_s": round(n / meta["fps"], 2), "container_duration_s": meta["duration_s"],
           "size_mb": round(out.stat().st_size / 2**20, 1), "codec": meta["codec"], "black_or_blank_frames": blanks[:50]}
    (DEMO / "verify/verification.json").write_text(json.dumps(rep, indent=2))
    print(json.dumps(rep, indent=2))


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("step", choices=["build", "screenshot", "video", "verify"])
    os.chdir(REPO)
    {"build": build, "screenshot": screenshot, "video": video, "verify": verify}[ap.parse_args().step]()
