"""Interactive Rerun replay of saved TrackScope-3D results.

Examples::

    python scripts/view.py                                  # seq 0014, Mahalanobis, opens the viewer
    python scripts/view.py --compare                        # + center / IoU BEV side by side
    python scripts/view.py --seq 0016 --method center --list-events
    python scripts/view.py --seq 0016 --method center --event 0     # window around an eval event
    python scripts/view.py --seq 0019 --frames 240:290 --compare
    python scripts/view.py --save results/viz/seq0014.rrd --no-open  # write a recording only

Nothing is re-tracked: the viewer reads results/pointrcnn_<method>/frames/<seq>.jsonl,
results/evaluation/failure_cases.csv and the KITTI sensor data that is available locally.
"""

from __future__ import annotations

import argparse
import subprocess
import sys
import time

from trackscope.config import load_config
from trackscope.viz.replay import load_events


def parse_frames(s: str) -> tuple[int, int]:
    a, b = s.split(":")
    return int(a), int(b)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--seq", default="0014")
    ap.add_argument("--method", default="mahalanobis", choices=["center", "mahalanobis", "iou"],
                    help="primary association method (3D view, camera)")
    ap.add_argument("--compare", action="store_true", help="add BEV views of all three methods")
    ap.add_argument("--frames", type=parse_frames, help="frame window START:END (end exclusive)")
    ap.add_argument("--event", type=int, help="index of an evaluation event (see --list-events); "
                                              "shows a window of +-20 frames around it")
    ap.add_argument("--list-events", action="store_true")
    ap.add_argument("--iou-thr", type=float, default=0.25, help="evaluation setting of the events")
    ap.add_argument("--show-gt", action="store_true", help="also draw ground-truth boxes (analysis layer)")
    ap.add_argument("--save", help="write an .rrd recording instead of streaming to a live viewer")
    ap.add_argument("--no-open", action="store_true", help="with --save: do not open the viewer")
    ap.add_argument("--config", default="configs/default.yaml")
    args = ap.parse_args(argv)
    seq = f"{int(args.seq):04d}"

    events = load_events("results/evaluation/failure_cases.csv", seq, args.method, args.iou_thr)
    if args.list_events:
        print(f"evaluation events, seq {seq}, method {args.method}, 3D IoU {args.iou_thr}: {len(events)}")
        for i, e in enumerate(events):
            print(f"[{i:3d}] frame {e.frame:4d}  {e.kind:4s} {e.cls:10s} {e.describe()}")
        return 0

    frames = args.frames
    if args.event is not None:
        if not 0 <= args.event < len(events):
            raise SystemExit(f"--event must be in [0, {len(events)}) for seq {seq} / {args.method}")
        e = events[args.event]
        frames = (max(0, e.frame - 20), e.frame + 21)
        print(f"event {args.event}: frame {e.frame}: {e.describe()}")

    from trackscope.viz.rerun_view import ViewerConfig, record  # needs rerun-sdk

    exp_cfg = load_config(args.config)
    methods = [args.method] + ([m for m in ("center", "mahalanobis", "iou") if m != args.method] if args.compare else [])
    cfg = ViewerConfig(seq=seq, methods=methods, frames=frames, show_gt=args.show_gt, event_iou_thr=args.iou_thr,
                       score_threshold=dict(exp_cfg.tracker.score_threshold),
                       kitti_root=exp_cfg.data.kitti_root)
    t0 = time.perf_counter()
    info = record(cfg, save_path=args.save, spawn=args.save is None)
    print(f"logged frames {info['frames'][0]}..{info['frames'][1] - 1} of seq {seq} in {time.perf_counter() - t0:.1f} s "
          f"(lidar: {info['has_lidar']}, camera: {info['has_images']}, events: {info['events']})")
    if args.save:
        print(f"recording: {args.save}   open with:  rerun {args.save}")
        if not args.no_open:
            subprocess.Popen([sys.executable, "-m", "rerun", args.save])
    return 0


if __name__ == "__main__":
    sys.exit(main())
